#!/usr/bin/env bash
# 欢迎页：SSH 登录时自动显示（/etc/profile.d），也可以 sb welcome 手动查看
# 只读本机数据（状态文件、/proc、systemd），不连外网，登录不卡
# 流量统计：ipwatch 定时任务（每 5 分钟）顺便调用 traffic_tick 记账

TRAFFIC="$ETC_DIR/traffic.json"
WELCOME_HOOK="/etc/profile.d/${SB_NAME}-welcome.sh"

# ---------- 流量统计 ----------
# 默认路由所在网卡
main_iface() { ip -4 route show default 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}'; }

# 记一次账：读网卡累计字节数，和上次比较得出增量，记到当天 / 当月（北京时间）
traffic_tick() {
  local ifc rx tx day mon tmp
  ifc=$(main_iface); [[ -n $ifc && -r /proc/net/dev ]] || return 0
  read -r rx tx < <(awk -v i="$ifc:" '$1==i {print $2, $10}' /proc/net/dev)
  [[ $rx =~ ^[0-9]+$ ]] || return 0
  day=$(TZ=Asia/Shanghai date +%F); mon=${day:0:7}
  [[ -s $TRAFFIC ]] || echo '{}' >"$TRAFFIC"
  tmp=$(mktemp)
  # 计数器变小（重启 / 网卡重建）就把当前值整个当作增量
  jq --argjson rx "$rx" --argjson tx "$tx" --arg d "$day" --arg m "$mon" '
    def delta(cur; last): if last == null then 0 elif cur >= last then cur - last else cur end;
    (delta($rx; .last_rx)) as $drx | (delta($tx; .last_tx)) as $dtx
    | .last_rx = $rx | .last_tx = $tx
    | .day[$d].rx += $drx | .day[$d].tx += $dtx
    | .mon[$m].rx += $drx | .mon[$m].tx += $dtx
    | .day |= (to_entries | sort_by(.key) | .[-40:] | from_entries)
    | .mon |= (to_entries | sort_by(.key) | .[-13:] | from_entries)
  ' "$TRAFFIC" >"$tmp" 2>/dev/null && mv "$tmp" "$TRAFFIC" || rm -f "$tmp"
}

# 字节数 → 1.2 GB
human_bytes() {
  awk -v b="${1:-0}" 'BEGIN{split("B KB MB GB TB",u," "); i=1; while(b>=1024 && i<5){b/=1024; i++}
    printf (i<=2 ? "%d %s" : "%.1f %s"), b, u[i]}'
}

# ---------- 系统资源 ----------
cpu_pct() {  # 采样 0.3 秒
  local a b
  read -r -a a < <(head -1 /proc/stat); sleep 0.3; read -r -a b < <(head -1 /proc/stat)
  local idle=$(( (b[4]+b[5]) - (a[4]+a[5]) )) tot=0 i
  for i in 1 2 3 4 5 6 7 8; do tot=$(( tot + b[i] - a[i] )); done
  (( tot > 0 )) && echo $(( (tot - idle) * 100 / tot )) || echo 0
}
mem_pct() { awk '/^MemTotal/{t=$2} /^MemAvailable/{a=$2} END{printf "%d", (t-a)*100/t}' /proc/meminfo; }
disk_pct() { df -P / | awk 'NR==2{gsub("%","",$5); print $5}'; }
uptime_cn() {
  local s; s=$(cut -d. -f1 /proc/uptime)
  if (( s >= 86400 )); then echo "$(( s / 86400 )) 天"; elif (( s >= 3600 )); then echo "$(( s / 3600 )) 小时"; else echo "$(( s / 60 )) 分钟"; fi
}

# 进度条：bar 百分比 → ███░░░░░░░ 12%（<60 绿，<85 黄，其余红）
bar() {
  local p=${1:-0} n c i s=""
  (( p > 100 )) && p=100
  n=$(( (p + 5) / 10 ))
  if (( p < 60 )); then c=$C_GRN; elif (( p < 85 )); then c=$C_YLW; else c=$C_RED; fi
  s+=$c; for ((i = 0; i < n; i++)); do s+='█'; done
  s+=$C_RST$C_DIM; for ((i = n; i < 10; i++)); do s+='░'; done
  printf '%s%s %3d%%' "$s" "$C_RST" "$p"
}

# 距今多久：ago 时间戳(秒)
ago() {
  local d=$(( $(date +%s) - $1 ))
  if (( d < 3600 )); then echo "$(( d / 60 )) 分钟前"
  elif (( d < 86400 )); then echo "$(( d / 3600 )) 小时前"
  else echo "$(( d / 86400 )) 天前"; fi
}

# 一个协议格子：proto_cell 名称 开关 端口说明
proto_cell() {
  if [[ $2 == true ]]; then padr "$(dot on) $1 ${C_DIM}$3${C_RST}" 22
  else padr "$(dot off) ${C_DIM}$1 关${C_RST}" 22; fi
}

# ---------- 欢迎页 ----------
# 欢迎页渲染位于 terminal.sh。

# 登录时调用：直接进入 sb 菜单（菜单顶部就是欢迎页），按 q 回到命令行
welcome_login() { exec /usr/local/bin/sb; }

# ---------- 登录钩子 ----------
welcome_install() {
  cat >"$WELCOME_HOOK" <<'EOF'
# vps 欢迎页：只在交互式 SSH 登录时显示（scp / sftp / ssh 带命令时不显示）
if [ -n "${PS1:-}" ] && [ -t 0 ] && [ -t 1 ] && [ -z "${SB_WELCOME_SHOWN:-}" ] && [ "$(id -u)" = 0 ] && [ -x /usr/local/bin/sb ]; then
  export SB_WELCOME_SHOWN=1
  /usr/local/bin/sb welcome --login
fi
EOF
  chmod 644 "$WELCOME_HOOK"
}
welcome_remove() { rm -f "$WELCOME_HOOK"; }
welcome_enabled() { [[ -f $WELCOME_HOOK ]]; }

# 清理日志，腾硬盘空间
log_clean() {
  local before after
  before=$(df -P / | awk 'NR==2{print $4}')
  # Only project logs are eligible; never remove other services audit history.
  find "$SB_HOME/log" -type f -size +20M -exec truncate -s 0 {} + 2>/dev/null
  after=$(df -P / | awk 'NR==2{print $4}')
  ok "已清理：仅清理本项目超过 20MB 的日志，腾出 $(human_bytes $(( (after - before) * 1024 )))"
  echo "   硬盘现在用了 $(disk_pct)%"
}
