#!/usr/bin/env bash
# 欢迎页：SSH 登录时自动显示（/etc/profile.d），也可以 sb welcome 手动查看
# 只读本机数据（状态文件、/proc、systemd），不连外网，登录不卡
# 流量统计：ipwatch 定时任务（每 5 分钟）顺便调用 traffic_tick 记账

TRAFFIC="$ETC_DIR/traffic.json"
WELCOME_HOOK="/etc/profile.d/${SB_NAME}-welcome.sh"

# ---------- 流量统计 ----------
# 默认路由所在网卡
main_iface() { ip -4 route show default 2>/dev/null | awk '{for(i=1;i<NF;i++) if($i=="dev"){print $(i+1); exit}}'; }

# 记一次账：读网卡累计字节数，和上次比较得出增量，记到当天 / 当月（北京时间）
traffic_tick() {
  local ifc rx tx day mon tmp
  ifc=$(main_iface); [[ -n $ifc && -r /proc/net/dev ]] || return 0
  read -r rx tx < <(awk -v i="$ifc:" '$1==i {print $2, $10}' /proc/net/dev)
  [[ $rx =~ ^[0-9]+$ ]] || return 0
  day=$(TZ=Asia/Shanghai date +%F); mon=${day:0:7}
  [[ -s $TRAFFIC ]] || echo '{}' >"$TRAFFIC"
  tmp=$(mktemp)
  # 计数器变小（重启 / 网卡重建）就把当前值整个当作增量
  jq --argjson rx "$rx" --argjson tx "$tx" --arg d "$day" --arg m "$mon" '
    def delta(cur; last): if last == null then 0 elif cur >= last then cur - last else cur end;
    (delta($rx; .last_rx)) as $drx | (delta($tx; .last_tx)) as $dtx
    | .last_rx = $rx | .last_tx = $tx
    | .day[$d].rx += $drx | .day[$d].tx += $dtx
    | .mon[$m].rx += $drx | .mon[$m].tx += $dtx
    | .day |= (to_entries | sort_by(.key) | .[-40:] | from_entries)
    | .mon |= (to_entries | sort_by(.key) | .[-13:] | from_entries)
  ' "$TRAFFIC" >"$tmp" 2>/dev/null && mv "$tmp" "$TRAFFIC" || rm -f "$tmp"
}

# 字节数 → 1.2 GB
human_bytes() {
  awk -v b="${1:-0}" 'BEGIN{split("B KB MB GB TB",u," "); i=1; while(b>=1024 && i<5){b/=1024; i++}
    printf (i<=2 ? "%d %s" : "%.1f %s"), b, u[i]}'
}

# ---------- 系统资源 ----------
cpu_pct() {  # 采样 0.3 秒
  local a b
  read -r -a a < <(head -1 /proc/stat); sleep 0.3; read -r -a b < <(head -1 /proc/stat)
  local idle=$(( (b[4]+b[5]) - (a[4]+a[5]) )) tot=0 i
  for i in 1 2 3 4 5 6 7 8; do tot=$(( tot + b[i] - a[i] )); done
  (( tot > 0 )) && echo $(( (tot - idle) * 100 / tot )) || echo 0
}
mem_pct() { awk '/^MemTotal/{t=$2} /^MemAvailable/{a=$2} END{printf "%d", (t-a)*100/t}' /proc/meminfo; }
disk_pct() { df -P / | awk 'NR==2{gsub("%","",$5); print $5}'; }
uptime_cn() {
  local s; s=$(cut -d. -f1 /proc/uptime)
  if (( s >= 86400 )); then echo "$(( s / 86400 )) 天"; elif (( s >= 3600 )); then echo "$(( s / 3600 )) 小时"; else echo "$(( s / 60 )) 分钟"; fi
}

# 进度条：bar 百分比 → ███░░░░░░░ 12%（<60 绿，<85 黄，其余红）
bar() {
  local p=${1:-0} n c i s=""
  (( p > 100 )) && p=100
  n=$(( (p + 5) / 10 ))
  if (( p < 60 )); then c=$C_GRN; elif (( p < 85 )); then c=$C_YLW; else c=$C_RED; fi
  s+=$c; for ((i = 0; i < n; i++)); do s+='█'; done
  s+=$C_RST$C_DIM; for ((i = n; i < 10; i++)); do s+='░'; done
  printf '%s%s %3d%%' "$s" "$C_RST" "$p"
}

# 距今多久：ago 时间戳(秒)
ago() {
  local d=$(( $(date +%s) - $1 ))
  if (( d < 3600 )); then echo "$(( d / 60 )) 分钟前"
  elif (( d < 86400 )); then echo "$(( d / 3600 )) 小时前"
  else echo "$(( d / 86400 )) 天前"; fi
}

# 一个协议格子：proto_cell 名称 开关 端口说明
proto_cell() {
  if [[ $2 == true ]]; then padr "$(dot on) $1 ${C_DIM}$3${C_RST}" 22
  else padr "$(dot off) ${C_DIM}$1 关${C_RST}" 22; fi
}

# ---------- 欢迎页 ----------
whr() { printf '  %s%s%s
' "$C_DIM" "────────────────────────────────────────────────────────────────────────────────────" "$C_RST"; }
show_welcome() {
  local warns=() bad=0 sys ver lvl now
  now=$(date +%s)
  ver=$(cat "$SB_HOME/VERSION" 2>/dev/null || echo dev)
  lvl=$(st .level)
  sys=$( . /etc/os-release 2>/dev/null; echo "${NAME%% *} ${VERSION_ID:-}")

  # —— 先收集告警，决定右上角的总状态 ——
  local xs ss ag=""
  xs=$(systemctl is-active "$SVC_X" 2>/dev/null); ss=$(systemctl is-active "$SVC_S" 2>/dev/null)
  ! xray_needed || [[ $xs == active ]] || { warns+=("${C_RED}Xray 没在运行：sb log 看日志，或 sb → 1 重装${C_RST}"); bad=1; }
  ! sbox_needed || [[ $ss == active ]] || { warns+=("${C_RED}sing-box 没在运行：sb log 看日志，或 sb → 1 重装${C_RST}"); bad=1; }
  if [[ -n $(st .panel.url) ]]; then
    ag=$(systemctl is-active "${SB_NAME}-agent" 2>/dev/null)
    [[ $ag == active ]] || warns+=("${C_YLW}面板 agent 没在运行：sb panel reapply${C_RST}")
  fi
  local cpu mem disk
  cpu=$(cpu_pct); mem=$(mem_pct); disk=$(disk_pct)
  (( disk >= 80 )) && warns+=("${C_YLW}硬盘用了 ${disk}%，可以清理日志：sb log clean${C_RST}")
  (( mem >= 90 )) && warns+=("${C_YLW}内存用了 ${mem}%${C_RST}")
  local cd=""
  if [[ $(st .l1.enabled) == true ]] && declare -F cert_days >/dev/null; then
    cd=$(cert_days "$CERT_DIR/direct.crt" 2>/dev/null)
    [[ $cd =~ ^-?[0-9]+$ ]] && (( cd < 15 )) && warns+=("${C_YLW}证书只剩 $cd 天，自动续期可能失败：sb → 4 → 4 重新签发${C_RST}")
  fi
  local k r fails=()
  for k in x s geo self; do
    r=$(jq -r --arg k "$k" '.upd.result[$k].result // empty' "$STATE" 2>/dev/null)
    [[ $r == fail ]] && case $k in x) fails+=(Xray) ;; s) fails+=(sing-box) ;; geo) fails+=(Geo) ;; self) fails+=(脚本) ;; esac
  done
  ((${#fails[@]})) && warns+=("${C_YLW}上次更新失败（已自动回滚）：${fails[*]}，详情 sb status${C_RST}")
  local bk bk_t=0
  bk=$(ls -1t "$SB_HOME"/backup/*.sbk 2>/dev/null | head -1)
  [[ -n $bk ]] && bk_t=$(stat -c %Y "$bk")
  (( now - bk_t > 3 * 86400 )) && warns+=("${C_YLW}超过 3 天没有备份：sb backup now${C_RST}")
  local eg
  eg=$(jq -r --arg ip "$(st .ip)" '[(.egress // {}) | to_entries[] | select(.value != $ip) | .key] | join(", ")' "$STATE" 2>/dev/null)

  local status
  if (( bad )); then status="${C_RED}● 有服务停了${C_RST}"
  elif ((${#warns[@]})); then status="${C_YLW}● ${#warns[@]} 项需要注意${C_RST}"
  else status="${C_GRN}● 一切正常${C_RST}"; fi

  # —— 标题 ——
  echo
  local head="  ${C_B}${C_BLU}◆${C_RST} ${C_B}$(st .node_name)${C_RST}  ${C_DIM}· L${lvl} · v${ver} · ${sys} · 已运行 $(uptime_cn)${C_RST}"
  printf '%s   %s\n' "$head" "$status"
  whr
  # —— 资源 ——
  printf '   %sCPU%s %s    %s内存%s %s    %s硬盘%s %s    %s负载%s %s\n' \
    "$C_DIM" "$C_RST" "$(bar "$cpu")" "$C_DIM" "$C_RST" "$(bar "$mem")" "$C_DIM" "$C_RST" "$(bar "$disk")" \
    "$C_DIM" "$C_RST" "$(cut -d' ' -f1 /proc/loadavg)"
  whr
  # —— 服务与协议 ——
  printf '   %s%s%s\n' \
    "$(padr "$(dot "$([[ $xs == active ]] && echo on || echo bad)") Xray ${C_DIM}$(st .core.xray)${C_RST}" 22)" \
    "$(padr "$(dot "$([[ $ss == active ]] && echo on || echo bad)") sing-box ${C_DIM}$(st .core.singbox)${C_RST}" 22)" \
    "$(if [[ -n $(st .panel.url) ]]; then echo "$(dot "$([[ $ag == active ]] && echo on || echo bad)") 面板 ${C_DIM}已接入${C_RST}"; else echo "$(dot off) ${C_DIM}面板 未接入${C_RST}"; fi)"
  local hop=""; [[ $(st .proto.hy2.hop_enabled) == true ]] && hop=" +跳跃"
  printf '   %s%s%s\n' \
    "$(proto_cell Vision "$(st .proto.vision.enabled)" "$(st .proto.vision.port)")" \
    "$(proto_cell XHTTP "$(st .proto.xhttp.enabled)" "$(st .proto.xhttp.port)")" \
    "$(proto_cell Hy2 "$(st .proto.hy2.enabled)" "$(st .proto.hy2.port)$hop")"
  if [[ $(st .l1.enabled) == true ]]; then
    printf '   %s%s%s\n' \
      "$(proto_cell Hy2-TLS "$(st .l1.hy2tls_enabled)" "$(st .l1.hy2tls_port)")" \
      "$(proto_cell CDN "$(st .l1.cdn_enabled)" "$(st .l1.cdn_port)")" \
      "${C_DIM}屏蔽回国 $([[ $(st .block.cn) == true ]] && echo 开 || echo 关) · BT $([[ $(st .block.bt) == true ]] && echo 开 || echo 关)${C_RST}"
  else
    printf '   %s%s\n' "$(padr "${C_DIM}屏蔽回国 $([[ $(st .block.cn) == true ]] && echo 开 || echo 关) · BT $([[ $(st .block.bt) == true ]] && echo 开 || echo 关)${C_RST}" 44)" \
      "${C_DIM}没有域名（sb → 4 升级 L1）${C_RST}"
  fi
  # 可选协议：开了任意一个才显示这一行
  if [[ $(proto_on tuic) == true || $(proto_on anytls) == true || $(proto_on naive) == true ]]; then
    printf '   %s%s%s\n' \
      "$(proto_cell TUIC "$(proto_on tuic)" "$(st .proto.tuic.port)")" \
      "$(proto_cell AnyTLS "$(proto_on anytls)" "$(st .proto.anytls.port)")" \
      "$(proto_cell Naive "$(proto_on naive)" "$(st .proto.naive.port)")"
  fi
  whr
  # —— 网络、证书、用户、流量、更新、备份 ——
  printf '   %sIP%s   %s  %s' "$C_DIM" "$C_RST" "$(st .ip)" \
    "$([[ -z $eg ]] && echo "${C_GRN}出口一致${C_RST}" || echo "${C_YLW}$eg 出口不同${C_RST}")"
  [[ $(st .l1.enabled) == true ]] && printf '    %s域名%s %s' "$C_DIM" "$C_RST" "$(st .l1.direct_host)"
  echo
  local users today month
  users=$(jq '[.users[]|select(.enabled)]|length' "$STATE" 2>/dev/null)
  printf '   %s用户%s %s 个' "$C_DIM" "$C_RST" "${users:-0}"
  [[ -n $cd ]] && printf '    %s证书%s 还剩 %s 天' "$C_DIM" "$C_RST" "$cd"
  if [[ -s $TRAFFIC ]]; then
    local d m
    d=$(TZ=Asia/Shanghai date +%F); m=${d:0:7}
    today=$(jq -r --arg d "$d" '.day[$d] // {} | "\(.tx // 0) \(.rx // 0)"' "$TRAFFIC" 2>/dev/null)
    month=$(jq -r --arg m "$m" '.mon[$m] // {} | (.tx // 0) + (.rx // 0)' "$TRAFFIC" 2>/dev/null)
    printf '    %s今日流量%s ↑ %s  ↓ %s    %s本月%s %s' "$C_DIM" "$C_RST" \
      "$(human_bytes "${today% *}")" "$(human_bytes "${today#* }")" "$C_DIM" "$C_RST" "$(human_bytes "$month")"
  else
    printf '    %s流量统计 5 分钟后开始%s' "$C_DIM" "$C_RST"
  fi
  echo
  # 最近一次成功更新（核心或脚本）
  local last
  last=$(jq -r '[.upd.result // {} | to_entries[] | select(.value.result == "ok") | {k: .key, t: .value.time}] | sort_by(.t) | last // empty
    | "\(.k)\t\(.t)"' "$STATE" 2>/dev/null)
  printf '   %s更新%s ' "$C_DIM" "$C_RST"
  if [[ -n $last ]]; then
    local n=${last%%$'\t'*} t=${last#*$'\t'}
    case $n in x) n=Xray ;; s) n=sing-box ;; geo) n=Geo 规则 ;; self) n=脚本 ;; esac
    printf '%s %s 已更新' "$n" "${t:5:11}"
  else printf '%s暂无%s' "$C_DIM" "$C_RST"; fi
  printf '    %s备份%s %s\n' "$C_DIM" "$C_RST" "$( (( bk_t > 0 )) && ago "$bk_t" || echo "${C_YLW}还没有${C_RST}")"
  # —— 告警 ——
  if ((${#warns[@]})); then
    whr
    local w; for w in "${warns[@]}"; do printf '   %s!%s %s\n' "$C_YLW" "$C_RST" "$w"; done
  fi
  whr
  printf '   %ssb%s 菜单   %ssb s%s 状态   %ssb sub%s 链接   %ssb probe%s 测线路   %ssb log%s 日志\n' \
    "$C_BLU" "$C_RST" "$C_BLU" "$C_RST" "$C_BLU" "$C_RST" "$C_BLU" "$C_RST" "$C_BLU" "$C_RST"
}

# 登录时调用：直接进入 sb 菜单（菜单顶部就是欢迎页），按 q 回到命令行
welcome_login() { exec /usr/local/bin/sb; }

# ---------- 登录钩子 ----------
welcome_install() {
  cat >"$WELCOME_HOOK" <<'EOF'
# vps 欢迎页：只在交互式 SSH 登录时显示（scp / sftp / ssh 带命令时不显示）
if [ -n "${PS1:-}" ] && [ -t 0 ] && [ -t 1 ] && [ -z "${SB_WELCOME_SHOWN:-}" ] && [ "$(id -u)" = 0 ] && [ -x /usr/local/bin/sb ]; then
  export SB_WELCOME_SHOWN=1
  /usr/local/bin/sb welcome --login
fi
EOF
  chmod 644 "$WELCOME_HOOK"
}
welcome_remove() { rm -f "$WELCOME_HOOK"; }
welcome_enabled() { [[ -f $WELCOME_HOOK ]]; }

# 清理日志，腾硬盘空间
log_clean() {
  local before after
  before=$(df -P / | awk 'NR==2{print $4}')
  # Only project logs are eligible; never remove other services audit history.
  find "$SB_HOME/log" -type f -size +20M -exec truncate -s 0 {} + 2>/dev/null
  after=$(df -P / | awk 'NR==2{print $4}')
  ok "已清理：仅清理本项目超过 20MB 的日志，腾出 $(human_bytes $(( (after - before) * 1024 )))"
  echo "   硬盘现在用了 $(disk_pct)%"
}
