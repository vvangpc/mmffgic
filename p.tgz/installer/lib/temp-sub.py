#!/usr/bin/env python3
"""Short-lived exact-path subscription handler. No directory listing or traversal."""
import http.server
import pathlib
import re
import sys

port, token = int(sys.argv[1]), sys.argv[2]
if not re.fullmatch(r"[0-9a-f]{32}", token):
    raise SystemExit("invalid token")
allowed = {f"/{token}/{n}": pathlib.Path(token, n).read_bytes() for n in ("clash.yaml", "v2ray.txt")}

class Handler(http.server.BaseHTTPRequestHandler):
    def setup(self):
        self.request.settimeout(5)
        super().setup()

    def do_GET(self):
        data = allowed.get(self.path)
        if data is None:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *_):
        pass

server = http.server.HTTPServer(("0.0.0.0", port), Handler)
server.timeout = 5
server.serve_forever()
