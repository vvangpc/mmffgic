#!/usr/bin/env bash
# 备份 / 恢复：加密打包配置、密钥、UUID、证书和设置
# SBK2 认证加密，使用每台 VPS 独立 backup-v2.key；旧备份只读兼容
# 接入面板后上传；节点仅可读取自己的备份，跨机由管理员下载导入

BK_DIR="$SB_HOME/backup"
BK_KEEP=7

backup_key() {
  if [[ ! -s $ETC_DIR/backup-v2.key ]]; then
    rand_hex 32 >"$ETC_DIR/backup-v2.key"; chmod 600 "$ETC_DIR/backup-v2.key"
  fi
  cat "$ETC_DIR/backup-v2.key"
}
# 打包内容：etc（状态、证书、配置、规则）+ L1 的 ACME 证书
backup_create() {
  local mode=${1:-manual} f tmp
  mkdir -p "$BK_DIR"; chmod 700 "$BK_DIR"
  f="$BK_DIR/$(st .node_name | tr -cd 'A-Za-z0-9_-')-$(date +%Y%m%d-%H%M%S).sbk"
  tmp=$(mktemp)
  local items=(etc)
  [[ -d $SB_HOME/acme/certs ]] && items+=(acme/certs)
  [[ -d $SB_HOME/acme/data ]] && items+=(acme/data)
  backup_key >/dev/null
  # 规则集可重新下载，不打包（备份保持在几十 KB，便于上传面板）
  if ! tar -czf "$tmp" -C "$SB_HOME" --exclude=etc/rules --exclude=etc/jobs --exclude='etc/*.new' "${items[@]}" 2>/dev/null; then
    rm -f "$tmp"; alert "备份打包失败"; return 1
  fi
  python3 "$SB_HOME/lib/backup_codec.py" encrypt "$tmp" "$f" "$ETC_DIR/backup-v2.key" || {
    rm -f "$tmp" "$f"; alert "备份加密失败"; return 1; }
  rm -f "$tmp"; chmod 600 "$f"
  # 只保留最近 N 份
  ls -1t "$BK_DIR"/*.sbk 2>/dev/null | tail -n +$((BK_KEEP + 1)) | xargs -r rm -f
  log_event BACKUP "$f"
  [[ $mode == manual ]] && ok "备份完成：$f"
  # 接入面板后上传一份（异地保存）
  if declare -F panel_backup_upload >/dev/null && [[ -n $(st .panel.url) ]]; then
    if panel_backup_upload "$f"; then
      [[ $mode == manual ]] && ok "已上传到面板"
    else
      alert "备份上传面板失败（本地备份已保存）"; return 1
    fi
  fi
  return 0
}

backup_list() {
  ls -1t "$BK_DIR"/*.sbk 2>/dev/null | while read -r f; do
    printf "  %s  %s\n" "$(du -h "$f" | cut -f1)" "$f"
  done
}

# 解密到目录：backup_decrypt 文件 目录 [密码]
backup_decrypt() {
  local f=$1 dir=$2 key=${3:-$(backup_key)} tmp
  tmp=$(mktemp)
  printf %s "$key" >"$tmp"
  mkdir -p "$dir"
  python3 "$SB_HOME/lib/backup_codec.py" extract "$f" "$dir" "$tmp" || { rm -f "$tmp"; return 1; }
  rm -f "$tmp"
  [[ -s $dir/etc/state.json ]] && jq -e .reality.private_key "$dir/etc/state.json" >/dev/null
}

# 恢复：节点参数保持不变，只把 IP 换成本机
backup_restore() {
  local f=$1 key=${2:-} mode=${3:-same-host} t
  [[ -f $f ]] || { err "文件不存在：$f"; return 1; }
  # 依次尝试：指定的密钥 → 本机密钥 → 手动输入
  local k ok_dec=0
  for k in "$key" "$(backup_key)" "$(cat "$ETC_DIR/backup.key" 2>/dev/null)"; do
    [[ -n $k ]] || continue
    t=$(mktemp -d)
    backup_decrypt "$f" "$t" "$k" && { ok_dec=1; break; }
    rm -rf "$t"
  done
  if ((!ok_dec)); then
    [[ -t 0 ]] || { err "解密失败：密钥不对或文件损坏"; return 1; }
    k=$(ask "解密失败，请输入来源 VPS 的备份密钥（在来源 VPS 上执行 sb backup key 查看）")
    t=$(mktemp -d)
    backup_decrypt "$f" "$t" "$k" || { rm -rf "$t"; err "解密失败，密钥不对或文件损坏"; return 1; }
  fi
  local s="$t/etc/state.json"
  echo "备份内容：节点 $(jq -r .node_name "$s")  原 IP $(jq -r .ip "$s")  用户 $(jq '.users|length' "$s") 个  层级 L$(jq -r .level "$s")"
  if [[ ${AUTO_YES:-0} != 1 ]]; then
    confirm "用这份备份覆盖本机当前配置？" n || { rm -rf "$t"; return 0; }
  fi
  # 先给当前配置做一份备份，以防恢复错了
  backup_create auto >/dev/null 2>&1 || warn "预备份未上传，请保留本地恢复快照"
  local local_panel; local_panel=$(jq -c '.panel // null' "$STATE")
  local restore_ip; restore_ip=$(get_ipv4) || { rm -rf "$t"; err "无法确认本机公网 IP，恢复未开始"; return 1; }
  valid_public_ipv4 "$restore_ip" || return 1
  if [[ $(jq -r .ip "$s") != "$restore_ip" && $(jq -r .l1.enabled "$s") == true && $mode != migrate ]]; then
    if [[ ! -t 0 || ${AUTO_YES:-0} == 1 ]] || ! confirm "跨机迁移会将备份中的域名 DNS 指向本机，原 VPS 将失去这些域名。确认迁移？" n; then
      rm -rf "$t"; err '跨机域名恢复需要明确 migrate 参数：sb backup restore 文件 密钥 migrate'; return 1
    fi
  fi
  # Keep this machine's identity. Source node must not overwrite its own reports remotely.
  jq --argjson p "$local_panel" '.panel=$p' "$s" >"$s.new" && mv "$s.new" "$s" || return 1
  for identity in panel.secret agent.json install.key backup.key backup-v2.key; do
    rm -f "$t/etc/$identity"
    [[ -f $ETC_DIR/$identity ]] && cp -p "$ETC_DIR/$identity" "$t/etc/$identity"
  done
  rm -rf "$t/etc/jobs"
  systemctl stop "$SVC_X" "$SVC_S" 2>/dev/null
  rm -rf "$ETC_DIR.old"; cp -a "$ETC_DIR" "$ETC_DIR.old"
  cp -a "$t/etc/." "$ETC_DIR/"
  [[ -d $t/acme ]] && { mkdir -p "$SB_HOME/acme"; cp -a "$t/acme/." "$SB_HOME/acme/"; }
  rm -rf "$t"
  chmod 700 "$ETC_DIR"; chmod 600 "$STATE"
  # 证书路径以本机安装目录为准；IP 换成本机
  st_set_str .ip "$restore_ip"
  write_units
  fetch_rulesets
  apply_config all || return 1
  declare -F install_timers >/dev/null && install_timers
  if [[ $(st .level) -ge 1 ]] && declare -F l1_after_restore >/dev/null; then l1_after_restore || return 1; fi
  if [[ -n $(panel_url) ]]; then panel_reapply || return 1; fi
  health_check all || return 1
  gen_outputs
  ok "恢复完成，节点参数与原 VPS 一致（IP 已改为本机 $(st .ip)）"
  log_event RESTORE "$f"
}

menu_backup() {
  while :; do
    clear
    title "备份 / 恢复"
    echo "本机备份（每天 03:30 自动，保留 $BK_KEEP 份）："
    backup_list
    echo
    echo "   ${C_BLU}1${C_RST}  立即备份"
    echo "   ${C_BLU}2${C_RST}  从本机备份文件恢复"
    echo "   ${C_BLU}3${C_RST}  从面板恢复本机备份（跨机备份由管理员下载后导入）"
    echo "   ${C_BLU}4${C_RST}  查看备份密钥（恢复别的 VPS 的备份时需要原密钥）"
    echo "   ${C_BLU}0${C_RST}  返回"
    case $(ask "选择" 0) in
      1) backup_create manual ;;
      2) backup_restore "$(ask "备份文件路径" "$(ls -1t "$BK_DIR"/*.sbk 2>/dev/null | head -1)")" ;;
      3) if declare -F panel_backup_restore >/dev/null && [[ -n $(st .panel.url) ]]; then panel_backup_restore
         else warn "尚未接入面板（主菜单 5）"; fi ;;
      4) echo "备份密钥：$(backup_key)"; warn "请妥善保管，不要发给别人" ;;
      0|"") return ;;
    esac
    pause
  done
}

cmd_backup() {
  case "${1:-}" in
    "") menu_backup ;;
    now) backup_create manual ;;
    list) backup_list ;;
    restore) backup_restore "$2" "${3:-}" "${4:-same-host}" ;;
    key) backup_key ;;
    *) echo "用法：sb backup [now|list|restore 文件 [密钥] [migrate]|key]" ;;
  esac
}
