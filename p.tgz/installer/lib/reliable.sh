#!/usr/bin/env bash
# Serialize mutations across CLI, timers and agent. Nested sb processes inherit fd 9.
with_lock() {
  local acquired=0 rc
  if [[ ${SB_LOCKED:-} != "$SB_HOME" ]] || ! { true >&9; } 2>/dev/null; then
    exec 9>"/run/${SB_NAME}.lock" || return 1
    flock -w 600 9 || { err "另一项操作仍在执行，请稍后重试"; return 75; }
    export SB_LOCKED="$SB_HOME"
    acquired=1
    if [[ -s $SB_HOME/.transaction.pending ]]; then
      local recovery; recovery=$(cat "$SB_HOME/.transaction.pending")
      if [[ $recovery == "$SB_HOME"/.transaction.* && -d $recovery ]]; then
        err "检测到中断操作，先恢复上次配置"
        if snapshot_restore "$recovery"; then rm -f "$SB_HOME/.transaction.pending"; rm -rf "$recovery"
        else flock -u 9; exec 9>&-; unset SB_LOCKED; return 1; fi
      else flock -u 9; exec 9>&-; unset SB_LOCKED; return 1; fi
    fi
  fi
  "$@"; rc=$?
  if ((acquired)); then flock -u 9; exec 9>&-; unset SB_LOCKED; fi
  return "$rc"
}

snapshot_copy() {
  cp -a -- "$1" "$2" && diff -qr --no-dereference -- "$1" "$2" >/dev/null
}

# Include empty directories and symlink targets as well as regular-file contents.
snapshot_paths() {
  find . ! -path ./checksums ! -path ./paths -printf '%y %p %l\0' | LC_ALL=C sort -z
}
snapshot_hashes() {
  find . -type f ! -path ./checksums -print0 | LC_ALL=C sort -z | xargs -0 sha256sum
}
snapshot_seal() (
  set -o pipefail
  cd "$1" && snapshot_paths >paths && snapshot_hashes >checksums
)
snapshot_valid() (
  set -o pipefail
  cd "$1" && snapshot_paths | cmp -s paths - && snapshot_hashes | cmp -s checksums -
)

snapshot_save() {
  local dst=$1 f
  [[ -s $STATE ]] || { err "缺少可恢复的节点状态"; return 1; }
  mkdir -p "$dst/etc" "$dst/units" || return 1
  tar -C "$ETC_DIR" --exclude=./jobs -cf - . | tar -C "$dst/etc" -xf - || return 1
  diff -qr --no-dereference --exclude=jobs "$ETC_DIR" "$dst/etc" >/dev/null || return 1
  if [[ -L $ETC_DIR/rules ]]; then
    rm "$dst/etc/rules" && cp -aL "$ETC_DIR/rules" "$dst/etc/rules" &&
      diff -qr "$ETC_DIR/rules/" "$dst/etc/rules/" >/dev/null || return 1
  fi
  for f in data certs; do
    [[ ! -L $SB_HOME/acme/$f ]] || { err "ACME 目录是符号链接，无法确认独立备份"; return 1; }
    [[ ! -d $SB_HOME/acme/$f ]] || snapshot_copy "$SB_HOME/acme/$f" "$dst/acme-$f" || return 1
  done
  for f in /etc/systemd/system/"${SB_NAME}"*.service /etc/systemd/system/"${SB_NAME}"*.timer; do
    [[ ! -L $f ]] || { err "服务文件是符号链接，无法确认独立备份"; return 1; }
    [[ ! -f $f ]] || snapshot_copy "$f" "$dst/units/${f##*/}" || return 1
  done
  local conf
  conf=$(NGINX_CONF) || return 1
  [[ ! -L $conf ]] || { err "nginx 配置是符号链接，无法确认独立备份"; return 1; }
  if [[ -f $conf ]]; then
    snapshot_copy "$conf" "$dst/nginx.conf" || return 1
    echo present >"$dst/nginx.state" || return 1
  else
    echo absent >"$dst/nginx.state" || return 1
  fi
  snapshot_seal "$dst"
}

snapshot_restore() {
  local src=$1 f
  [[ -d $src/etc && -d $src/units && $ETC_DIR == "$SB_HOME/etc" && $SB_HOME == /opt/* ]] || return 1
  snapshot_valid "$src" || { err "恢复快照不完整，保留当前配置"; return 1; }
  local staging
  staging=$(mktemp -d "$SB_HOME/.restore.XXXXXXXX") || return 1
  snapshot_copy "$src/etc" "$staging/etc" || { rm -rf "$staging"; return 1; }
  for f in data certs; do
    [[ ! -d $src/acme-$f ]] || snapshot_copy "$src/acme-$f" "$staging/acme-$f" || return 1
  done
  mv "$ETC_DIR" "$staging/live" || return 1
  if ! mv "$staging/etc" "$ETC_DIR"; then mv "$staging/live" "$ETC_DIR"; return 1; fi
  if [[ -d $staging/live/jobs ]]; then mv "$staging/live/jobs" "$ETC_DIR/jobs" || return 1; fi
  if [[ -s $staging/live/firewall.owned ]]; then
    cat "$staging/live/firewall.owned" >>"$ETC_DIR/firewall.owned" &&
      sort -u "$ETC_DIR/firewall.owned" -o "$ETC_DIR/firewall.owned" || return 1
  fi
  for f in "$src"/units/*; do
    [[ ! -f $f ]] || cp -a -- "$f" "/etc/systemd/system/${f##*/}" || return 1
  done
  for f in /etc/systemd/system/"${SB_NAME}"*.service /etc/systemd/system/"${SB_NAME}"*.timer; do
    [[ ! -f $f || -e $src/units/${f##*/} ]] || rm -f "$f" || return 1
  done
  case $(cat "$src/nginx.state") in
    present) cp -a "$src/nginx.conf" "$(NGINX_CONF)" || return 1 ;;
    absent) rm -f "$(NGINX_CONF)" || return 1 ;;
    *) return 1 ;;
  esac
  for f in data certs; do
    if [[ -e $SB_HOME/acme/$f ]]; then mv "$SB_HOME/acme/$f" "$staging/live-$f" || return 1; fi
    if [[ -d $src/acme-$f ]]; then
      mkdir -p "$SB_HOME/acme" || return 1
      if ! mv "$staging/acme-$f" "$SB_HOME/acme/$f"; then
        [[ ! -e $staging/live-$f ]] || mv "$staging/live-$f" "$SB_HOME/acme/$f"
        return 1
      fi
    fi
  done
  rm -f "$SB_HOME/.outputs.hash" && systemctl daemon-reload || return 1
  # Restore the previous validated configuration even when the external probe
  # destinations are unavailable; do not leave all future mutations locked out.
  SB_RESTORING=1 _raw_apply_config all || return 1
  rm -rf "$staging"
}

snapshot_unchanged() {
  local src=$1 f conf
  # 仅对完整快照做免回滚优化；测试替身或非完整目录保守视为已变更
  [[ -d $src/etc && -d $src/units && -f $src/nginx.state ]] || return 1
  diff -qr --no-dereference --exclude=jobs --exclude=rules "$ETC_DIR" "$src/etc" >/dev/null 2>&1 || return 1
  if [[ -d $src/etc/rules ]]; then
    diff -qr "$ETC_DIR/rules/" "$src/etc/rules/" >/dev/null 2>&1 || return 1
  elif [[ -e $ETC_DIR/rules ]]; then
    return 1
  fi
  for f in data certs; do
    if [[ -d $src/acme-$f ]]; then
      [[ -d $SB_HOME/acme/$f ]] && diff -qr --no-dereference "$SB_HOME/acme/$f" "$src/acme-$f" >/dev/null 2>&1 || return 1
    elif [[ -e $SB_HOME/acme/$f ]]; then
      return 1
    fi
  done
  for f in "$src"/units/*; do
    [[ -f $f ]] || continue
    cmp -s "$f" "/etc/systemd/system/${f##*/}" >/dev/null 2>&1 || return 1
  done
  for f in /etc/systemd/system/"${SB_NAME}"*.service /etc/systemd/system/"${SB_NAME}"*.timer; do
    [[ -f $f ]] || continue
    [[ -f $src/units/${f##*/} ]] || return 1
  done
  conf=$(NGINX_CONF) || return 1
  case $(cat "$src/nginx.state") in
    present) [[ -f $conf ]] && cmp -s "$conf" "$src/nginx.conf" >/dev/null 2>&1 || return 1 ;;
    absent) [[ ! -e $conf ]] || return 1 ;;
    *) return 1 ;;
  esac
  return 0
}

transaction() {
  if [[ ${SB_TRANSACTION:-} == 1 || ! -s $STATE ]]; then "$@"; return; fi
  local snap rc
  snap=$(mktemp -d "$SB_HOME/.transaction.XXXXXXXX") || return 1
  snapshot_save "$snap" || { rm -rf "$snap"; return 1; }
  printf '%s\n' "$snap" >"$SB_HOME/.transaction.pending" || { rm -rf "$snap"; return 1; }
  # Child commands (including certificate reload hooks) share this marker.
  local -x SB_TRANSACTION_RUNTIME="${SB_RUN_DIR:-$SB_HOME}/${snap##*/}.runtime"
  export SB_TRANSACTION=1
  "$@"; rc=$?
  unset SB_TRANSACTION
  local runtime_changed=0
  if [[ -e $SB_TRANSACTION_RUNTIME ]]; then runtime_changed=1; rm -f -- "$SB_TRANSACTION_RUNTIME"; fi
  unset SB_TRANSACTION_RUNTIME
  if ((rc)); then
    if ((!runtime_changed)) && snapshot_unchanged "$snap"; then
      rm -f "$SB_HOME/.transaction.pending"
      rm -rf "$snap"
      return "$rc"
    fi
    err "操作未完成，正在恢复变更前配置"
    if snapshot_restore "$snap"; then
      log_event ROLLBACK "配置恢复成功"
      rm -f "$SB_HOME/.transaction.pending"
      rm -rf "$snap"
    else
      alert "配置恢复失败，恢复快照保留在 $snap"
    fi
    return "$rc"
  fi
  rm -f "$SB_HOME/.transaction.pending"
  rm -rf "$snap"
}

guard_function() {
  local name=$1 mode=${2:-lock} def
  declare -F "$name" >/dev/null || return 0
  declare -F "_raw_$name" >/dev/null && return 0
  def=$(declare -f "$name")
  eval "${def/#$name /_raw_$name }"
  if [[ $mode == transaction ]]; then
    eval "$name() { with_lock transaction _raw_$name \"\$@\"; }"
  else
    eval "$name() { with_lock _raw_$name \"\$@\"; }"
  fi
}

certificate_transaction() {
  local kind=$1 fn=$2 dst rc pubcert pubkey oldkind; shift 2
  oldkind=$(jq -c '.l1.cdn_cert // null' "$STATE")
  dst=$(mktemp -d "$SB_RUN_DIR/cert.XXXXXX") || return 1
  cp -a "$CERT_DIR/." "$dst/" || return 1
  "$fn" "$@"; rc=$?
  if ((rc==0)); then
    pubcert=$(openssl x509 -in "$CERT_DIR/$kind.crt" -pubkey -noout 2>/dev/null)
    pubkey=$(openssl pkey -in "$CERT_DIR/$kind.key" -pubout 2>/dev/null)
    [[ -n $pubcert && $pubcert == "$pubkey" ]] && openssl x509 -in "$CERT_DIR/$kind.crt" -noout -checkend 0 >/dev/null 2>&1 || rc=1
  fi
  if ((rc)); then
    rm -f "$CERT_DIR/$kind.key" "$CERT_DIR/$kind.crt"
    cp -a "$dst/." "$CERT_DIR/" || return 1
    st_set .l1.cdn_cert "$oldkind"
    if [[ -s $dst/direct.crt ]]; then cert_reload >/dev/null 2>&1 || alert "原证书已恢复，但服务重载失败"; fi
    err "证书更换失败，已恢复原证书"
  fi
  rm -rf "$dst"
  return "$rc"
}
reliability_init() {
  local fn
  for fn in acme_issue_direct cdn_cert_issue; do
    if declare -F "$fn" >/dev/null && ! declare -F "_raw_$fn" >/dev/null; then
      guard_function "$fn"
      if [[ $fn == acme_issue_direct ]]; then
        acme_issue_direct() { with_lock certificate_transaction direct _raw_acme_issue_direct "$@"; }
      else
        cdn_cert_issue() { with_lock certificate_transaction cdn _raw_cdn_cert_issue "$@"; }
      fi
    fi
  done
  for fn in apply_config proto_set proto_apply_set user_add_cmd user_set_enabled user_del user_reset domain_setup domain_reapply backup_restore cert_cron; do guard_function "$fn" transaction; done
  # 菜单和命令分发不占锁；保护实际操作，避免停在菜单时阻塞定时上报。
  for fn in state_migrate state_init add_user user_sub_token traffic_tick record_result upd_defaults update_core update_geo self_update backup_create panel_join panel_reapply panel_remove panel_report panel_report_json gen_outputs health_check node_probe recorded_probe egress_refresh ip_watch cert_cron cert_reload do_uninstall do_install domain_remove domain_replace_token dns_sync rollback_core install_timers toggle bbr_enable time_sync welcome_install welcome_remove log_clean cmd_ip agent_exec self_post st_set st_set_str; do guard_function "$fn"; done
}
reliability_init
