#!/usr/bin/env bash
# L1 域名增强：CF DNS、ACME 真证书、CF Origin 证书、Reality 偷自己、CDN 线路、本地订阅、换 IP 自动更新 DNS
#
# 结构：
#   直连域名（灰云）d-xxx.<直连域>  → VPS：Reality 偷自己、Hy2-TLS、本地订阅
#   CDN 域名（橙云）c-xxx.<主域>     → CF → VPS:2053（nginx TLS）→ grpc_pass → Xray XHTTP
#   nginx 另在 127.0.0.1:<decoy_port> 提供伪装站（Reality 目标站），并提供订阅文件

CF_API=https://api.cloudflare.com/client/v4
CF_TOKEN_FILE="$ETC_DIR/cf.token"
ACME_HOME="$SB_HOME/acme"
WWW_DIR="$SB_HOME/www"
NGINX_CONF() { echo "/etc/nginx/conf.d/${SB_NAME}.conf"; }
CF_CDN_PORTS=(2053 2083 2087 2096 8443)

cf_token() { cat "$CF_TOKEN_FILE" 2>/dev/null; }

# cf_api 方法 路径 [JSON]  → 输出响应 JSON；success=false 时返回 1
cf_api() {
  local method=$1 path=$2 data=${3:-} out
  local args=(-4 -sS --max-time 30 -X "$method" -H "Authorization: Bearer $(cf_token)" -H "Content-Type: application/json")
  [[ -n $data ]] && args+=(--data "$data")
  out=$(curl "${args[@]}" "$CF_API$path") || return 1
  echo "$out"
  [[ $(jq -r .success <<<"$out" 2>/dev/null) == true ]]
}
cf_errmsg() { jq -r '[.errors[]?.message] | join("; ")' 2>/dev/null; }

cf_verify() {
  local r
  r=$(cf_api GET /user/tokens/verify) && [[ $(jq -r .result.status <<<"$r") == active ]]
}

cf_zone_id() {  # cf_zone_id 根域名
  local r
  r=$(cf_api GET "/zones?name=$1&status=active") || return 1
  jq -r '.result[0].id // empty' <<<"$r"
}

# 新建或更新 A 记录：cf_upsert_a 区域ID 主机名 IP proxied(true|false)
cf_upsert_a() {
  local z=$1 name=$2 ip=$3 px=$4 r id body
  body=$(jq -nc --arg n "$name" --arg ip "$ip" --argjson px "$px" \
    '{type:"A", name:$n, content:$ip, ttl:1, proxied:$px, comment:"managed by sb"}')
  r=$(cf_api GET "/zones/$z/dns_records?type=A&name=$name") || return 1
  id=$(jq -r '.result[0].id // empty' <<<"$r")
  if [[ -n $id ]]; then
    r=$(cf_api PUT "/zones/$z/dns_records/$id" "$body") || { err "更新 DNS 失败：$(cf_errmsg <<<"$r")"; return 1; }
  else
    r=$(cf_api POST "/zones/$z/dns_records" "$body") || { err "创建 DNS 失败：$(cf_errmsg <<<"$r")"; return 1; }
  fi
  # 只用 IPv4：删掉同名 AAAA
  r=$(cf_api GET "/zones/$z/dns_records?type=AAAA&name=$name") &&
    for id in $(jq -r '.result[].id' <<<"$r"); do cf_api DELETE "/zones/$z/dns_records/$id" >/dev/null; done
  return 0
}

cf_delete_record() {  # cf_delete_record 区域ID 主机名
  local r id
  r=$(cf_api GET "/zones/$1/dns_records?name=$2") || return 1
  for id in $(jq -r '.result[].id' <<<"$r"); do cf_api DELETE "/zones/$1/dns_records/$id" >/dev/null; done
}

# 把当前 IP 写到两条记录
dns_sync() {
  local ip; ip=$(st .ip)
  [[ -n $ip ]] || return 1
  local ok_all=0
  cf_upsert_a "$(st .l1.direct_zone_id)" "$(st .l1.direct_host)" "$ip" false || ok_all=1
  if [[ $(st .l1.cdn_enabled) == true ]]; then
    cf_upsert_a "$(st .l1.cdn_zone_id)" "$(st .l1.cdn_host)" "$ip" true || ok_all=1
  fi
  ((ok_all == 0)) && ok "DNS 已同步：$(st .l1.direct_host)$([[ $(st .l1.cdn_enabled) == true ]] && echo " / $(st .l1.cdn_host)") → $ip"
  return $ok_all
}

# ---------- acme.sh ----------
acme() { "$ACME_HOME/acme.sh" --home "$ACME_HOME" --config-home "$ACME_HOME/data" --cert-home "$ACME_HOME/certs" "$@"; }

acme_install() {
  [[ -x $ACME_HOME/acme.sh ]] && return 0
  local rel tag t
  info "安装 acme.sh ..."
  tag=$(jq -r .tag "$SB_HOME/lib/acme-release.json")
  local sha; sha=$(jq -r .sha256 "$SB_HOME/lib/acme-release.json")
  t=$(mktemp -d)
  dl_verify "https://codeload.github.com/acmesh-official/acme.sh/tar.gz/refs/tags/$tag" "$sha" "$t/a.tgz" || { rm -rf "$t"; return 1; }
  tar -xzf "$t/a.tgz" -C "$t" --strip-components=1
  (cd "$t" && ./acme.sh --install --nocron --no-profile --home "$ACME_HOME" \
     --config-home "$ACME_HOME/data" --cert-home "$ACME_HOME/certs" >/dev/null 2>&1) || { rm -rf "$t"; err "acme.sh 安装失败"; return 1; }
  rm -rf "$t"
  acme --set-default-ca --server letsencrypt >/dev/null 2>&1
  ok "acme.sh $tag 已安装"
}

# 申请直连域名证书（DNS-01，经 CF API）并安装到 etc/cert/direct.*
acme_issue_direct() {
  local host; host=$(st .l1.direct_host)
  info "申请证书：$host（Let's Encrypt，DNS 验证，约需 1 分钟）"
  if ! CF_Token=$(cf_token) CF_Zone_ID=$(st .l1.direct_zone_id) \
       acme --issue --dns dns_cf -d "$host" --keylength ec-256 --server letsencrypt >"$LOG_DIR/acme.log" 2>&1; then
    # 已有有效证书时 acme.sh 返回 2（跳过），视为成功
    grep -q -E "Skipping|Domains not changed" "$LOG_DIR/acme.log" || { err "证书申请失败，详见 $LOG_DIR/acme.log"; tail -n 5 "$LOG_DIR/acme.log" >&2; return 1; }
  fi
  acme --install-cert -d "$host" --ecc \
    --key-file "$CERT_DIR/direct.key" --fullchain-file "$CERT_DIR/direct.crt" \
    --reloadcmd "/usr/local/bin/sb cert-reload" >>"$LOG_DIR/acme.log" 2>&1 || return 1
  chmod 600 "$CERT_DIR/direct.key"
  ok "证书已安装：$host（到期 $(cert_end "$CERT_DIR/direct.crt")）"
}

# CDN 回源证书：优先 CF Origin CA（15 年），失败则用 ACME
cdn_cert_issue() {
  local host z csr r
  host=$(st .l1.cdn_host); z=$(st .l1.cdn_zone_id)
  openssl ecparam -genkey -name prime256v1 -out "$CERT_DIR/cdn.key" 2>/dev/null
  csr=$(openssl req -new -key "$CERT_DIR/cdn.key" -subj "/CN=$host" 2>/dev/null)
  r=$(cf_api POST /certificates "$(jq -nc --arg h "$host" --arg c "$csr" \
      '{hostnames:[$h], requested_validity:5475, request_type:"origin-ecc", csr:$c}')")
  if [[ $? -eq 0 ]] && jq -e .result.certificate <<<"$r" >/dev/null; then
    jq -r .result.certificate <<<"$r" >"$CERT_DIR/cdn.crt"
    chmod 600 "$CERT_DIR/cdn.key"
    st_set_str .l1.cdn_cert origin
    ok "CF Origin 证书已签发：$host（到期 $(cert_end "$CERT_DIR/cdn.crt")）"
    return 0
  fi
  warn "CF Origin 证书签发失败（Token 需要「SSL 和证书：编辑」权限）：$(cf_errmsg <<<"$r")，改用 ACME 证书"
  if CF_Token=$(cf_token) CF_Zone_ID=$z acme --issue --dns dns_cf -d "$host" --keylength ec-256 --server letsencrypt >"$SB_RUN_DIR/cdn-issue.log" 2>&1 ||
     grep -q Skipping "$SB_RUN_DIR/cdn-issue.log"; then
    acme --install-cert -d "$host" --ecc --key-file "$CERT_DIR/cdn.key" --fullchain-file "$CERT_DIR/cdn.crt" \
      --reloadcmd "/usr/local/bin/sb cert-reload" >>"$LOG_DIR/acme.log" 2>&1 || return 1
    st_set_str .l1.cdn_cert acme
    ok "CDN 证书（ACME）已安装：$host"
    return 0
  fi
  err "CDN 证书申请失败"; return 1
}

cert_end() { openssl x509 -noout -enddate -in "$1" 2>/dev/null | cut -d= -f2; }
cert_days() {  # 剩余天数
  local end; end=$(cert_end "$1"); [[ -n $end ]] || { echo -1; return; }
  echo $((($(date -d "$end" +%s) - $(date +%s)) / 86400))
}

# 证书续期后：平滑重载
cert_reload() {
  # 首次配置先安装证书，待完整配置生成后由 apply_config 启动服务。
  [[ $(st .l1.enabled) == true ]] || return 0
  nginx -t || return 1
  { systemctl reload nginx 2>/dev/null || systemctl restart nginx; } || return 1
  # sing-box 里用域名证书的线路：Hy2-TLS、TUIC（L1）、AnyTLS、Naive
  local k
  for k in hy2tls tuic anytls naive; do
    [[ $(proto_on "$k") == true ]] && { systemctl restart "$SVC_S" || return 1; break; }
  done
  log_event CERT "证书已续期并重载"
}

# 每天检查：续期、到期告警、CF Token 有效性
cert_cron() {
  [[ $(st .l1.enabled) == true ]] || return 0
  acme --cron >>"$LOG_DIR/acme.log" 2>&1 || { alert "证书续期执行失败，已保留原配置"; return 1; }
  local d
  d=$(cert_days "$CERT_DIR/direct.crt")
  ((d < 15)) && alert "直连证书 $(st .l1.direct_host) 只剩 $d 天且续期未成功，请检查 CF Token 和 $LOG_DIR/acme.log"
  if [[ -f $CERT_DIR/cdn.crt ]]; then
    d=$(cert_days "$CERT_DIR/cdn.crt")
    if [[ $(st .l1.cdn_cert) == origin ]]; then
      ((d < 30)) && alert "CF Origin 证书只剩 $d 天，请在菜单 4 重新签发"
    else
      ((d < 15)) && alert "CDN 证书只剩 $d 天且续期未成功"
    fi
  fi
  cf_verify || alert "CF API Token 已失效，证书续期和 DNS 自动更新将失败，请在菜单 4 更换"
}

# ---------- nginx ----------
nginx_install() {
  if ! command -v nginx >/dev/null; then
    info "安装 nginx ..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nginx >/dev/null || { err "nginx 安装失败"; return 1; }
    # 新装的 nginx：去掉默认站点（其中有 IPv6 监听）
    rm -f /etc/nginx/sites-enabled/default
    st_set .l1.nginx_ours true
  fi
  systemctl enable nginx >/dev/null 2>&1
}

# 伪装站点与订阅目录
www_init() {
  mkdir -p "$WWW_DIR/site" "$WWW_DIR/s"
  chmod 755 "$SB_HOME" "$WWW_DIR" "$WWW_DIR/site"
  chmod 711 "$WWW_DIR/s"   # 只能按精确路径访问，不能列目录
  [[ -f $WWW_DIR/site/index.html ]] && return
  cat >"$WWW_DIR/site/index.html" <<'EOF'
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Field Notes</title><style>body{font:16px/1.7 Georgia,serif;max-width:640px;margin:48px auto;padding:0 16px;color:#222;background:#fafaf7}
h1{font-weight:normal}a{color:#355}.d{color:#888;font-size:14px}</style></head><body>
<h1>Field Notes</h1><p class="d">Occasional writing about walking, maps and small towns.</p>
<h2>On reading old maps</h2><p class="d">March</p><p>Old survey maps reward patience. Contour lines drawn by hand carry the hesitations of the people who walked the ground.</p>
<h2>A winter route</h2><p class="d">January</p><p>The coastal path is quiet in winter. Most of the cafés are shut, which is half the point.</p>
</body></html>
EOF
  chmod 644 "$WWW_DIR/site/index.html"
}

nginx_apply() {
  local conf; conf=$(NGINX_CONF)
  local direct cdn dport cport cinner cpath
  direct=$(st .l1.direct_host); cdn=$(st .l1.cdn_host)
  dport=$(st .l1.decoy_port); cport=$(st .l1.cdn_port); cinner=$(st .l1.cdn_inner); cpath=$(st .l1.cdn_path)
  {
    echo "# 由 sb 生成，请勿手改"
    cat <<EOF
# 伪装站点（Reality 偷自己的目标站）+ 本地订阅；只监听本机，经 Reality 端口对外
server {
  listen 127.0.0.1:${dport} ssl http2;
  server_name ${direct};
  ssl_certificate ${CERT_DIR}/direct.crt;
  ssl_certificate_key ${CERT_DIR}/direct.key;
  ssl_protocols TLSv1.3;
  ssl_session_cache shared:${SB_NAME//-/_}_d:1m;
  access_log off;
  root ${WWW_DIR}/site;
  location ~ "^/s/(?<tok>[0-9a-f]{32})\$" {
    root ${WWW_DIR};
    default_type text/plain;
    add_header Cache-Control no-store;
    # Clash 系客户端返回 YAML，其余返回 base64 分享链接（if 里只用 rewrite break，安全）
    if (\$http_user_agent ~* "(?:clash|mihomo|flclash|stash|meta|verge)") { rewrite ^ /s/\$tok/clash.yaml break; }
    try_files /s/\$tok/v2ray.txt =404;
  }
  location / { try_files \$uri \$uri/ /index.html; }
}
EOF
    if [[ $(st .l1.cdn_enabled) == true ]]; then
      cat <<EOF
# CDN 回源（CF 橙云 → 本机 ${cport}）
server {
  listen 0.0.0.0:${cport} ssl http2;
  server_name ${cdn};
  ssl_certificate ${CERT_DIR}/cdn.crt;
  ssl_certificate_key ${CERT_DIR}/cdn.key;
  ssl_protocols TLSv1.2 TLSv1.3;
  access_log off;
  root ${WWW_DIR}/site;
  client_max_body_size 0;
  location ${cpath} {
    grpc_pass grpc://127.0.0.1:${cinner};
    grpc_set_header Host \$host;
    grpc_read_timeout 1h; grpc_send_timeout 1h;
    grpc_buffer_size 64k;
  }
  location ~ "^/s/(?<tok>[0-9a-f]{32})\$" {
    root ${WWW_DIR};
    default_type text/plain;
    add_header Cache-Control no-store;
    # Clash 系客户端返回 YAML，其余返回 base64 分享链接（if 里只用 rewrite break，安全）
    if (\$http_user_agent ~* "(?:clash|mihomo|flclash|stash|meta|verge)") { rewrite ^ /s/\$tok/clash.yaml break; }
    try_files /s/\$tok/v2ray.txt =404;
  }
  include ${ETC_DIR}/nginx-agent*.inc;
  location / { try_files \$uri \$uri/ /index.html; }
}
EOF
    fi
  } >"$conf.new"
  [[ -f $conf ]] && cp -a "$conf" "$SB_RUN_DIR/nginx.previous"
  mv -f "$conf.new" "$conf"
  if nginx -t >$SB_RUN_DIR/nginx.log 2>&1; then
    systemctl reload nginx 2>/dev/null || systemctl restart nginx
  else
    if [[ -f $SB_RUN_DIR/nginx.previous ]]; then cp -a "$SB_RUN_DIR/nginx.previous" "$conf"; else rm -f "$conf"; fi
    err "nginx 配置检查失败："; tail -n 5 $SB_RUN_DIR/nginx.log >&2; return 1
  fi
}

# ---------- 订阅 ----------
user_sub_token() {  # 没有就生成
  local name=$1 tok tmp
  tok=$(jq -r --arg n "$name" '.users[]|select(.name==$n)|.sub // empty' "$STATE")
  if [[ -z $tok ]]; then
    tok=$(rand_hex 16); tmp=$(mktemp)
    jq --arg n "$name" --arg t "$tok" '(.users[]|select(.name==$n)).sub = $t' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
    chmod 600 "$STATE"
  fi
  echo "$tok"
}

# 发布订阅文件（gen_outputs 之后调用）
sub_publish() {
  [[ $(st .l1.enabled) == true ]] || return 0
  local n tok stage
  stage=$(mktemp -d "$SB_HOME/.subs.XXXXXXXX") || return 1
  chmod 711 "$stage"
  while read -r n; do
    tok=$(user_sub_token "$n")
    mkdir -p "$stage/$tok"
    base64 -w0 "$OUT_DIR/$n.txt" >"$stage/$tok/v2ray.txt" && cp -f "$OUT_DIR/$n.yaml" "$stage/$tok/clash.yaml" || { rm -rf "$stage"; return 1; }
    chmod 755 "$stage/$tok"; chmod 644 "$stage/$tok"/*
  done < <(jq -r '.users[]|select(.enabled)|.name' "$STATE")
  switch_tree "$WWW_DIR/s" "$stage"
}

sub_urls() {
  local tok; tok=$(user_sub_token "${1:-default}")
  echo "${C_GRN}订阅地址（v2rayN / v2rayNG 添加订阅，FlClash 自动识别为 Clash 格式）：${C_RST}"
  echo "  直连：https://$(st .l1.direct_host):$(st .proto.vision.port)/s/$tok"
  [[ $(st .l1.cdn_enabled) == true ]] && echo "  CDN ：https://$(st .l1.cdn_host):$(st .l1.cdn_port)/s/$tok   （IP 被墙时也能更新）"
  [[ $(st .level) -ge 2 ]] && echo "  合并订阅（所有 VPS）请到面板查看"
}

# 隐藏输入（粘贴密钥用），去掉首尾空白
ask_secret() {
  local v
  read -r -s -p "$1: " v </dev/tty || true
  echo >&2
  printf '%s' "$v" | tr -d '[:space:]'
}

# 按编号选择域名：pick_zone 提示 默认值 域名...   （输出选中的域名）
pick_zone() {
  local prompt=$1 def=$2 i sel n; shift 2
  local list=("$@")
  if ((${#list[@]} == 0)); then
    ask "$prompt（输入域名）" "$def"; return
  fi
  echo "$prompt：" >&2
  for i in "${!list[@]}"; do
    printf "  %2d. %s\n" $((i + 1)) "${list[i]}" >&2
  done
  echo "   m. 手动输入" >&2
  local d=1
  if [[ -n $def ]]; then for i in "${!list[@]}"; do [[ ${list[i]} == "$def" ]] && d=$((i + 1)); done; fi
  while :; do
    sel=$(ask "编号" "$d")
    if [[ $sel == m ]]; then ask "域名"; return; fi
    if [[ $sel =~ ^[0-9]+$ ]] && ((sel >= 1 && sel <= ${#list[@]})); then echo "${list[sel - 1]}"; return; fi
    warn "请输入 1-${#list[@]} 之间的编号"
  done
}

# ---------- 升级向导 ----------
domain_setup() {
  title "添加域名（升级到 L1）"
  echo "需要："
  echo "  1. Cloudflare API Token（权限：区域-DNS-编辑、区域-区域-读取、区域-SSL 和证书-编辑）"
  echo "  2. 主域名（CDN 线路，橙云）和直连域名（灰云，可与主域名相同），都已托管在 Cloudflare"
  echo "已有节点保持不变；新增：Reality 偷自己、Hy2 真证书、CDN 备用线路、本地订阅、换 IP 自动改 DNS"
  echo
  # 非交互参数：--token-file 文件  --main 主域名  --direct 直连域名  --cdn-prefix x  --direct-prefix y
  local tok main="" direct="" cz dz pc="" pd="" tf=""
  while (($#)); do
    case $1 in
      --token-file) tf=$2; shift ;;
      --main) main=$2; shift ;;
      --direct) direct=$2; shift ;;
      --cdn-prefix) pc=$2; shift ;;
      --direct-prefix) pd=$2; shift ;;
    esac
    shift
  done
  if [[ -n $tf ]]; then
    local AUTO_YES=1   # 非交互：其余提问一律用默认值
    [[ -s $tf ]] || { err "Token 文件不存在：$tf"; return 1; }
    tr -d '[:space:]' <"$tf" >"$CF_TOKEN_FILE"; chmod 600 "$CF_TOKEN_FILE"
  fi
  if [[ -s $CF_TOKEN_FILE ]] && cf_verify; then
    ok "使用已保存的 CF Token（有效）"
  else
    [[ -n $tf ]] && { err "Token 无效或已过期"; return 1; }
    echo "请在下面粘贴 CF API Token：${C_YLW}鼠标右键粘贴，然后回车${C_RST}（为了安全，粘贴后屏幕不显示内容）"
    while :; do
      tok=$(ask_secret "Token")
      [[ -n $tok ]] || { warn "没有输入，已取消"; return 1; }
      info "已收到 ${#tok} 个字符，正在验证..."
      printf '%s' "$tok" >"$CF_TOKEN_FILE"; chmod 600 "$CF_TOKEN_FILE"
      cf_verify && { ok "Token 有效"; break; }
      err "Token 无效或已过期（常见原因：复制不完整、多复制了空格以外的字符），请重新粘贴"
    done
  fi
  # 列出 Token 能管理的域名，按编号选择
  local zones=()
  mapfile -t zones < <(cf_api GET "/zones?status=active&per_page=50" | jq -r '.result[].name' | sort)
  if [[ -z $main ]]; then
    main=$(pick_zone "选择主域名（CDN 线路和面板用，开橙云）" "" "${zones[@]}") || return 1
  fi
  cz=$(cf_zone_id "$main")
  [[ -n $cz ]] || { err "在 CF 里找不到 $main（确认状态为 Active，Token 有该区域权限）"; return 1; }
  if [[ -z $direct ]]; then
    if [[ ${AUTO_YES:-0} == 1 ]]; then direct=$main
    else direct=$(pick_zone "选择直连域名（Reality 偷自己、Hy2 真证书用，灰云；可与主域名相同）" "$main" "${zones[@]}") || return 1
    fi
  fi
  dz=$(cf_zone_id "$direct")
  [[ -n $dz ]] || { err "在 CF 里找不到 $direct"; return 1; }
  ok "主域名：$main   直连域名：$direct"
  [[ -n $pc ]] || pc=$(_ask "CDN 子域名前缀" "c-$(rand_str 4)")
  [[ -n $pd ]] || pd=$(_ask "直连子域名前缀" "d-$(rand_str 4)")
  pc=$(tr -cd 'a-z0-9-' <<<"${pc,,}"); pd=$(tr -cd 'a-z0-9-' <<<"${pd,,}")

  # CF SSL 模式检查（CDN 回源需要 Full 或 Full (strict)）
  local ssl
  ssl=$(cf_api GET "/zones/$cz/settings/ssl" | jq -r '.result.value // empty')
  if [[ $ssl == off || $ssl == flexible ]]; then
    warn "主域名的 CF SSL 模式是 $ssl，CDN 线路需要「完全」或「完全（严格）」"
    warn "请到 CF 控制台 → $main → SSL/TLS → 概述，改成「完全（严格）」后再继续"
    [[ -n $tf ]] && return 1
    confirm "已经改好了？" n || return 1
  fi

  # CDN 回源端口（CF 支持的 HTTPS 端口里找一个空闲的）
  local cport=""
  for p in "${CF_CDN_PORTS[@]}"; do port_busy tcp "$p" || [[ $p == "$(st .proto.xhttp.port)" ]] || { cport=$p; break; }; done
  [[ -n $cport ]] || { err "CF 支持的回源端口 ${CF_CDN_PORTS[*]} 都被占用"; return 1; }

  local tmp; tmp=$(mktemp)
  jq --arg cz "$cz" --arg dz "$dz" --arg ch "$pc.$main" --arg dh "$pd.$direct" --argjson cp "$cport" \
     --argjson dp "$(auto_port tcp "" 18443 18444 18445)" --argjson ci "$(auto_port tcp "" 18480 18481 18482)" \
     --arg path "/$(rand_str 12)" --argjson hp "$(auto_port udp "$(st .proto.hy2.port)" 8443 9443 7443 5443)" '
     .l1 = {enabled: false, cdn_zone: "", cdn_zone_id: $cz, direct_zone_id: $dz, cdn_host: $ch, direct_host: $dh,
            cdn_enabled: true, cdn_port: $cp, cdn_inner: $ci, cdn_path: $path, decoy_port: $dp,
            hy2tls_enabled: false, hy2tls_port: $hp, hop2: "50001-60000", cdn_cert: ""}' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
  chmod 600 "$STATE"
  domain_reapply full
}

# 部署 / 重新部署 L1（向导、重装、恢复后都用）
# domain_reapply [full]   full=重新签发证书
domain_reapply() {
  mkdir -p "$LOG_DIR"
  [[ -s $CF_TOKEN_FILE ]] || { err "缺少 CF Token"; return 1; }
  local public_ip; public_ip=$(get_ipv4) || return 1
  valid_public_ipv4 "$public_ip" || return 1
  st_set_str .ip "$public_ip"
  dns_sync || return 1
  nginx_install || return 1
  acme_install || return 1
  if [[ ${1:-} == full || ! -s $CERT_DIR/direct.crt ]]; then acme_issue_direct || return 1; fi
  if [[ $(st .l1.cdn_enabled) == true ]] && [[ ${1:-} == full || ! -s $CERT_DIR/cdn.crt ]]; then cdn_cert_issue || return 1; fi
  # acme.sh 的续期配置随备份恢复过来时，重新绑定安装路径
  if [[ ${1:-} != full ]]; then
    acme --install-cert -d "$(st .l1.direct_host)" --ecc \
    --key-file "$CERT_DIR/direct.key" --fullchain-file "$CERT_DIR/direct.crt" \
    --reloadcmd "/usr/local/bin/sb cert-reload" >>"$LOG_DIR/acme.log" 2>&1 || return 1
    if [[ $(st .l1.cdn_cert) == acme && $(st .l1.cdn_enabled) == true ]]; then
      acme --install-cert -d "$(st .l1.cdn_host)" --ecc \
        --key-file "$CERT_DIR/cdn.key" --fullchain-file "$CERT_DIR/cdn.crt" \
        --reloadcmd "/usr/local/bin/sb cert-reload" >>"$LOG_DIR/acme.log" 2>&1 || return 1
    fi
  fi
  www_init
  st_set .l1.enabled true
  [[ $(st .level) -lt 1 ]] && st_set .level 1
  write_timer cert "*-*-* 03:00:00 $TZ_PLAN" "cert renew"
  systemctl daemon-reload; systemctl enable --now "${SB_NAME}-cert.timer" >/dev/null 2>&1
  local rc=0
  apply_config all || rc=1
  if health_check all; then ok "健康检查通过：$HEALTH_MSG"; else warn "健康检查：$HEALTH_MSG"; rc=1; fi
  domain_check_cdn || rc=1
  if ((rc)); then
    warn "L1 已部署，但有检查未通过（见上面），修好后执行 sb domain reapply"
  else
    ok "已升级到 L1"
  fi
  if [[ -n $(panel_url) ]]; then agent_install || rc=1; fi
  egress_refresh
  show_nodes default
  sub_urls default
  return "$rc"
}
l1_after_restore() { domain_reapply; }

# 检查 CDN 线路是否通：从外部经 CF 访问伪装页
domain_check_cdn() {
  [[ $(st .l1.cdn_enabled) == true ]] || return 0
  local code i
  for i in 1 2 3 4 5 6; do
    code=$(curl -4 -s -o /dev/null -w '%{http_code}' --max-time 10 "https://$(st .l1.cdn_host):$(st .l1.cdn_port)/")
    [[ $code == 200 ]] && { ok "CDN 回源正常（https://$(st .l1.cdn_host):$(st .l1.cdn_port)）"; return 0; }
    sleep 10   # 新建 DNS 记录需要一点时间生效
  done
  warn "CDN 回源检查未通过（HTTP $code）。常见原因：CF SSL 模式不是「完全」、DNS 未生效（稍后用 sb domain check 再测）"
  return 1
}

# 降级回 L0
domain_remove() {
  [[ $(st .l1.enabled) == true ]] || return 0
  rm -f "$(NGINX_CONF)" "$ETC_DIR"/nginx-agent*.inc
  nginx -t >/dev/null 2>&1 && systemctl reload nginx 2>/dev/null
  systemctl disable --now "${SB_NAME}-cert.timer" >/dev/null 2>&1
  rm -f /etc/systemd/system/${SB_NAME}-cert.{timer,service}
  if [[ -s $CF_TOKEN_FILE ]] && confirm "同时删除 CF 上的两条 DNS 记录？" y; then
    cf_delete_record "$(st .l1.direct_zone_id)" "$(st .l1.direct_host)"
    cf_delete_record "$(st .l1.cdn_zone_id)" "$(st .l1.cdn_host)"
  fi
  st_set .l1.enabled false
  st_set .level 0
  [[ ${SB_UNINSTALL:-0} != 1 && -n $SB_HOME && -f $STATE ]] && apply_config all >/dev/null 2>&1
  ok "已移除域名功能（回到 L0，原有 IP 节点不变）"
}

domain_status() {
  [[ $(st .l1.enabled) == true ]] || return 0
  kv "直连域名" "$(st .l1.direct_host)  ${C_DIM}证书剩 $(cert_days "$CERT_DIR/direct.crt") 天${C_RST}"
  if [[ $(st .l1.cdn_enabled) == true ]]; then
    kv "CDN 域名" "$(st .l1.cdn_host):$(st .l1.cdn_port)  ${C_DIM}$([[ $(st .l1.cdn_cert) == origin ]] && echo Origin || echo ACME) 证书剩 $(cert_days "$CERT_DIR/cdn.crt") 天${C_RST}"
  fi
}

domain_replace_token() {
  cp -f "$CF_TOKEN_FILE" "$CF_TOKEN_FILE.bak" || return 1
  printf '%s' "$1" >"$CF_TOKEN_FILE"
  if cf_verify; then ok "Token 已更换"; rm -f "$CF_TOKEN_FILE.bak"
  else err "新 Token 无效，已恢复旧 Token"; mv -f "$CF_TOKEN_FILE.bak" "$CF_TOKEN_FILE"; return 1; fi
}

menu_domain() {
  if [[ $(st .l1.enabled) != true ]]; then
    domain_setup; pause; return
  fi
  while :; do
    clear
    title "域名（L1）"
    domain_status
    echo
    echo "   ${C_BLU}1${C_RST}  查看订阅地址"
    echo "   ${C_BLU}2${C_RST}  立即同步 DNS（IP 变化后会自动做）"
    echo "   ${C_BLU}3${C_RST}  检查 CDN 线路"
    echo "   ${C_BLU}4${C_RST}  立即续期 / 重新签发证书"
    echo "   ${C_BLU}5${C_RST}  CDN 线路             $(onoff "$(st .l1.cdn_enabled)")"
    echo "   ${C_BLU}6${C_RST}  Hy2-TLS（真证书）    $(onoff "$(st .l1.hy2tls_enabled)")"
    echo "   ${C_BLU}7${C_RST}  更换 CF API Token"
    echo "   ${C_BLU}8${C_RST}  移除域名功能（回到 L0）"
    echo "   ${C_BLU}0${C_RST}  返回"
    case $(ask "选择" 0) in
      1) sub_urls default ;;
      2) dns_sync ;;
      3) domain_check_cdn ;;
      4) acme_issue_direct; [[ $(st .l1.cdn_enabled) == true ]] && cdn_cert_issue; cert_reload ;;
      5) if [[ $(st .l1.cdn_enabled) == true && -n $(st .panel.url) ]]; then
           warn "面板靠 CDN 线路远程操作这台 VPS，关闭后面板只能看状态"
           confirm "仍要关闭？" n || { pause; continue; }
         fi
         proto_set cdn "$([[ $(st .l1.cdn_enabled) == true ]] && echo off || echo on)" ;;
      6) proto_set hy2tls "$([[ $(st .l1.hy2tls_enabled) == true ]] && echo off || echo on)" ;;
      7) local t; echo "右键粘贴新的 Token 后回车（屏幕不显示）"; t=$(ask_secret "Token")
         if [[ -n $t ]]; then
           domain_replace_token "$t"
         fi ;;
      8) confirm "确定移除域名功能？" n && domain_remove && { pause; return; } ;;
      0|"") return ;;
    esac
    pause
  done
}

cmd_domain() {
  case "${1:-}" in
    "") menu_domain ;;
    setup) shift; domain_setup "$@" ;;
    sync) dns_sync ;;
    check) domain_check_cdn ;;
    renew) cert_cron ;;
    reapply) domain_reapply "${2:-}" ;;
    remove) domain_remove ;;
    *) echo "用法：sb domain [setup|sync|check|renew|reapply|remove]" ;;
  esac
}
