#!/usr/bin/env bash
# L2 统一面板（CF Workers）对接：加入面板、定时上报、告警、备份上传、远程命令（agent）
#
# VPS → 面板：HTTPS 主动上报（每 5 分钟），HMAC 签名 + 时间戳 + nonce
# 面板 → VPS：CDN 域名回源端口的隐藏路径 → nginx → 127.0.0.1 上的 sbagent → sb agent-exec（白名单）
# 签名：hex(HMAC-SHA256(secret, METHOD\nPATH\nTS\nNONCE\nhex(SHA256(body))))

PANEL_SECRET="$ETC_DIR/panel.secret"
AGENT_BIN="$SB_HOME/bin/sbagent"
AGENT_CONF="$ETC_DIR/agent.json"
SVC_AGENT="${SB_NAME}-agent"

panel_url() { st .panel.url; }

# panel_req 方法 路径 [body文件]  → 输出响应体；HTTP 非 2xx 返回 1
panel_req() {
  local method=$1 path=$2 bf=${3:-} ts nonce bh sig out code
  [[ -n $bf ]] || { bf=$(mktemp); : >"$bf"; local tmpb=1; }
  ts=$(date +%s); nonce=$(rand_hex 16)
  bh=$(sha256sum "$bf" | cut -d' ' -f1)
  sig=$(printf '%s\n%s\n%s\n%s\n%s' "$method" "$path" "$ts" "$nonce" "$bh" |
    openssl dgst -sha256 -hmac "$(cat "$PANEL_SECRET")" -r | cut -d' ' -f1)
  out=$(mktemp)
  code=$(curl -4 -sS --max-time 60 -o "$out" -w '%{http_code}' -X "$method" \
    -H "X-Node: $(st .panel.node_id)" -H "X-Ts: $ts" -H "X-Nonce: $nonce" -H "X-Sig: $sig" \
    -H 'Content-Type: application/json' --data-binary "@$bf" "$(panel_url)$path")
  cat "$out"; rm -f "$out"; [[ ${tmpb:-0} == 1 ]] && rm -f "$bf"
  [[ $code == 2* ]]
}

# ---------- 上报内容 ----------
main_iface() { ip -4 route show default 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}'; }

panel_report_json() {
  local ifc rx=0 tx=0 mt ma load cpus up disk n
  ifc=$(main_iface)
  [[ -n $ifc ]] && { rx=$(cat /sys/class/net/$ifc/statistics/rx_bytes); tx=$(cat /sys/class/net/$ifc/statistics/tx_bytes); }
  mt=$(awk '/MemTotal/{print $2}' /proc/meminfo); ma=$(awk '/MemAvailable/{print $2}' /proc/meminfo)
  load=$(cut -d' ' -f1 /proc/loadavg); cpus=$(nproc); up=$(cut -d. -f1 /proc/uptime)
  disk=$(df -P / | awk 'NR==2{gsub("%","",$5); print $5}')
  # 机器基本信息（面板「VPS 信息」里自动显示）
  local os kern cpum dtot virt
  os=$(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-}")
  kern=$(uname -r); cpum=$(awk -F: '/model name/{gsub(/^[[:space:]]+/,"",$2); print $2; exit}' /proc/cpuinfo)
  dtot=$(df -P -B1 / | awk 'NR==2{print $2}'); virt=$(systemd-detect-virt 2>/dev/null || echo unknown)
  # 每个启用用户的链接与 mihomo 代理片段（面板合并订阅用）
  local subs="{}" tmp
  gen_outputs >/dev/null 2>&1 || return 1
  while read -r n; do
    local px names
    px=$(awk '/^proxies:/{f=1;next} /^proxy-groups:/{f=0} f' "$OUT_DIR/$n.yaml")
    subs=$(jq -c --arg n "$n" --rawfile l "$OUT_DIR/$n.txt" --arg px "$px" \
      '.[$n] = {links: ($l | split("\n") | map(select(length > 0))), px: $px}' <<<"$subs")
  done < <(jq -r '.users[]|select(.enabled)|.name' "$STATE")
  local agent_url=""
  if [[ $(st .l1.enabled) == true && $(st .l1.cdn_enabled) == true && -n $(st .panel.agent_path) ]]; then
    agent_url="https://$(st .l1.cdn_host):$(st .l1.cdn_port)$(st .panel.agent_path)"
  fi
  jq -n --slurpfile s "$STATE" --argjson subs "$subs" --arg ver "$(cat "$SB_HOME/VERSION" 2>/dev/null)" \
    --arg xa "$(systemctl is-active "$SVC_X")" --arg sa "$(systemctl is-active "$SVC_S")" \
    --argjson rx "$rx" --argjson tx "$tx" --argjson mt "${mt:-0}" --argjson ma "${ma:-0}" \
    --arg load "$load" --argjson cpus "$cpus" --argjson cpu "$(cpu_pct)" --argjson monthrx "$(jq -r --arg m "$(TZ=Asia/Shanghai date +%Y-%m)" '.mon[$m].rx // 0' "$TRAFFIC" 2>/dev/null || echo 0)" --argjson monthtx "$(jq -r --arg m "$(TZ=Asia/Shanghai date +%Y-%m)" '.mon[$m].tx // 0' "$TRAFFIC" 2>/dev/null || echo 0)" --argjson up "$up" --argjson disk "${disk:-0}" \
    --arg os "$os" --arg kern "$kern" --arg cpum "$cpum" --argjson dtot "${dtot:-0}" --arg virt "$virt" \
    --arg agent "$agent_url" --arg v6 "$(ipv6_status | sed 's/\x1b\[[0-9;]*m//g')" '
    $s[0] as $st | {
      name: $st.node_name, ip: $st.ip, level: $st.level, version: $ver, egress: ($st.egress // {}),
      cores: {xray: $st.core.xray, singbox: $st.core.singbox},
      services: {xray: $xa, singbox: $sa},
      metrics: {load: ($load|tonumber), cpus: $cpus, mem_total: ($mt*1024), mem_used: (($mt-$ma)*1024),
                disk_pct: $disk, rx: $rx, tx: $tx, uptime: $up, cpu_pct:$cpu, month_rx:$monthrx, month_tx:$monthtx},
      ipv6: $v6,
      sys: {os: $os, kernel: $kern, cpu: $cpum, disk_total: $dtot, virt: $virt},
      protos: {vision: $st.proto.vision, xhttp: $st.proto.xhttp, hy2: $st.proto.hy2,
               tuic: ($st.proto.tuic // {enabled: false}), anytls: ($st.proto.anytls // {enabled: false}),
               naive: ($st.proto.naive // {enabled: false}),
               cdn: ($st.l1.cdn_enabled // false), hy2tls: ($st.l1.hy2tls_enabled // false),
               hy2tls_port: ($st.l1.hy2tls_port // null), cdn_port: ($st.l1.cdn_port // null),
               l1: ($st.l1.enabled // false)},
      block: $st.block,
      l1: (if ($st.l1.enabled // false) then {direct_host: $st.l1.direct_host, cdn_host: $st.l1.cdn_host, cdn_port: $st.l1.cdn_port} else null end),
      upd: ($st.upd // {}),
      users: [$st.users[] | {name, enabled}],
      subs: $subs,
      agent_url: $agent
    }'
}

panel_report() {
  [[ -n $(panel_url) && -s $PANEL_SECRET ]] || return 0
  local f; f=$(mktemp)
  panel_report_json >"$f" || { rm -f "$f"; return 1; }
  if panel_req POST /api/agent/report "$f" >/dev/null; then rm -f "$f"; return 0; fi
  rm -f "$f"; log_event PANEL "上报失败"; return 1
}

panel_alert() {
  [[ -n $(panel_url) && -s $PANEL_SECRET ]] || return 1
  local f; f=$(mktemp)
  jq -nc --arg m "$1" '{msg:$m}' >"$f"
  panel_req POST /api/agent/alert "$f" >/dev/null; local rc=$?
  rm -f "$f"; return $rc
}

panel_backup_upload() {
  local f=$1 b; b=$(mktemp)
  jq -nc --arg name "$(basename "$f")" --rawfile d <(base64 -w0 "$f") '{name:$name, data:$d}' >"$b"
  panel_req POST /api/agent/backup "$b" >/dev/null; local rc=$?
  rm -f "$b"; return $rc
}

panel_backup_restore() {
  local list ids i sel id f
  list=$(panel_req GET /api/agent/backups) || { err "获取面板备份列表失败"; return 1; }
  mapfile -t ids < <(jq -r '.backups[].id' <<<"$list")
  ((${#ids[@]})) || { warn "面板上还没有备份"; return 1; }
  jq -r '.backups | to_entries[] | "  \(.key+1). \(.value.node)  \(.value.name)  \(.value.created)"' <<<"$list"
  sel=$(ask "选择要恢复的备份" 1)
  [[ $sel =~ ^[0-9]+$ ]] && ((sel >= 1 && sel <= ${#ids[@]})) || return 1
  id=${ids[sel - 1]}
  f=$(mktemp --suffix=.sbk)
  panel_req GET "/api/agent/backup/$id" | jq -r .data | base64 -d >"$f" || { err "下载失败"; rm -f "$f"; return 1; }
  backup_restore "$f"
  rm -f "$f"
}

# ---------- agent ----------
agent_install() {
  local src="$SB_HOME/agent/sbagent-$ARCH" port
  [[ -x $src || -f $src ]] || { err "缺少 agent 程序 $src"; return 1; }
  local sum0; sum0=$(cat "$AGENT_BIN" "$AGENT_CONF" /etc/systemd/system/${SVC_AGENT}.service 2>/dev/null | sha256sum)
  install -m 755 "$src" "$AGENT_BIN.new" && mv -f "$AGENT_BIN.new" "$AGENT_BIN" || return 1
  port=$(st .panel.agent_port)
  [[ -n $port ]] || { port=$(auto_port tcp "" 18490 18491 18492 18493); st_set .panel.agent_port "$port"; }
  [[ -n $(st .panel.agent_path) ]] || st_set_str .panel.agent_path "/$(rand_str 20)"
  jq -n --arg l "127.0.0.1:$port" --arg s "$PANEL_SECRET" '{listen:$l, secret_file:$s, sb:"/usr/local/bin/sb"}' >"$AGENT_CONF"
  chmod 600 "$AGENT_CONF"
  cat >/etc/systemd/system/${SVC_AGENT}.service <<EOF
[Unit]
Description=${SB_NAME} agent
After=network-online.target

[Service]
ExecStart=${AGENT_BIN} -c ${AGENT_CONF}
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable "$SVC_AGENT" >/dev/null 2>&1
  # 没变化就不重启：面板发来的命令就运行在 agent 里，重启会把正在执行的命令一起杀掉
  if [[ $(cat "$AGENT_BIN" "$AGENT_CONF" /etc/systemd/system/${SVC_AGENT}.service | sha256sum) != "$sum0" ]] ||
     ! systemctl is-active -q "$SVC_AGENT"; then
    systemctl restart "$SVC_AGENT"
  fi
  # nginx 隐藏路径（需要 L1 的 CDN 线路）
  if [[ $(st .l1.enabled) == true ]]; then
    cat >"$ETC_DIR/nginx-agent.inc" <<EOF
location $(st .panel.agent_path)/ {
  proxy_pass http://127.0.0.1:${port}/;
  proxy_read_timeout 660s;
  proxy_set_header X-Real-IP \$remote_addr;
}
EOF
    nginx_apply >/dev/null || return 1
  fi
  sleep 1
  systemctl is-active -q "$SVC_AGENT" && ok "agent 运行中" || { err "agent 启动失败"; journalctl -u "$SVC_AGENT" -n 10 --no-pager; return 1; }
}

# 加入面板：sb panel join <面板地址> <加入码>
panel_join() {
  local url=${1%/} code=$2 f r
  [[ $url == https://* && -n $code ]] || { err "用法：sb panel join https://面板地址 加入码"; return 1; }
  f=$(mktemp)
  jq -nc --arg c "$code" --arg n "$(st .node_name)" --arg ip "$(st .ip)" --arg h "$(hostname)" \
    '{code:$c, name:$n, ip:$ip, hostname:$h}' >"$f"
  r=$(curl -4 -sS --max-time 30 -H 'Content-Type: application/json' --data-binary "@$f" "$url/api/agent/join")
  rm -f "$f"
  if [[ $(jq -r '.node_id // empty' <<<"$r") == "" ]]; then
    err "加入失败：$(jq -r '.error // .' <<<"$r" 2>/dev/null | head -c 200)"; return 1
  fi
  jq -r .secret <<<"$r" >"$PANEL_SECRET"; chmod 600 "$PANEL_SECRET"
  st_set_str .panel.url "$url"
  st_set_str .panel.node_id "$(jq -r .node_id <<<"$r")"
  panel_reapply || { err "面板注册已完成，但接入配置未完成；修复后执行 sb panel reapply，无需重新生成加入码"; return 1; }
  ok "已接入面板：$url"
  [[ $(st .l1.enabled) == true ]] || warn "尚未升级到 L1：面板只能看状态，无法远程操作（远程操作经 CDN 线路回源）"
}

panel_reapply() {
  [[ -n $(panel_url) && -s $PANEL_SECRET ]] || return 0
  agent_install || { err "面板 agent 配置或启动失败"; return 1; }
  write_timer report "*:0/5" "panel report" 20 || { err "定时上报配置写入失败"; return 1; }
  systemctl daemon-reload || return 1
  systemctl enable --now "${SB_NAME}-report.timer" >/dev/null 2>&1 || { err "定时上报启动失败"; return 1; }
  [[ $(st .level) -lt 2 ]] && st_set .level 2
  panel_report || { err "首次上报失败，请检查面板地址与网络"; return 1; }
  ok "已上报到面板"
  backup_create auto >/dev/null 2>&1 || warn "已接入，但首次备份失败，可稍后执行 sb backup now 重试"
  return 0
}

panel_remove() {
  systemctl disable --now "${SB_NAME}-report.timer" >/dev/null 2>&1
  systemctl disable --now "$SVC_AGENT" >/dev/null 2>&1
  rm -f /etc/systemd/system/${SB_NAME}-report.{timer,service} /etc/systemd/system/${SVC_AGENT}.service
  rm -f "$ETC_DIR/nginx-agent.inc" "$AGENT_CONF" "$PANEL_SECRET" "$AGENT_BIN"
  systemctl daemon-reload
  [[ $(st .l1.enabled) == true ]] && nginx_apply >/dev/null 2>&1
  st_set .panel null 2>/dev/null
  [[ $(st .level) -ge 2 ]] && st_set .level "$([[ $(st .l1.enabled) == true ]] && echo 1 || echo 0)"
  ok "已退出面板"
}

# ---------- 远程命令（只由 agent 调用） ----------
# sb agent-exec <命令> [参数...]   命令白名单在这里，agent 只做签名校验
agent_exec() {
  local c=${1:-} a=${2:-} b=${3:-} rc=""
  shift || true
  export AUTO_YES=1
  case $c in
    report) panel_report_json ;;
    status) cmd_status | sed 's/\x1b\[[0-9;]*m//g' ;;
    health) health_check all; rc=$?; echo "$HEALTH_MSG" ;;
    probe) local pr; pr=$(node_probe "$([[ $a == speed ]] && echo speed)"); rc=$?
           echo "$pr"; egress_refresh "$pr" >/dev/null 2>&1 ;;
    restart) case $a in x|s) restart_core "$a" ;; all) apply_config all ;; *) rc=2 ;; esac ;;
    update) case $a in
              x|s) if [[ $b == force ]]; then update_core "$a" --force; else update_core "$a"; fi ;;
              geo) update_geo ;;
              # 放到独立的 systemd 单元里跑：更新过程中 agent 可能被重启，不能连带杀掉更新
              self) /usr/local/bin/sb update self ;;
              *) rc=2 ;;
            esac ;;
    rollback) [[ $a == x || $a == s ]] && rollback_core "$a" "$(cat "$PREV_DIR/$(basename "$(core_bin "$a")").version" 2>/dev/null)" || rc=2 ;;
    logs) case $a in
            x) journalctl -u "$SVC_X" -n 100 --no-pager ;;
            s) journalctl -u "$SVC_S" -n 100 --no-pager ;;
            agent) journalctl -u "$SVC_AGENT" -n 100 --no-pager ;;
            *) tail -n 100 "$SB_HOME/log/events.log" 2>/dev/null ;;
          esac ;;
    proto)
      # 关掉 CDN 线路后面板就连不上这台 VPS 了，只允许在 VPS 上操作
      [[ $a == cdn && $b == off ]] && { echo "面板靠 CDN 线路远程操作这台 VPS，不能在面板里关闭（需要时在 VPS 上 sb → 4 关闭）"; return 2; }
      case $a in
        blockcn|blockbt)
          [[ $b == on || $b == off ]] || { echo "参数错误"; return 2; }
          st_set "$(proto_path "$a")" "$([[ $b == on ]] && echo true || echo false)"; apply_config all ;;
        *) proto_set "$a" "$b" ;;
      esac ;;
    # 面板「协议」勾选后一次应用：protoset vision.hy2.tuic（列出要开启的线路，其余关闭）
    protoset)
      [[ $a =~ ^[a-z0-9.]*$ ]] || { echo "参数错误"; return 2; }
      [[ $(st .l1.enabled) == true && $(st .l1.cdn_enabled) == true && ".$a." != *".cdn."* ]] &&
        { echo "面板靠 CDN 线路远程操作这台 VPS，不能在面板里关闭（需要时在 VPS 上 sb → 4 关闭）"; return 2; }
      proto_apply_set "$a" ;;
    user)
      [[ $b =~ ^[A-Za-z0-9_-]{1,20}$ ]] || { echo "用户名不合法"; return 2; }
      case $a in
        sync-enabled|sync-disabled)
          user_exists "$b" || add_user "$b" || return 1
          user_set_enabled "$b" "$([[ $a == sync-enabled ]] && echo true || echo false)" ;;
        add) user_exists "$b" && user_set_enabled "$b" true || user_add_cmd "$b" >/dev/null ;;
        disable) user_set_enabled "$b" false ;; enable) user_set_enabled "$b" true ;;
        del) if user_exists "$b"; then user_del "$b"; else return 0; fi ;; reset) user_reset "$b" >/dev/null ;;
        *) rc=2 ;;
      esac ;;
    updset)
      case $a in
        xray|singbox|geo|self) [[ $b == on || $b == off ]] && st_set ".upd.$a.enabled" "$([[ $b == on ]] && echo true || echo false)" && install_timers ;;
        cooldown) [[ $b =~ ^[0-9]+$ ]] && ((b <= 30)) && st_set .upd.cooldown "$b" ;;
        *) rc=2 ;;
      esac ;;
    backup) backup_create manual ;;
    *) echo "未知命令：$c"; return 2 ;;
  esac
  local last=$?
  [[ -n $rc ]] || rc=$last
  # 状态有变化的命令执行完后立即上报，面板马上能看到
  case $c in proto|protoset|user|updset|restart|update|rollback) panel_report >/dev/null 2>&1 ;; esac
  return $rc
}

menu_panel() {
  while :; do
    clear
    title "面板（L2）"
    if [[ -n $(panel_url) ]]; then
      echo "面板：$(panel_url)   节点 ID：$(st .panel.node_id)"
      echo "agent：$(systemctl is-active "$SVC_AGENT")   远程操作：$([[ $(st .l1.enabled) == true ]] && echo 可用 || echo 不可用（需 L1 CDN 线路）)"
      echo
      echo "   ${C_BLU}1${C_RST}  立即上报   2. 重新部署 agent   3. 退出面板   0. 返回"
      case $(ask "选择" 0) in
        1) panel_report && ok "已上报" ;;
        2) panel_reapply ;;
        3) confirm "确定退出面板？" n && panel_remove ;;
        0|"") return ;;
      esac
    else
      echo "还没有接入面板。"
      echo "先按教程部署 Worker 面板，在面板「VPS」页点「添加 VPS」，复制加入命令到这里执行，"
      echo "或在下面直接填写："
      local u c
      u=$(ask "面板地址（https://...，留空返回）")
      [[ -n $u ]] || return
      c=$(ask "加入码")
      panel_join "$u" "$c"
    fi
    pause
  done
}

cmd_panel() {
  case "${1:-}" in
    "") menu_panel ;;
    join) panel_join "${2:-}" "${3:-}" ;;
    report) panel_report && ok "已上报" ;;
    json) panel_report_json ;;
    reapply) panel_reapply ;;
    leave) panel_remove ;;
    *) echo "用法：sb panel [join 地址 加入码|report|json|reapply|leave]" ;;
  esac
}
