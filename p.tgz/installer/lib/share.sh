#!/usr/bin/env bash
# 分享层：节点链接、二维码、mihomo(FlClash) 配置、临时订阅

# 输出某个用户的全部分享链接，一行一个：user_links <用户名>
user_links() {
  local name=$1 ip node uuid pass sni pbk sid tag
  ip=$(st .ip); node=$(st .node_name); sni=$(st .reality.sni)
  pbk=$(st .reality.public_key); sid=$(st .reality.short_id)
  uuid=$(jq -r --arg n "$name" '.users[]|select(.name==$n)|.uuid' "$STATE")
  pass=$(jq -r --arg n "$name" '.users[]|select(.name==$n)|.hy2' "$STATE")
  tag="${node}"; [[ $name != default ]] && tag="${node}-${name}"
  # 实测出口 IP 与 VPS IP 不同的线路才加 -IPchange（见 egress_refresh）
  _sfx() { local e; e=$(st ".egress.$1"); [[ -n $e && $e != "$(st .ip)" ]] && echo "-IPchange"; }
  # L1：地址改用直连域名（换 IP 后 DNS 自动更新，客户端无需重新导入）；Reality 偷自己
  local L1=0 dh=""
  if [[ $(st .l1.enabled) == true ]]; then L1=1; dh=$(st .l1.direct_host); ip=$dh; sni=$dh; fi
  if [[ $(st .proto.vision.enabled) == true ]]; then
    echo "vless://${uuid}@${ip}:$(st .proto.vision.port)?encryption=none&flow=xtls-rprx-vision&security=reality&sni=${sni}&fp=chrome&pbk=${pbk}&sid=${sid}&type=tcp&headerType=none#$(urlencode "${tag}-vless-reality-Vision$(_sfx vision)")"
  fi
  if [[ $(st .proto.xhttp.enabled) == true ]]; then
    echo "vless://${uuid}@${ip}:$(st .proto.xhttp.port)?encryption=none&security=reality&sni=${sni}&fp=chrome&pbk=${pbk}&sid=${sid}&type=xhttp&path=$(urlencode "$(st .xhttp_path)")&mode=auto#$(urlencode "${tag}-vless-reality-XHTTP$(_sfx xhttp)")"
  fi
  if [[ $(st .proto.hy2.enabled) == true ]]; then
    local mport=""
    [[ $(st .proto.hy2.hop_enabled) == true ]] && mport="&mport=$(st .proto.hy2.hop)"
    echo "hysteria2://${pass}@${ip}:$(st .proto.hy2.port)?sni=$(st .hy2.sni)&alpn=h3&insecure=1&pinSHA256=$(st .hy2.pin)${mport}#$(urlencode "${tag}-hysteria2$(_sfx hy2)")"
  fi
  # TUIC：L1 用域名真证书；L0 用自签证书（客户端需跳过证书校验）
  if [[ $(proto_on tuic) == true ]]; then
    local tsni tins=""
    if ((L1)); then tsni=$dh; else tsni=$(st .hy2.sni); tins="&allow_insecure=1&insecure=1&pinSHA256=$(st .hy2.pin)"; fi
    echo "tuic://${uuid}:${pass}@${ip}:$(st .proto.tuic.port)?congestion_control=bbr&udp_relay_mode=native&alpn=h3&sni=${tsni}${tins}#$(urlencode "${tag}-tuic$(_sfx tuic)")"
  fi
  ((L1)) || return 0
  if [[ $(proto_on anytls) == true ]]; then
    echo "anytls://${pass}@${dh}:$(st .proto.anytls.port)?security=tls&sni=${dh}&fp=chrome&type=tcp#$(urlencode "${tag}-anytls$(_sfx anytls)")"
  fi
  if [[ $(proto_on naive) == true ]]; then
    echo "naive+https://$(urlencode "$name"):${pass}@${dh}:$(st .proto.naive.port)?padding=true#$(urlencode "${tag}-naive$(_sfx naive)")"
  fi
  if [[ $(st .l1.hy2tls_enabled) == true ]]; then
    local mp2=""; [[ -n $(st .l1.hop2) ]] && mp2="&mport=$(st .l1.hop2)"
    echo "hysteria2://${pass}@${dh}:$(st .l1.hy2tls_port)?sni=${dh}&alpn=h3${mp2}#$(urlencode "${tag}-hysteria2-TLS$(_sfx hy2tls)")"
  fi
  if [[ $(st .l1.cdn_enabled) == true ]]; then
    local ch; ch=$(st .l1.cdn_host)
    echo "vless://${uuid}@${ch}:$(st .l1.cdn_port)?encryption=none&security=tls&sni=${ch}&host=${ch}&fp=chrome&alpn=h2&type=xhttp&path=$(urlencode "$(st .l1.cdn_path)")&mode=auto#$(urlencode "${tag}-vless-xhttp-CDN$(_sfx cdn)")"
  fi
}

# 生成 mihomo / FlClash 配置：user_mihomo <用户名> > file
user_mihomo() {
  local name=$1
  jq -rn --slurpfile s "$STATE" --arg n "$name" '
    $s[0] as $st
    | ($st.users[] | select(.name == $n)) as $u
    | (if $n == "default" then $st.node_name else $st.node_name + "-" + $n end) as $tag
    | def sfx($k): (($st.egress // {})[$k] // "") as $e | if $e != "" and $e != $st.ip then "-IPchange" else "" end;
    ($st.l1 // {}) as $l1
    | ($l1.enabled == true) as $L1
    | (if $L1 then $l1.direct_host else $st.ip end) as $addr
    | (if $L1 then $l1.direct_host else $st.reality.sni end) as $rsni
    | def q: tojson;   # JSON 字符串即合法 YAML 字符串
    [
      (if $st.proto.vision.enabled then
"  - name: \(($tag + "-vless-reality-Vision" + sfx("vision"))|q)
    type: vless
    server: \($addr)
    port: \($st.proto.vision.port)
    uuid: \($u.uuid)
    network: tcp
    udp: true
    tls: true
    flow: xtls-rprx-vision
    servername: \($rsni)
    client-fingerprint: chrome
    reality-opts:
      public-key: \($st.reality.public_key|q)
      short-id: \($st.reality.short_id|q)" else empty end),
      (if $st.proto.xhttp.enabled then
"  - name: \(($tag + "-vless-reality-XHTTP" + sfx("xhttp"))|q)
    type: vless
    server: \($addr)
    port: \($st.proto.xhttp.port)
    uuid: \($u.uuid)
    network: xhttp
    udp: true
    tls: true
    servername: \($rsni)
    client-fingerprint: chrome
    reality-opts:
      public-key: \($st.reality.public_key|q)
      short-id: \($st.reality.short_id|q)
    xhttp-opts:
      path: \($st.xhttp_path|q)
      mode: auto" else empty end),
      (if $st.proto.hy2.enabled then
"  - name: \(($tag + "-hysteria2" + sfx("hy2"))|q)
    type: hysteria2
    server: \($addr)
    port: \($st.proto.hy2.port)" +
        (if $st.proto.hy2.hop_enabled then "\n    ports: \($st.proto.hy2.hop|q)" else "" end) +
"
    password: \($u.hy2|q)
    sni: \($st.hy2.sni)
    alpn: [h3]
    skip-cert-verify: true
    fingerprint: \($st.hy2.pin|q)" else empty end),
      (if $L1 and ($st.proto.tuic.enabled // false) and $st.proto.tuic.port != null then
"  - name: \(($tag + "-tuic" + sfx("tuic"))|q)
    type: tuic
    server: \($addr)
    port: \($st.proto.tuic.port)
    uuid: \($u.uuid)
    password: \($u.hy2|q)
    alpn: [h3]
    congestion-controller: bbr
    udp-relay-mode: native
    reduce-rtt: false
    sni: \(if $L1 then $l1.direct_host else $st.hy2.sni end)" +
        (if $L1 then "" else "
    skip-cert-verify: true
    fingerprint: \($st.hy2.pin|q)" end) else empty end),
      (if $L1 and ($st.proto.anytls.enabled // false) and $st.proto.anytls.port != null then
"  - name: \(($tag + "-anytls" + sfx("anytls"))|q)
    type: anytls
    server: \($l1.direct_host)
    port: \($st.proto.anytls.port)
    password: \($u.hy2|q)
    client-fingerprint: chrome
    udp: true
    sni: \($l1.direct_host)" else empty end),
      (if $L1 and $l1.hy2tls_enabled then
"  - name: \(($tag + "-hysteria2-TLS" + sfx("hy2tls"))|q)
    type: hysteria2
    server: \($l1.direct_host)
    port: \($l1.hy2tls_port)" +
        (if ($l1.hop2 // "") != "" then "\n    ports: \($l1.hop2|q)" else "" end) +
"
    password: \($u.hy2|q)
    sni: \($l1.direct_host)
    alpn: [h3]" else empty end),
      (if $L1 and $l1.cdn_enabled then
"  - name: \(($tag + "-vless-xhttp-CDN" + sfx("cdn"))|q)
    type: vless
    server: \($l1.cdn_host)
    port: \($l1.cdn_port)
    uuid: \($u.uuid)
    network: xhttp
    udp: true
    tls: true
    servername: \($l1.cdn_host)
    client-fingerprint: chrome
    alpn: [h2]
    xhttp-opts:
      path: \($l1.cdn_path|q)
      host: \($l1.cdn_host|q)
      mode: auto" else empty end)
    ] as $px
    | [
      ($st.proto.vision.enabled | if . then $tag + "-vless-reality-Vision" + sfx("vision") else empty end),
      ($st.proto.xhttp.enabled  | if . then $tag + "-vless-reality-XHTTP" + sfx("xhttp")  else empty end),
      ($st.proto.hy2.enabled    | if . then $tag + "-hysteria2" + sfx("hy2")    else empty end),
      (if $L1 and ($st.proto.tuic.enabled // false) and $st.proto.tuic.port != null then $tag + "-tuic" + sfx("tuic") else empty end),
      (if $L1 and ($st.proto.anytls.enabled // false) and $st.proto.anytls.port != null then $tag + "-anytls" + sfx("anytls") else empty end),
      (if $L1 and $l1.hy2tls_enabled then $tag + "-hysteria2-TLS" + sfx("hy2tls") else empty end),
      (if $L1 and $l1.cdn_enabled then $tag + "-vless-xhttp-CDN" + sfx("cdn") else empty end)
    ] as $names
    | ($names | map("      - " + q) | join("\n")) as $list
    | "mixed-port: 7890
allow-lan: false
mode: rule
log-level: warning
ipv6: false
unified-delay: true
geodata-mode: true
geo-auto-update: true
geo-update-interval: 72
geox-url:
  geoip: \"https://cdn.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geoip.dat\"
  geosite: \"https://cdn.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geosite.dat\"
  mmdb: \"https://cdn.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/country.mmdb\"
dns:
  enable: true
  ipv6: false
  enhanced-mode: fake-ip
  fake-ip-range: 198.18.0.1/16
  default-nameserver: [223.5.5.5, 119.29.29.29]
  nameserver: [\"https://dns.alidns.com/dns-query\", \"https://doh.pub/dns-query\"]
  fallback: [\"https://1.1.1.1/dns-query\", \"https://8.8.8.8/dns-query\"]
  fallback-filter:
    geoip: true
    geoip-code: CN
proxies:
\($px | join("\n"))
proxy-groups:
  - name: 节点选择
    type: select
    proxies:
      - 自动选择
\($list)
      - DIRECT
  - name: 自动选择
    type: url-test
    url: https://www.gstatic.com/generate_204
    interval: 300
    tolerance: 50
    proxies:
\($list)
rules:
  - GEOSITE,private,DIRECT
  - GEOIP,private,DIRECT,no-resolve
  - GEOSITE,category-ads-all,REJECT
  - GEOSITE,cn,DIRECT
  - GEOIP,CN,DIRECT
  - MATCH,节点选择
"'
}

# 生成 out/ 下的所有文件
gen_outputs() {
  local n hash stage oldout=$OUT_DIR
  hash=$({ cat "$SB_HOME/VERSION" "$SB_HOME/lib/share.sh" "$SB_HOME/lib/domain.sh"; jq -cS '{users,proto,l1,ip,node_name,egress,reality,hy2,xhttp_path}' "$STATE"; } | sha256sum | cut -d' ' -f1) || return 1
  [[ -s $SB_HOME/.outputs.hash && $(cat "$SB_HOME/.outputs.hash") == "$hash" && -d $OUT_DIR ]] && return 0
  stage=$(mktemp -d "$SB_HOME/.outputs.XXXXXXXX") || return 1
  while read -r n; do
    user_links "$n" >"$stage/$n.txt" && user_mihomo "$n" >"$stage/$n.yaml" || { rm -rf "$stage"; return 1; }
  done < <(jq -r '.users[]|select(.enabled)|.name' "$STATE")
  chmod 600 "$stage"/* 2>/dev/null || true
  switch_tree "$OUT_DIR" "$stage" || return 1
  if declare -F sub_publish >/dev/null; then sub_publish || return 1; fi
  printf %s "$hash" >"$SB_HOME/.outputs.hash"
  return 0
}


show_nodes() {  # show_nodes [用户名]（第二个参数 --qr 已不再使用，保留兼容）
  local name=${1:-default} l t
  gen_outputs
  [[ -s $OUT_DIR/$name.txt ]] || { warn "用户 $name 不存在或已停用"; return 1; }
  title "节点" "用户 $name"
  while read -r l; do
    t=${l##*#}; t=$(printf '%b' "${t//%/\\x}")   # 解码备注里的 %XX
    echo
    printf '    %s●%s %s%s%s\n' "$C_GRN" "$C_RST" "$C_B" "$t" "$C_RST"
    printf '      %s\n' "$l"
  done <"$OUT_DIR/$name.txt"
  echo
  echo "    ${C_DIM}复制链接，在 v2rayN / v2rayNG 里「从剪贴板导入」；多台 VPS 建议用面板的合并订阅。${C_RST}"
}

# 临时订阅：开一个随机端口的 HTTP 服务，几分钟后自动关闭
temp_sub() {
  local name=${1:-default} minutes=${2:-5} port token dir ip
  command -v python3 >/dev/null || { err "需要 python3（apt install python3）"; return 1; }
  gen_outputs
  [[ -s $OUT_DIR/$name.yaml ]] || { warn "用户 $name 不存在或已停用"; return 1; }
  token=$(rand_hex 16)
  dir=$(mktemp -d)
  mkdir -p "$dir/$token"
  cp "$OUT_DIR/$name.yaml" "$dir/$token/clash.yaml"
  base64 -w0 "$OUT_DIR/$name.txt" >"$dir/$token/v2ray.txt"
  while :; do
    port=$((RANDOM % 10000 + 40000))
    port_busy tcp "$port" || break
  done
  ip=$(st .ip)
  fw_open "$port/tcp"
  (exec 9>&-; unset SB_LOCKED; cd "$dir" && timeout "$((minutes * 60))" python3 "$SB_HOME/lib/temp-sub.py" "$port" "$token"; with_lock fw_close_owned "$port/tcp"; rm -rf "$dir") >/dev/null 2>&1 &
  disown
  warn "临时订阅为明文 HTTP，${minutes} 分钟后自动关闭，请尽快导入。"
  echo
  echo "${C_GRN}FlClash 订阅：${C_RST}http://${ip}:${port}/${token}/clash.yaml"
  echo "${C_GRN}v2rayN / v2rayNG 订阅：${C_RST}http://${ip}:${port}/${token}/v2ray.txt"
}
