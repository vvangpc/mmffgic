#!/usr/bin/env bash
# 安装流程（L0 零配置）。AUTO_YES=1 时全部使用默认值，不提问。

# 非交互时 ask/confirm 直接返回默认值
_ask()     { if [[ ${AUTO_YES:-0} == 1 ]]; then echo "$2"; else ask "$@"; fi; }
_confirm() { if [[ ${AUTO_YES:-0} == 1 ]]; then [[ ${2:-n} == y ]]; else confirm "$@"; fi; }

# 端口输入并检查占用：pick_port 提示 默认 tcp|udp
pick_port() {
  local p
  while :; do
    p=$(_ask "$1" "$2")
    [[ $p =~ ^[0-9]+$ ]] && ((p >= 1 && p <= 65535)) || { warn "端口无效"; continue; }
    if port_busy "$3" "$p"; then
      warn "$3 端口 $p 已被占用：$(ss -lnp 2>/dev/null | awk -v x=":$p" '$5 ~ x"$"{print $NF; exit}')"
      [[ ${AUTO_YES:-0} == 1 ]] && die "默认端口被占用，请交互安装并换端口"
      continue
    fi
    echo "$p"; return
  done
}

# 依次尝试候选端口，返回第一个空闲的：auto_port tcp|udp 需避开的端口(可空) 首选 备选...
auto_port() {
  local proto=$1 avoid=$2; shift 2
  local p first=$1 i
  for p in "$@"; do
    [[ $p == "$avoid" ]] && continue
    if ! port_busy "$proto" "$p"; then
      [[ $p != "$first" ]] && warn "${proto^^} $first 已被占用，改用 $p"
      echo "$p"; return
    fi
  done
  for i in {1..50}; do  # 候选都被占用：随机高位端口
    p=$((RANDOM % 15000 + 31000))
    [[ $p != "$avoid" ]] && ! port_busy "$proto" "$p" && { warn "候选端口均被占用，改用 $p"; echo "$p"; return; }
  done
  die "找不到空闲的 ${proto^^} 端口"
}

setup_params() {
  local sni node def_node
  def_node=$(hostname -s | tr -cd 'A-Za-z0-9-' | cut -c1-16)
  node=$(_ask "节点名称（显示在客户端里）" "${def_node:-VPS}")
  st_set_str .node_name "$node"

  # Reality 目标站
  sni=$(choose_reality_sni)
  [[ -n $sni ]] || die "未选定伪装站点"
  ok "Reality 伪装站点：$sni"
  st_set_str .reality.sni "$sni"

  # 端口
  if _confirm "是否自定义端口？（默认 Vision TCP443 / Hy2 UDP443 + 跳跃 20000-30000）" n; then
    st_set .proto.vision.port "$(pick_port 'Reality-Vision TCP 端口' 443 tcp)"
    st_set .proto.xhttp.port "$(pick_port 'XHTTP-Reality TCP 端口（默认关闭，开启时使用）' 8443 tcp)"
    st_set .proto.hy2.port "$(pick_port 'Hysteria2 UDP 端口' 443 udp)"
    local hop
    hop=$(_ask "Hy2 跳跃端口段（填 no 关闭）" "20000-30000")
    if [[ $hop == no ]]; then st_set .proto.hy2.hop_enabled false
    elif valid_hop "$hop"; then st_set_str .proto.hy2.hop "$hop"
    else warn "格式无效，使用默认 20000-30000"; fi
  else
    # 默认端口被占用时自动换到备选端口
    st_set .proto.vision.port "$(auto_port tcp "" 443 2443 4443 6443 10443)"
    st_set .proto.xhttp.port "$(auto_port tcp "$(st .proto.vision.port)" 8443 9443 7443 5443 12443)"
    st_set .proto.hy2.port "$(auto_port udp "" 443 8443 9443 7443 5443)"
    ok "端口：Vision TCP $(st .proto.vision.port) / Hy2 UDP $(st .proto.hy2.port)"
  fi
  info "默认只开 Vision 和 Hy2；XHTTP、TUIC、AnyTLS、Naive 等在 sb → 2 协议管理 或面板里勾选开启"

  gen_reality_keys
  st_set_str .xhttp_path "/$(rand_str 10)"
  st_set_str .hy2.sni "$DEF_HY2_SNI"
  gen_hy2_cert "$DEF_HY2_SNI"
  add_user default
  ok "节点参数已生成"
}

do_install() {
  need_root
  title "安装 / 重装（L0 零配置）"
  check_os
  install_deps
  mkdir -p "$BIN_DIR"
  local fresh=1 install_rc=0
  if [[ -s $STATE && -n $(st .reality.private_key) ]]; then
    if _confirm "检测到已有节点参数，保留（客户端无需重新导入）？" y; then
      fresh=0
    else
      rm -f "$STATE"
    fi
  fi
  state_init

  ipv6_disable
  time_sync
  _confirm "开启 BBR？" y && bbr_enable

  install_xray
  install_singbox

  ((fresh)) && setup_params

  local ip
  ip=$(get_ipv4)
  [[ -n $ip ]] || die "无法获取公网 IPv4"
  st_set_str .ip "$ip"
  ok "公网 IPv4：$ip"

  fetch_rulesets
  write_units
  apply_config || { warn "部分服务启动失败，请执行 sb log 查看"; install_rc=1; }

  ln -sf "$SB_HOME/sb.sh" /usr/local/bin/sb
  chmod 755 "$SB_HOME/sb.sh"
  ok "快捷命令：sb"

  install_timers
  declare -F welcome_install >/dev/null && welcome_install && ok "SSH 登录后直接进入 sb 菜单（sb → 9 → 4 可关闭）"
  backup_key >/dev/null
  backup_create auto >/dev/null 2>&1 && ok "已生成首份备份"
  # 已升级到 L1/L2 的，重装后恢复对应服务
  if [[ $(st .level) -ge 1 ]] && declare -F domain_reapply >/dev/null; then domain_reapply || install_rc=1; fi
  if [[ $(st .level) -ge 2 ]] && declare -F panel_reapply >/dev/null; then panel_reapply || install_rc=1; fi

  if health_check all; then ok "健康检查通过：$HEALTH_MSG"
  else warn "健康检查未通过：$HEALTH_MSG"; install_rc=1; fi
  # 实测各线路出口 IP：与 VPS IP 不同的线路节点名加 -IPchange
  egress_refresh

  show_nodes default --qr
  echo
  if ((install_rc == 0)); then
    ok "安装完成。客户端请使用“绕过大陆”规则，并关闭 IPv6。"
  else
    err "安装文件已写入，但验证未通过；请执行 sb health / sb log 排查后再使用。"
  fi
  return "$install_rc"
}

do_uninstall() {
  need_root
  _confirm "确定卸载？节点参数会一并删除" n || return 0
  export SB_UNINSTALL=1
  # 卸载前做一份加密备份放到 /root，重装或换机后可用 sb backup restore 恢复
  if backup_create auto >/dev/null 2>&1; then
    local last; last=$(ls -1t "$BK_DIR"/*.sbk 2>/dev/null | head -1)
    cp -f "$last" /root/ && info "节点参数已加密备份到 /root/$(basename "$last")（密钥：$(backup_key)）"
  fi
  systemctl disable --now "$SVC_X" "$SVC_S" >/dev/null 2>&1
  hop_remove
  remove_timers
  declare -F welcome_remove >/dev/null && welcome_remove
  declare -F domain_remove >/dev/null && domain_remove
  declare -F panel_remove >/dev/null && panel_remove
  rm -f /etc/systemd/system/${SVC_X}.service /etc/systemd/system/${SVC_S}.service
  systemctl daemon-reload
  if _confirm "恢复 IPv6？" n; then ipv6_enable; fi
  rm -f /usr/local/bin/sb
  rm -rf "$SB_HOME"
  ok "已卸载"
  exit 0
}
