#!/usr/bin/env bash
# 脚本自更新：从发布仓库取版本号 → 下载公开包 → 验签校验 → 备份 → 替换 → 健康检查 → 失败回滚
# 发布文件：i.sh、p.tgz、v、manifest、manifest.sig

SELF_PREV="$SB_HOME/prev-self"

self_repo() { st .self.repo; }

self_check() {  # 输出远端版本号
  local raw; raw=$(self_repo)
  [[ -n $raw ]] || return 1
  curl -4 -fsSL --max-time 20 "$raw/v?t=$(date +%s)" | tr -d '[:space:]'
}

self_update() {
  local force=0 raw remote cur t verifier=${2:-$SB_HOME/lib/release-verify.sh}
  [[ ${1:-} == --force ]] && force=1
  raw=$(self_repo)
  if [[ -z $raw ]]; then
    info "本机是手动安装的（没有发布仓库地址），跳过脚本自更新"
    record_result self skip "未配置发布仓库"; return 0
  fi
  remote=$(self_check) || { record_result self fail "无法获取版本号"; alert "脚本更新检查失败：无法访问发布仓库"; return 1; }
  cur=$(cat "$SB_HOME/VERSION" 2>/dev/null || echo 0)
  if ((!force)) && ! ver_gt "$remote" "$cur"; then
    ok "脚本已是最新：$cur"; record_result self ok "已是最新 $cur"; return 0
  fi
  info "脚本：$cur → $remote"
  t=$(mktemp -d)
  if ! curl -4 -fsSL --max-time 120 -o "$t/p.tgz" "$raw/p.tgz?t=$(date +%s)"; then
    rm -rf "$t"; record_result self fail "下载失败"; alert "脚本 $remote 下载失败"; return 1
  fi
  local asset
  for asset in manifest manifest.sig; do
    curl -4 -fsSL --max-time 30 -o "$t/$asset" "$raw/$asset" || { rm -rf "$t"; return 1; }
  done
  source "$verifier" || { rm -rf "$t"; return 1; }
  release_verify "$t" "$SB_HOME/lib/release.pub" "$remote" || { rm -rf "$t"; record_result self fail "发布签名无效，拒绝更新"; return 1; }
  if ! tar -xzf "$t/p.tgz" -C "$t" 2>/dev/null; then
    rm -rf "$t"; record_result self fail "安装包解包失败"; alert "脚本 $remote 解包失败，保持当前版本"; return 1
  fi
  local n="$t/installer" f
  # 校验：版本号一致、所有脚本语法正确
  [[ $(tr -d '[:space:]' <"$n/VERSION") == "$remote" ]] || { rm -rf "$t"; record_result self fail "版本号不一致"; return 1; }
  for f in "$n/sb.sh" "$n"/lib/*.sh; do
    bash -n "$f" 2>/dev/null || { rm -rf "$t"; record_result self fail "$(basename "$f") 语法错误"; alert "脚本 $remote 校验失败，保持 $cur"; return 1; }
  done
  # 备份当前版本
  rm -rf "$SELF_PREV"; mkdir -p "$SELF_PREV"
  cp -a "$SB_HOME/lib" "$SB_HOME/sb.sh" "$SB_HOME/VERSION" "$SELF_PREV/" 2>/dev/null
  [[ -d $SB_HOME/agent ]] && cp -a "$SB_HOME/agent" "$SELF_PREV/"
  snapshot_save "$SELF_PREV/runtime" || { rm -rf "$t"; return 1; }
  [[ ! -f $SB_HOME/bin/sbagent ]] || cp -a "$SB_HOME/bin/sbagent" "$SELF_PREV/sbagent"
  # 替换
  local copy_ok=1
  cp -f "$n"/lib/* "$SB_HOME/lib/" || copy_ok=0
  cp -f "$n/sb.sh" "$n/VERSION" "$SB_HOME/" || copy_ok=0
  if [[ -d $n/agent ]]; then mkdir -p "$SB_HOME/agent"; cp -f "$n"/agent/* "$SB_HOME/agent/" || copy_ok=0; fi
  chmod 755 "$SB_HOME/sb.sh"
  rm -rf "$t"
  # 用新脚本完成后续步骤（新版本可能有新的服务、定时任务、配置格式）
  if ((copy_ok)) && /usr/local/bin/sb self-post; then
    ok "脚本已更新到 $remote"
    record_result self ok "$cur → $remote"
    return 0
  fi
  err "新脚本健康检查失败，回滚到 $cur"
  rm -f "$SB_HOME"/lib/*.sh
  cp -a "$SELF_PREV/lib/." "$SB_HOME/lib/"
  cp -f "$SELF_PREV/sb.sh" "$SELF_PREV/VERSION" "$SB_HOME/"
  [[ -d $SELF_PREV/agent ]] && cp -f "$SELF_PREV"/agent/* "$SB_HOME/agent/"
  if [[ -f $SELF_PREV/sbagent ]]; then install -m 755 "$SELF_PREV/sbagent" "$SB_HOME/bin/sbagent.new" && mv -f "$SB_HOME/bin/sbagent.new" "$SB_HOME/bin/sbagent"; fi
  if ! snapshot_restore "$SELF_PREV/runtime" || ! /usr/local/bin/sb self-post >/dev/null 2>&1; then
    record_result self fail "回滚失败，快照保留在 $SELF_PREV"; alert "自更新回滚失败，需要人工恢复 $SELF_PREV"; return 1
  fi
  record_result self fail "$remote 健康检查失败，已回滚到 $cur"
  alert "脚本更新到 $remote 失败，已回滚到 $cur"
  return 1
}

# 更新后的收尾（由新版本脚本执行）
self_post() {
  write_units
  install_timers >/dev/null
  # 新功能：欢迎页（老版本升级上来默认开启，用户关掉过的保持关）
  if declare -F welcome_install >/dev/null && [[ $(st .welcome) != false ]]; then welcome_install; fi
  apply_config all >/dev/null || return 1
  [[ $(st .l1.enabled) == true ]] && declare -F nginx_apply >/dev/null && { nginx_apply || return 1; }
  if [[ -n $(st .panel.url) ]] && declare -F agent_install >/dev/null; then agent_install >/dev/null || return 1; fi
  health_check all || { echo "$HEALTH_MSG"; return 1; }
  egress_refresh
  declare -F panel_report >/dev/null && panel_report >/dev/null 2>&1
  return 0
}
