#!/usr/bin/env bash
# 脚本自更新：从发布仓库取版本号 → 下载公开包 → 验签校验 → 备份 → 替换 → 健康检查 → 失败回滚
# 发布文件：i.sh、p.tgz、v、manifest、manifest.sig

SELF_PREV="$SB_HOME/prev-self"

self_repo() { st .self.repo; }

self_replace_entry() {
  # Bash 可能仍从旧入口读取命令。把新文件放在同一目录后 rename，让旧进程读完原文件。
  install -m 755 "$1/sb.sh" "$SB_HOME/sb.sh.new" &&
    mv -fT "$SB_HOME/sb.sh.new" "$SB_HOME/sb.sh" &&
    cp -f "$1/VERSION" "$SB_HOME/VERSION"
}

self_check() {  # 输出远端版本号
  local raw; raw=$(self_repo)
  [[ -n $raw ]] || return 1
  curl -4 -fsSL --max-time 20 "$raw/v?t=$(date +%s)" | tr -d '[:space:]'
}

self_update() {
  local force=0 raw remote cur t verifier=${2:-$SB_HOME/lib/release-verify.sh}
  [[ ${1:-} == --force ]] && force=1
  raw=$(self_repo)
  if [[ -z $raw ]]; then
    info "本机是手动安装的（没有发布仓库地址），跳过脚本自更新"
    record_result self skip "未配置发布仓库"; return 0
  fi
  remote=$(self_check) || { record_result self fail "无法获取版本号"; alert "脚本更新检查失败：无法访问发布仓库"; return 1; }
  cur=$(cat "$SB_HOME/VERSION") || return 1
  if ((!force)) && ! ver_gt "$remote" "$cur"; then
    if [[ $(st .upd.result.self.result) == pending-report && -n $(st .panel.url) ]]; then
      panel_report || { err "脚本已是 $cur，面板上报仍失败"; return 3; }
    fi
    ok "脚本已是最新：$cur"; record_result self ok "已是最新 $cur"; return 0
  fi
  info "脚本：$cur → $remote"
  t=$(mktemp -d) || return 1
  if ! curl -4 -fsSL --max-time 120 -o "$t/p.tgz" "$raw/p.tgz?t=$(date +%s)"; then
    rm -rf "$t"; record_result self fail "下载失败"; alert "脚本 $remote 下载失败"; return 1
  fi
  local asset
  for asset in manifest manifest.sig; do
    curl -4 -fsSL --max-time 30 -o "$t/$asset" "$raw/$asset" || { rm -rf "$t"; return 1; }
  done
  source "$verifier" || { rm -rf "$t"; return 1; }
  release_verify "$t" "$SB_HOME/lib/release.pub" "$remote" || { rm -rf "$t"; record_result self fail "发布签名无效，拒绝更新"; return 1; }
  if ! tar -xzf "$t/p.tgz" -C "$t" 2>/dev/null; then
    rm -rf "$t"; record_result self fail "安装包解包失败"; alert "脚本 $remote 解包失败，保持当前版本"; return 1
  fi
  local rc=0
  self_apply_candidate "$t/installer" "$remote" "$cur" || rc=$?
  rm -rf "$t"
  return "$rc"
}

self_backup() {
  local dst=$1 f
  [[ -s $SB_HOME/lib/load.sh && -s $SB_HOME/sb.sh && -s $SB_HOME/VERSION ]] || return 1
  for f in lib sb.sh VERSION agent bin/sbagent; do [[ ! -L $SB_HOME/$f ]] || return 1; done
  for f in lib sb.sh VERSION; do snapshot_copy "$SB_HOME/$f" "$dst/$f" || return 1; done
  [[ ! -d $SB_HOME/agent ]] || snapshot_copy "$SB_HOME/agent" "$dst/agent" || return 1
  [[ ! -f $SB_HOME/bin/sbagent ]] || snapshot_copy "$SB_HOME/bin/sbagent" "$dst/sbagent" || return 1
  snapshot_save "$dst/runtime" || return 1
  snapshot_seal "$dst"
}

# 包已由调用方使用安装时信任的公钥验证；调用方持有同一把维护锁。
self_apply_candidate() {
  local n=$1 remote=$2 cur=$3 f stage incoming rc=0
  [[ $(cat "$n/VERSION") == "$remote" ]] || { err "包内版本不匹配"; return 1; }
  for f in "$n/sb.sh" "$n"/lib/*.sh; do
    bash -n "$f" || { err "$(basename "$f") 语法错误"; return 1; }
  done
  stage=$(mktemp -d "$SB_HOME/.self-backup.XXXXXXXX") || return 1
  if ! self_backup "$stage" || ! snapshot_valid "$stage"; then
    rm -rf "$stage"; err "备份不完整，已停止升级，当前脚本和上次备份均保留"; return 1
  fi
  # Stage the release on the install filesystem before replacing any live file.
  incoming=$(mktemp -d "$SB_HOME/.self-install.XXXXXXXX") || { rm -rf "$stage"; return 1; }
  for f in sb.sh VERSION lib agent; do
    [[ $f == agent && ! -d $n/agent ]] && continue
    snapshot_copy "$n/$f" "$incoming/$f" || { rm -rf "$stage" "$incoming"; err "新版文件写入或核对失败"; return 1; }
  done
  chmod 755 "$incoming/sb.sh" || { rm -rf "$stage" "$incoming"; return 1; }
  if [[ -e $SELF_PREV ]] && ! mv -T "$SELF_PREV" "$stage.previous"; then
    rm -rf "$stage" "$incoming"; return 1
  fi
  if ! mv -T "$stage" "$SELF_PREV"; then
    [[ ! -d $stage.previous ]] || mv -T "$stage.previous" "$SELF_PREV"
    rm -rf "$incoming"; return 1
  fi
  rm -rf "$stage.previous"
  for f in "$incoming"/lib/*; do mv -fT "$f" "$SB_HOME/lib/${f##*/}" || { rc=1; break; }; done
  if ((rc == 0)) && [[ -d $incoming/agent ]]; then
    mkdir -p "$SB_HOME/agent" || rc=1
    for f in "$incoming"/agent/*; do mv -fT "$f" "$SB_HOME/agent/${f##*/}" || { rc=1; break; }; done
  fi
  if ((rc == 0)) && mv -fT "$incoming/sb.sh" "$SB_HOME/sb.sh" && mv -fT "$incoming/VERSION" "$SB_HOME/VERSION"; then
    rm -rf "$incoming"
    # The outer script backup owns rollback, including any changes made by apply_config.
    SB_TRANSACTION=1 "$SB_HOME/sb.sh" self-post || rc=$?
    case $rc in
      0) ok "脚本已更新到 $remote"; record_result self ok "$cur → $remote"; return 0 ;;
      3) err "脚本已更新到 $remote，线路健康，面板上报待重试"
         record_result self pending-report "$remote 已安装，面板上报失败"; return 3 ;;
    esac
  fi
  rm -rf "$incoming"
  err "新脚本应用失败，回滚到 $cur"
  rc=0
  if self_restore; then SB_TRANSACTION=1 "$SB_HOME/sb.sh" self-post || rc=$?
  else rc=1; fi
  if ((rc != 0 && rc != 3)); then
    record_result self fail "回滚未完成，快照保留在 $SELF_PREV"; alert "自更新回滚未完成，请检查 $SELF_PREV"; return 1
  fi
  record_result self fail "$remote 应用失败，已回滚到 $cur"
  alert "脚本更新到 $remote 失败，已回滚到 $cur"
  return 1
}

self_restore() {
  local stage f
  snapshot_valid "$SELF_PREV" && snapshot_valid "$SELF_PREV/runtime" || return 1
  stage=$(mktemp -d "$SB_HOME/.self-restore.XXXXXXXX") || return 1
  for f in lib agent; do
    [[ ! -d $SELF_PREV/$f ]] || snapshot_copy "$SELF_PREV/$f" "$stage/$f" || return 1
  done
  for f in lib agent; do
    if [[ -d $SB_HOME/$f ]]; then mv -T "$SB_HOME/$f" "$stage/failed-$f" || return 1; fi
    [[ -d $stage/$f ]] || continue
    if ! mv -T "$stage/$f" "$SB_HOME/$f"; then
      [[ ! -d $stage/failed-$f ]] || mv -T "$stage/failed-$f" "$SB_HOME/$f"
      return 1
    fi
  done
  self_replace_entry "$SELF_PREV" || return 1
  if [[ -f $SELF_PREV/sbagent ]]; then
    install -m 755 "$SELF_PREV/sbagent" "$SB_HOME/bin/sbagent.new" && mv -f "$SB_HOME/bin/sbagent.new" "$SB_HOME/bin/sbagent" || return 1
  else
    rm -f "$SB_HOME/bin/sbagent" || return 1
  fi
  rm -rf "$stage"
  snapshot_restore "$SELF_PREV/runtime"
}

# 更新后的收尾（由新版本脚本执行）
self_post() {
  write_units || return 1
  install_timers >/dev/null || return 1
  # 新功能：欢迎页（老版本升级上来默认开启，用户关掉过的保持关）
  if declare -F welcome_install >/dev/null && [[ $(st .welcome) != false ]]; then welcome_install; fi
  apply_config all >/dev/null || return 1
  [[ $(st .l1.enabled) == true ]] && declare -F nginx_apply >/dev/null && { nginx_apply || return 1; }
  if [[ -n $(st .panel.url) ]] && declare -F agent_install >/dev/null; then agent_install >/dev/null || return 1; fi
  health_check all || { echo "$HEALTH_MSG"; return 1; }
  egress_refresh
  if [[ -n $(st .panel.url) ]]; then panel_report || return 3; fi
  return 0
}
