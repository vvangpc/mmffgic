#!/usr/bin/env bash
# 核心层：下载 Xray / sing-box（只取正式版，校验 sha256），systemd 服务，健康检查

GH_API=https://api.github.com/repos
REPO_X=XTLS/Xray-core
REPO_S=SagerNet/sing-box

# 读取最新正式版信息：gh_latest XTLS/Xray-core -> 输出 release JSON（/latest 不含预发布）
gh_latest() {
  curl -4 -fsSL --max-time 20 -H 'Accept: application/vnd.github+json' "$GH_API/$1/releases/latest"
}

# 下载并校验：dl_verify url 期望sha256(可空) 输出文件
dl_verify() {
  local url=$1 sha=$2 out=$3
  curl -4 -fsSL --retry 3 --max-time 300 -o "$out" "$url" || return 1
  if [[ $sha =~ ^[a-fA-F0-9]{64}$ ]]; then
    echo "$sha  $out" | sha256sum -c --status || { err "sha256 校验失败：$url"; return 1; }
  else
    err "无可信 sha256，拒绝安装：$url"; rm -f "$out"; return 1
  fi
}

core_repo() { [[ $1 == x ]] && echo "$REPO_X" || echo "$REPO_S"; }
core_name() { [[ $1 == x ]] && echo Xray || echo sing-box; }
core_bin()  { [[ $1 == x ]] && echo "$XRAY_BIN" || echo "$SBOX_BIN"; }
core_cur()  { [[ $1 == x ]] && st .core.xray || st .core.singbox; }
core_svc()  { [[ $1 == x ]] && echo "$SVC_X" || echo "$SVC_S"; }

# 下载某个核心到暂存目录：fetch_core x|s 目录 [release JSON]
# 成功后目录内有 xray（及 geoip.dat/geosite.dat）或 sing-box；FETCH_TAG 为版本号
fetch_core() {
  local which=$1 dir=$2 rel=${3:-} tag ver asset url sha
  [[ -n $rel ]] || rel=$(gh_latest "$(core_repo "$which")") || { err "无法访问 GitHub API"; return 1; }
  tag=$(jq -r .tag_name <<<"$rel"); ver=${tag#v}
  if [[ $which == x ]]; then
    [[ $ARCH == amd64 ]] && asset=Xray-linux-64.zip || asset=Xray-linux-arm64-v8a.zip
  else
    asset="sing-box-${ver}-linux-${ARCH}.tar.gz"
  fi
  url=$(jq -r --arg a "$asset" '.assets[]|select(.name==$a)|.browser_download_url' <<<"$rel")
  [[ -n $url ]] || { err "找不到安装包 $asset"; return 1; }
  sha=$(jq -r --arg a "$asset" '.assets[]|select(.name==$a)|.digest // empty' <<<"$rel" | sed 's/^sha256://')
  if [[ -z $sha && $which == x ]]; then  # 退回到官方 .dgst 文件
    sha=$(curl -4 -fsSL "$url.dgst" 2>/dev/null | awk -F'= ' '/SHA2-256/{print $2; exit}')
  fi
  info "下载 $(core_name "$which") $tag ..."
  mkdir -p "$dir"
  dl_verify "$url" "$sha" "$dir/pkg" || return 1
  [[ -n $sha ]] && ok "sha256 校验通过"
  if [[ $which == x ]]; then
    unzip -qo "$dir/pkg" xray geoip.dat geosite.dat -d "$dir" || { err "解压失败"; return 1; }
  else
    tar -xzf "$dir/pkg" -C "$dir" --strip-components=1 "sing-box-${ver}-linux-${ARCH}/sing-box" || { err "解压失败"; return 1; }
  fi
  rm -f "$dir/pkg"
  chmod 755 "$dir/xray" "$dir/sing-box" 2>/dev/null
  FETCH_TAG=$tag
}

# 把暂存目录里的核心装到正式位置：install_staged x|s 目录 版本号
install_staged() {
  local which=$1 dir=$2 tag=$3
  if [[ $which == x ]]; then
    install -m 755 "$dir/xray" "$XRAY_BIN.new" && mv -f "$XRAY_BIN.new" "$XRAY_BIN"
    # Geo 文件若已由 geo 更新任务维护（更新），就不用安装包里的旧版本覆盖
    if [[ $(st .geo.managed) != true ]]; then
      install -m 644 "$dir/geoip.dat" "$dir/geosite.dat" "$BIN_DIR/"
    fi
    st_set_str .core.xray "$tag"
  else
    install -m 755 "$dir/sing-box" "$SBOX_BIN.new" && mv -f "$SBOX_BIN.new" "$SBOX_BIN"
    st_set_str .core.singbox "$tag"
  fi
}

install_xray() {
  local d; d=$(mktemp -d)
  fetch_core x "$d" || { rm -rf "$d"; die "Xray 下载失败"; }
  install_staged x "$d" "$FETCH_TAG"; rm -rf "$d"
  ok "Xray $FETCH_TAG 已安装"
}
install_singbox() {
  local d; d=$(mktemp -d)
  fetch_core s "$d" || { rm -rf "$d"; die "sing-box 下载失败"; }
  install_staged s "$d" "$FETCH_TAG"; rm -rf "$d"
  ok "sing-box $FETCH_TAG 已安装"
}

write_units() {
  cat >/etc/systemd/system/${SVC_X}.service <<EOF || return 1
[Unit]
Description=${SB_NAME} x
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
Environment=XRAY_LOCATION_ASSET=${BIN_DIR}
ExecStart=${XRAY_BIN} run -c ${XRAY_CONF}
Restart=on-failure
RestartSec=5
LimitNOFILE=1048576
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_NET_RAW
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_NET_RAW
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF
  cat >/etc/systemd/system/${SVC_S}.service <<EOF || return 1
[Unit]
Description=${SB_NAME} s
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=${ETC_DIR}
ExecStart=${SBOX_BIN} run -c ${SBOX_CONF} -D ${ETC_DIR}
ExecReload=/bin/kill -HUP \$MAINPID
Restart=on-failure
RestartSec=5
LimitNOFILE=1048576
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_NET_RAW
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_NET_RAW
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
}

# 校验配置（可指定用哪个二进制校验，用于更新前预检）
check_xray() { XRAY_LOCATION_ASSET=$BIN_DIR "${1:-$XRAY_BIN}" run -test -c "$XRAY_CONF" >$SB_RUN_DIR/xcheck.log 2>&1; }
check_singbox() { "${1:-$SBOX_BIN}" check -c "$SBOX_CONF" -D "$ETC_DIR" >$SB_RUN_DIR/scheck.log 2>&1; }

# 重启某个核心并检查服务状态：restart_core x|s
restart_core() {
  local which=$1 svc name
  svc=$(core_svc "$which"); name=$(core_name "$which")
  if [[ $which == x ]]; then
    if ! xray_needed; then systemctl disable --now "$svc" >/dev/null 2>&1; info "Xray 无启用的协议，已停止"; return 0; fi
    check_xray || { err "Xray 配置校验失败："; tail -n 20 $SB_RUN_DIR/xcheck.log >&2; return 1; }
  else
    if ! sbox_needed; then systemctl disable --now "$svc" >/dev/null 2>&1; info "sing-box 无启用的协议，已停止"; return 0; fi
    check_singbox || { err "sing-box 配置校验失败："; tail -n 20 $SB_RUN_DIR/scheck.log >&2; return 1; }
  fi
  systemctl enable "$svc" >/dev/null 2>&1
  systemctl restart "$svc"
  sleep 2
  if systemctl is-active -q "$svc"; then
    ok "$name 运行中"
  else
    err "$name 启动失败，最近日志："
    journalctl -u "$svc" -n 20 --no-pager >&2
    return 1
  fi
}

core_status() {  # core_status svc -> 运行中/已停止
  systemctl is-active -q "$1" && echo "${C_GRN}运行中${C_RST}" || echo "${C_RED}已停止${C_RST}"
}

# 本机自检用的 sing-box 出站（经 127.0.0.1 连本机入站）：sbox_test_outbound tuic|anytls|naive 密码 uuid
sbox_test_port() { case $1 in tuic) echo $(($2 + 6)) ;; anytls) echo $(($2 + 7)) ;; snell) echo $(($2 + 9)) ;; naive) echo $(($2 + 8)) ;; esac; }
sbox_test_outbound() {
  local k=$1 pass=$2 uuid=$3 sni ins=false name
  name=$(jq -r '[.users[]|select(.enabled)][0].name // "default"' "$STATE")
  if [[ $(st .l1.enabled) == true ]]; then sni=$(st .l1.direct_host); else sni=$(st .hy2.sni); ins=true; fi
  case $k in
    tuic) jq -nc --argjson p "$(st .proto.tuic.port)" --arg u "$uuid" --arg pw "$pass" --arg sni "$sni" --argjson ins "$ins" \
      '{type:"tuic",server:"127.0.0.1",server_port:$p,uuid:$u,password:$pw,congestion_control:"bbr",
              udp_relay_mode:"native",tls:{enabled:true,server_name:$sni,insecure:$ins,alpn:["h3"]}}' ;;
    snell) jq -c '.proto.snell.port as $p | .users[] | select(.name=="default" and .enabled) |
      {type:"snell",server:"127.0.0.1",server_port:$p,version:6,psk:.snell_psk}' "$STATE" ;;
    anytls) jq -nc --argjson p "$(st .proto.anytls.port)" --arg pw "$pass" --arg sni "$sni" \
      '{type:"anytls",server:"127.0.0.1",server_port:$p,password:$pw,tls:{enabled:true,server_name:$sni}}' ;;
    naive) jq -nc --argjson p "$(st .proto.naive.port)" --arg n "$name" --arg pw "$pass" --arg sni "$sni" \
      '{type:"naive",server:"127.0.0.1",server_port:$p,username:$n,password:$pw,tls:{enabled:true,server_name:$sni}}' ;;
  esac
}

# Naive 握手检查：服务端只认带 Naive padding 头的 CONNECT 握手。
# 优先用 Python3 原生 TLS 只发 CONNECT 读完响应头即断（毫秒级完成且不把凭据暴露在命令行参数里）。
naive_handshake() {
  local dh n pw port out
  [[ $(st .l1.enabled) == true ]] || return 1
  dh=$(st .l1.direct_host); port=$(st .proto.naive.port)
  n=$(jq -r '[.users[]|select(.enabled)][0].name // empty' "$STATE")
  pw=$(jq -r '[.users[]|select(.enabled)][0].hy2 // empty' "$STATE")
  [[ -n $dh && -n $port && -n $n && -n $pw ]] || return 1
  if command -v python3 >/dev/null 2>&1; then
    NAIVE_HOST=$dh NAIVE_PORT=$port NAIVE_USER=$n NAIVE_PASS=$pw python3 - <<'PY' 2>/dev/null
import base64, os, socket, ssl, sys, time
host, port = os.environ["NAIVE_HOST"], int(os.environ["NAIVE_PORT"])
auth = base64.b64encode((os.environ["NAIVE_USER"] + ":" + os.environ["NAIVE_PASS"]).encode()).decode()
ctx = ssl.create_default_context()
ctx.set_alpn_protocols(["http/1.1"])
t0 = time.monotonic()
try:
    with socket.create_connection(("127.0.0.1", port), timeout=5) as raw:
        with ctx.wrap_socket(raw, server_hostname=host) as s:
            req = (
                "CONNECT www.gstatic.com:443 HTTP/1.1\r\n"
                "Host: www.gstatic.com:443\r\n"
                f"Proxy-Authorization: Basic {auth}\r\n"
                "Padding: !!!!!!!!!!!!!!!!!!!!!!!!\r\n\r\n"
            ).encode()
            s.sendall(req)
            buf = b""
            while b"\r\n\r\n" not in buf and len(buf) < 4096:
                chunk = s.recv(1024)
                if not chunk:
                    break
                buf += chunk
            head = buf.split(b"\r\n\r\n", 1)[0].decode("latin1", "ignore")
            lines = head.splitlines()
            if not lines or " 200" not in lines[0] or not any(l.lower().startswith("padding:") for l in lines[1:]):
                sys.exit(1)
            print(int((time.monotonic() - t0) * 1000) + 1)
except Exception:
    sys.exit(1)
PY
    return $?
  fi
  out=$(curl -4 -sv -o /dev/null -w 'T=%{time_connect} %{time_total}\n' --max-time 4 --resolve "$dh:$port:127.0.0.1" \
    --proxy-header "padding: !!!!!!!!!!!!!!!!!!!!!!!!" -x "https://$n:$pw@$dh:$port" \
    https://www.gstatic.com/generate_204 2>&1)
  grep -qE '^< HTTP/[0-9.]+ 200' <<<"$out" && grep -qi '^< padding:' <<<"$out" || return 1
  awk '/^T=/{sub(/^T=/,""); printf "%d", $1*1000 + 1}' <<<"$out"
}

# ---------- 健康检查：端口 + 真实出站 ----------
# 在本机起临时客户端，经每个启用的协议访问外网，返回 0 表示全部通过
# health_check x|s|all   结果明细写到 HEALTH_MSG
HEALTH_URL=https://www.gstatic.com/generate_204
health_check_run() {
  local which=${1:-all} results rc=0
  HEALTH_MSG=""
  if [[ $which == x ]] && ! xray_needed; then HEALTH_MSG="Xray 无启用协议，跳过检查"; return 0; fi
  if [[ $which == s ]] && ! sbox_needed; then HEALTH_MSG="sing-box 无启用协议，跳过检查"; return 0; fi
  if [[ $which != s ]] && xray_needed && ! systemctl is-active -q "$SVC_X"; then HEALTH_MSG+="Xray 未运行；"; rc=1; fi
  if [[ $which != x ]] && sbox_needed && ! systemctl is-active -q "$SVC_S"; then HEALTH_MSG+="sing-box 未运行；"; rc=1; fi
  if [[ $(jq '[.users[]|select(.enabled)]|length' "$STATE") == 0 ]]; then
    HEALTH_MSG+="无启用用户，不做出站测试；"; return "$rc"
  fi
  results=$(node_probe "health-$which") || { HEALTH_MSG+="线路探测未完成；"; return 1; }
  HEALTH_MSG+=$(jq -r '[.[]|.name + (if .ok then " 正常" else " 失败" end)]|join("；")' <<<"$results")
  jq -e 'length>0 and all(.[];.ok)' <<<"$results" >/dev/null || rc=1
  return "$rc"
}
health_check() {
  local rc=0 file
  health_check_run "${1:-all}" || rc=$?
  if [[ -n ${STATE:-} && -s $STATE && -d ${SB_HOME:-/nonexistent} ]]; then
    file=$(mktemp "$SB_HOME/.health.XXXXXX")
    if jq -n --arg time "$(TZ=Asia/Shanghai date '+%F %T')" --arg scope "${1:-all}" --arg message "$HEALTH_MSG" --arg hash "$(sha256sum "$STATE" | cut -d' ' -f1)" --argjson rc "$rc" '{time:$time,scope:$scope,message:$message,state_hash:$hash,rc:$rc}' >"$file"; then
      mv -f "$file" "$SB_HOME/.last-health.json"
    else rm -f "$file"; fi
  fi
  return "$rc"
}
probe_base() {
  local base p busy try
  for try in {1..100}; do
    base=$((RANDOM % 20000 + 30000)); busy=0
    for ((p=base+1;p<=base+9;p++)); do ss -H -lnt | awk '{print $4}' | grep -qE ":$p$" && busy=1; done
    ((busy)) || { echo "$base"; return 0; }
  done
  return 1
}

# ---------- 线路实测：真连接延迟 / 出口 IP / 下载速度 ----------
# node_probe [speed]  → 输出 JSON 数组：[{key,name,ok,ms,egress,mbps}]
# 在 VPS 本机起临时客户端，逐条线路真实走一遍代理（CDN 线路会真的绕经 Cloudflare）。
# 测的是「VPS 这一端」：延迟≈经该协议访问 Google 的耗时，速度≈VPS 出口带宽；不含你手机到 VPS 这一段。
PROBE_IP_URLS=(https://api.ipify.org https://ipv4.icanhazip.com)
PROBE_SPEED_URL="https://speed.cloudflare.com/__down?bytes=30000000"
node_probe() {
  local worker="" signal_rc=0 rc=0 saved_traps
  saved_traps=$(trap -p INT TERM)
  trap 'signal_rc=130; if [[ -n $worker ]]; then kill -TERM "$worker" 2>/dev/null || :; fi' INT
  trap 'signal_rc=143; if [[ -n $worker ]]; then kill -TERM "$worker" 2>/dev/null || :; fi' TERM
  _node_probe_run "$@" & worker=$!
  if ((signal_rc)); then kill -TERM "$worker" 2>/dev/null || :; fi
  wait "$worker" || rc=$?
  if ((signal_rc)); then wait "$worker" 2>/dev/null || :; rc=$signal_rc; fi
  trap - INT TERM
  eval "$saved_traps"
  return "$rc"
}
_node_probe_run() {
  local speed=${1:-} t="" uuid pass rows=() sni pbk sid base pid=""
  _probe_cleanup() {
    [[ -n ${pid:-} ]] && kill "$pid" 2>/dev/null && wait "$pid" 2>/dev/null || true
    [[ -z $t ]] || rm -rf -- "$t"
  }
  trap _probe_cleanup EXIT
  trap 'exit 130' INT
  trap 'exit 143' TERM
  base=$(probe_base) || return 1
  t=$(mktemp -d) || return 1
  uuid=$(jq -r '[.users[]|select(.enabled)][0].uuid // empty' "$STATE")
  pass=$(jq -r '[.users[]|select(.enabled)][0].hy2 // empty' "$STATE")
  [[ -n $uuid ]] || { echo '[]'; return 1; }
  sni=$(st .reality.sni); pbk=$(st .reality.public_key); sid=$(st .reality.short_id)
  if [[ $(st .l1.enabled) == true && -n $(st .l1.direct_host) ]]; then sni=$(st .l1.direct_host); fi

  # 逐条串行拉起临时客户端并及时回收，避免低配 VPS 同时启动 8 个核心触发 OOM
  _probe_one() {  # engine(x|s) port key name outbound-json
    local eng=$1 port=$2 key=$3 name=$4 ob=$5 px ms i v ok eg mbps best ready=0
    if [[ $speed == health-x && $eng != x ]]; then return 0; fi
    if [[ $speed == health-s && $eng != s ]]; then return 0; fi
    if [[ $eng == x ]]; then
      printf '{"log":{"loglevel":"error"},"inbounds":[{"listen":"127.0.0.1","port":%s,"protocol":"socks"}],"outbounds":[%s]}' "$port" "$ob" >"$t/$key.json"
      XRAY_LOCATION_ASSET=$BIN_DIR "$XRAY_BIN" run -c "$t/$key.json" >"$t/$key.log" 2>&1 & pid=$!
    else
      printf '{"log":{"level":"error"},"inbounds":[{"type":"socks","listen":"127.0.0.1","listen_port":%s}],"outbounds":[%s]}' "$port" "$ob" >"$t/$key.json"
      "$SBOX_BIN" run -c "$t/$key.json" >"$t/$key.log" 2>&1 & pid=$!
    fi
    for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
      kill -0 "$pid" 2>/dev/null || break
      if ss -H -lnt "sport = :$port" 2>/dev/null | grep -q .; then ready=1; break; fi
      sleep 0.2
    done
    if ((!ready)); then
      local why=""
      why=$(tail -n 2 "$t/$key.log" 2>/dev/null | tr '\n' ' ')
      [[ -n $why ]] && warn "探测客户端($name)未就绪：$why"
      kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null; pid=""
      rows+=("$(jq -nc --arg k "$key" --arg n "$name" '{key:$k, name:$n, ok:false, ms:null, egress:"", mbps:null}')")
      return 0
    fi
    px="socks5h://127.0.0.1:$port"
    best=""
    for i in 1 2; do
      local target=$HEALTH_URL; [[ $i != 2 ]] || target=https://cp.cloudflare.com/generate_204
      v=$(curl -4 -s -o /dev/null -w '%{http_code} %{time_total}' --max-time 8 -x "$px" "$target")
      [[ ${v%% *} == 204 ]] || continue
      v=$(awk -v s="${v#* }" 'BEGIN{printf "%d", s*1000}')
      [[ -z $best || $v -lt $best ]] && best=$v
    done
    ok=false; [[ -n $best ]] && ok=true
    eg=""
    if [[ $speed != health-* && $ok == true ]]; then
      for v in "${PROBE_IP_URLS[@]}"; do
        eg=$(curl -4 -s --max-time 8 -x "$px" "$v" | tr -d '[:space:]')
        [[ $eg =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] && break; eg=""
      done
    fi
    mbps=""
    if [[ $speed == speed && $ok == true ]]; then
      v=$(curl -4 -s -o /dev/null -w '%{speed_download}' --max-time 8 -x "$px" "$PROBE_SPEED_URL")
      mbps=$(awk -v b="$v" 'BEGIN{printf "%.1f", b*8/1000000}')
    fi
    kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null; pid=""
    rows+=("$(jq -nc --arg k "$key" --arg n "$name" --argjson ok "$ok" --arg ms "$best" --arg e "$eg" --arg m "$mbps" \
      '{key:$k, name:$n, ok:$ok, ms:($ms|tonumber? // null), egress:$e, mbps:($m|tonumber? // null)}')")
  }

  local reality="\"security\":\"reality\",\"realitySettings\":{\"serverName\":\"$sni\",\"fingerprint\":\"chrome\",\"publicKey\":\"$pbk\",\"shortId\":\"$sid\"}"
  [[ $(st .proto.vision.enabled) == true ]] && _probe_one x "$((base+1))" vision Vision \
    "{\"protocol\":\"vless\",\"settings\":{\"vnext\":[{\"address\":\"127.0.0.1\",\"port\":$(st .proto.vision.port),\"users\":[{\"id\":\"$uuid\",\"encryption\":\"none\",\"flow\":\"xtls-rprx-vision\"}]}]},\"streamSettings\":{\"network\":\"raw\",$reality}}"
  [[ $(st .proto.xhttp.enabled) == true ]] && _probe_one x "$((base+2))" xhttp XHTTP \
    "{\"protocol\":\"vless\",\"settings\":{\"vnext\":[{\"address\":\"127.0.0.1\",\"port\":$(st .proto.xhttp.port),\"users\":[{\"id\":\"$uuid\",\"encryption\":\"none\"}]}]},\"streamSettings\":{\"network\":\"xhttp\",\"xhttpSettings\":{\"path\":\"$(st .xhttp_path)\",\"mode\":\"auto\"},$reality}}"
  [[ $(st .proto.hy2.enabled) == true ]] && _probe_one s "$((base+3))" hy2 Hy2 \
    "{\"type\":\"hysteria2\",\"server\":\"127.0.0.1\",\"server_port\":$(st .proto.hy2.port),\"password\":\"$pass\",\"tls\":{\"enabled\":true,\"server_name\":\"$(st .hy2.sni)\",\"insecure\":true,\"alpn\":[\"h3\"]}}"
  local ob
  for ob in tuic anytls snell; do
    [[ $(proto_on "$ob") == true ]] && _probe_one s "$(sbox_test_port "$ob" "$base")" "$ob" "$(proto_label "$ob" | cut -d' ' -f1)" "$(sbox_test_outbound "$ob" "$pass" "$uuid")"
  done
  if [[ $(st .l1.enabled) == true ]]; then
    local dh ch; dh=$(st .l1.direct_host); ch=$(st .l1.cdn_host)
    [[ $(st .l1.hy2tls_enabled) == true ]] && _probe_one s "$((base+4))" hy2tls Hy2-TLS \
      "{\"type\":\"hysteria2\",\"server\":\"127.0.0.1\",\"server_port\":$(st .l1.hy2tls_port),\"password\":\"$pass\",\"tls\":{\"enabled\":true,\"server_name\":\"$dh\",\"alpn\":[\"h3\"]}}"
    [[ $(st .l1.cdn_enabled) == true ]] && _probe_one x "$((base+5))" cdn CDN \
      "{\"protocol\":\"vless\",\"settings\":{\"vnext\":[{\"address\":\"$ch\",\"port\":$(st .l1.cdn_port),\"users\":[{\"id\":\"$uuid\",\"encryption\":\"none\"}]}]},\"streamSettings\":{\"network\":\"xhttp\",\"xhttpSettings\":{\"path\":\"$(st .l1.cdn_path)\",\"host\":\"$ch\",\"mode\":\"auto\"},\"security\":\"tls\",\"tlsSettings\":{\"serverName\":\"$ch\",\"fingerprint\":\"chrome\",\"alpn\":[\"h2\"]}}}"
  fi
  if [[ $speed != health-x && $(proto_on naive) == true ]]; then
    local best="" i v
    for i in 1 2; do v=$(naive_handshake) && [[ -z $best || $v -lt $best ]] && best=$v; done
    rows+=("$(jq -nc --arg ms "$best" '{key:"naive", name:"Naive(握手)", ok:($ms != ""), ms:($ms|tonumber? // null), egress:"", mbps:null}')")
  fi
  printf '%s\n' "${rows[@]}" | jq -sc .
}

# 实测各线路出口 IP，记到 .egress；与 VPS IP 不同的线路，节点名加 -IPchange 并主动告警
egress_refresh() {   # 可传入已有的 node_probe 结果，省得再测一遍
  local r=${1:-} new old ip diff
  [[ -n $r ]] || r=$(node_probe) || return 1
  new=$(jq -c 'map(select(.egress != "") | {(.key): .egress}) | add // {}' <<<"$r")
  old=$(jq -c '.egress // {}' "$STATE")
  [[ $new == "$old" ]] && return 0
  st_set .egress "$new"
  log_event EGRESS "$new"
  ip=$(st .ip)
  diff=$(jq -r --arg ip "$ip" 'to_entries | map(select(.value != $ip) | "\(.key)=\(.value)") | join(", ")' <<<"$new")
  if [[ -n $diff ]] && declare -F alert >/dev/null; then
    alert "检测到代理出口 IP 与 VPS IP($ip) 不一致：$diff（对应线路已标记 -IPchange 并移出自动组）"
  fi
  declare -F gen_outputs >/dev/null && gen_outputs >/dev/null 2>&1
  return 0
}

# 打印测速结果（菜单 / sb probe）
probe_show() {
  local r ip; ip=$(st .ip)
  info "逐条线路实测中（${1:+含测速，}约 $([[ $1 == speed ]] && echo 1 || echo 0.5) 分钟）..."
  r=$(node_probe "${1:-}"); PROBE_LAST=$r
  printf '  %-9s %-6s %-9s %-17s %s\n' 线路 状态 延迟 出口IP 下载速度
  jq -r --arg ip "$ip" '.[] | [.name, (if .ok then "正常" else "失败" end),
      (if .ms then "\(.ms) ms" else "-" end),
      (if .egress == "" then "-" elif .egress == $ip then .egress else .egress + " (≠VPS)" end),
      (if .mbps then "\(.mbps) Mbps" else "-" end)] | @tsv' <<<"$r" |
    while IFS=$'\t' read -r a b c d e; do printf '  %-9s %-6s %-9s %-17s %s\n' "$a" "$b" "$c" "$d" "$e"; done
  echo "  说明：在 VPS 本机经各协议实测；延迟≈经该线路访问 Google 的耗时，不含你设备到 VPS 这段。"
}
