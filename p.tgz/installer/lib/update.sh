#!/usr/bin/env bash
# 自动更新：核心（Xray / sing-box）、Geo 规则、定时任务、告警
#
# 核心更新流程：
#   检查正式版 → 冷静期 → 下载并校验 sha256 → 用新核心校验当前配置
#   → 备份旧版 → 替换 → 重启 → 健康检查（服务 + 端口 + 真实出站）
#   → 失败回滚并告警；小版本配置不兼容则保持旧版并告警

LOG_DIR="$SB_HOME/log"
PREV_DIR="$BIN_DIR/prev"

log_event() {  # log_event 类别 内容
  mkdir -p "$LOG_DIR"
  echo "$(date '+%F %T') [$1] $2" >>"$LOG_DIR/events.log"
  # 只保留最近 2000 行
  if (($(wc -l <"$LOG_DIR/events.log") > 2000)); then
    tail -n 1000 "$LOG_DIR/events.log" >"$LOG_DIR/events.log.tmp" && mv "$LOG_DIR/events.log.tmp" "$LOG_DIR/events.log"
  fi
}

# 告警：写日志；接入面板（L2）后由面板转发 Telegram；也可本机直连 Telegram
alert() {
  local msg="[$(st .node_name)] $1"
  warn "告警：$1"
  log_event ALERT "$1"
  if declare -F panel_alert >/dev/null && [[ -n $(st .panel.url) ]]; then
    panel_alert "$msg" && return 0
  fi
  local tok chat
  tok=$(st .tg.token); chat=$(st .tg.chat)
  if [[ -n $tok && -n $chat ]]; then
    curl -4 -fsS --max-time 10 "https://api.telegram.org/bot${tok}/sendMessage" \
      --data-urlencode "chat_id=${chat}" --data-urlencode "text=${msg}" >/dev/null 2>&1 || true
  fi
}

# 版本号 → 三段数字："v1.14.4" -> "1 14 4"
ver_parts() { local v=${1#v}; v=${v%%-*}; IFS=. read -r a b c <<<"$v"; echo "${a:-0} ${b:-0} ${c:-0}"; }
# 比较：ver_gt a b → a 比 b 新
ver_gt() {
  local a b
  read -r -a a <<<"$(ver_parts "$1")"; read -r -a b <<<"$(ver_parts "$2")"
  for i in 0 1 2; do
    ((a[i] > b[i])) && return 0
    ((a[i] < b[i])) && return 1
  done
  return 1
}
# 是否只是补丁版本变化
ver_patch_only() {
  local a b
  read -r -a a <<<"$(ver_parts "$1")"; read -r -a b <<<"$(ver_parts "$2")"
  [[ ${a[0]} == "${b[0]}" && ${a[1]} == "${b[1]}" ]]
}

# 记录更新结果（sb status 显示）
record_result() {  # record_result x|s|geo ok|fail|skip 说明
  local tmp
  tmp=$(mktemp)
  jq --arg k "$1" --arg r "$2" --arg m "$3" --arg t "$(date '+%F %T')" \
    '.upd.result[$k] = {time:$t, result:$r, msg:$m}' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
  chmod 600 "$STATE"
  log_event "UPDATE-$1" "$2 $3"
}

# 回滚到 prev 目录里的旧版本
rollback_core() {  # rollback_core x|s 旧版本号
  local which=$1 old=$2 bin
  bin=$(core_bin "$which")
  [[ -f $PREV_DIR/$(basename "$bin") ]] || { err "没有可回滚的旧版本"; return 1; }
  install -m 755 "$PREV_DIR/$(basename "$bin")" "$bin"
  if [[ $which == x ]]; then st_set_str .core.xray "$old"; else st_set_str .core.singbox "$old"; fi
  restart_core "$which"
}

# 更新单个核心
# update_core x|s [--force 忽略冷静期和同晚限制] [--simulate-fail 模拟健康检查失败]
update_core() {
  local which=$1 force=0 simfail=0 a
  shift
  for a in "$@"; do
    [[ $a == --force ]] && force=1
    [[ $a == --simulate-fail ]] && simfail=1
  done
  local name repo cur rel tag pub age days dir bin other today
  name=$(core_name "$which"); repo=$(core_repo "$which"); cur=$(core_cur "$which")
  bin=$(core_bin "$which"); today=$(date +%F)

  # 两个核心不在同一天更新
  [[ $which == x ]] && other=s || other=x
  if ((!force)) && [[ $(st ".upd.last_date.$other") == "$today" ]]; then
    info "$name：另一个核心今天已更新，改天再更新"
    record_result "$which" skip "另一个核心今天已更新"
    return 0
  fi

  rel=$(gh_latest "$repo") || { record_result "$which" fail "无法访问 GitHub"; alert "$name 更新检查失败：无法访问 GitHub"; return 1; }
  tag=$(jq -r .tag_name <<<"$rel")
  if ! ver_gt "$tag" "$cur" && ((!simfail)); then
    ok "$name 已是最新：$cur"
    record_result "$which" ok "已是最新 $cur"
    return 0
  fi

  # 冷静期：正式版发布满 N 天才更新
  days=$(st .upd.cooldown); days=${days:-3}
  pub=$(date -d "$(jq -r .published_at <<<"$rel")" +%s 2>/dev/null || date +%s)
  age=$((($(date +%s) - pub) / 86400))
  if ((!force && age < days)); then
    info "$name $tag 发布 $age 天，冷静期 $days 天，暂不更新"
    record_result "$which" skip "$tag 处于冷静期（$age/$days 天）"
    return 0
  fi

  info "$name：$cur → $tag"
  dir=$(mktemp -d)
  if ! fetch_core "$which" "$dir" "$rel"; then
    rm -rf "$dir"; record_result "$which" fail "$tag 下载或校验失败"; alert "$name $tag 下载或校验失败，保持 $cur"; return 1
  fi

  # 用新核心校验当前配置（小版本可能不兼容）
  local newbin="$dir/$(basename "$bin")" ok_cfg=1
  if [[ $which == x ]]; then check_xray "$newbin" || ok_cfg=0; else check_singbox "$newbin" || ok_cfg=0; fi
  if ((!ok_cfg)); then
    local why
    why=$(tail -n 3 "$SB_RUN_DIR/$([[ $which == x ]] && echo x || echo s)check.log" | tr '\n' ' ' | cut -c1-200)
    rm -rf "$dir"
    record_result "$which" fail "$tag 与当前配置不兼容，保持 $cur"
    alert "$name $tag 与当前配置不兼容，保持 $cur：$why"
    return 1
  fi
  if ! ver_patch_only "$tag" "$cur"; then
    info "$name 小版本变化（$cur → $tag），配置预检已通过"
  fi

  # 备份旧版 → 替换 → 重启 → 健康检查
  mkdir -p "$PREV_DIR"
  cp -f "$bin" "$PREV_DIR/"
  echo "$cur" >"$PREV_DIR/$(basename "$bin").version"
  install_staged "$which" "$dir" "$tag"
  rm -rf "$dir"

  local hc=1
  if restart_core "$which"; then
    sleep 2
    if ((simfail)); then
      HEALTH_MSG="模拟失败（--simulate-fail）"; hc=0
    elif ! health_check "$which"; then
      hc=0
    fi
  else
    HEALTH_MSG="服务启动失败"; hc=0
  fi

  if ((hc)); then
    ok "$name 已更新到 $tag（$HEALTH_MSG）"
    st_set_str ".upd.last_date.$which" "$today"
    record_result "$which" ok "$cur → $tag"
    log_event UPDATE "$name $cur → $tag 成功"
    return 0
  fi

  local reason=$HEALTH_MSG
  err "$name $tag 健康检查失败：$reason，回滚到 $cur"
  if rollback_core "$which" "$cur" && health_check "$which"; then
    record_result "$which" fail "$tag 健康检查失败，已回滚到 $cur"
    alert "$name 更新到 $tag 失败（$reason），已自动回滚到 $cur"
  else
    record_result "$which" fail "$tag 失败且回滚后仍异常"
    alert "$name 更新到 $tag 失败（$reason），回滚后仍异常（$HEALTH_MSG），请尽快检查！"
  fi
  return 1
}

# ---------- Geo 规则 ----------
# Xray：Loyalsoldier/v2ray-rules-dat（带 sha256）；sing-box：SagerNet rule-set
GEO_DAT_BASE=https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download

update_geo() {
  local t f ok_all=1
  t=$(mktemp -d)
  info "更新 Geo 规则..."
  for f in geoip.dat geosite.dat; do
    local sha
    sha=$(curl -4 -fsSL --max-time 30 "$GEO_DAT_BASE/$f.sha256sum" | awk '{print $1}')
    if [[ -z $sha ]] || ! dl_verify "$GEO_DAT_BASE/$f" "$sha" "$t/$f"; then ok_all=0; break; fi
  done
  if ((!ok_all)); then
    rm -rf "$t"; record_result geo fail "Xray Geo 文件下载失败"; alert "Geo 规则下载失败，保持旧版"; return 1
  fi
  # 备份旧文件，替换后用 Xray 校验
  rm -rf "$PREV_DIR/geo"; mkdir -p "$PREV_DIR/geo/rules"
  cp -f "$BIN_DIR"/geo*.dat "$PREV_DIR/geo/" 2>/dev/null
  cp -a "$ETC_DIR/rules/." "$PREV_DIR/geo/rules/" 2>/dev/null
  install -m 644 "$t"/geo*.dat "$BIN_DIR/"
  rm -rf "$t"
  local good=1
  fetch_rulesets || good=0
  st_set .geo.managed true
  render_xray && render_singbox || good=0
  ((good)) && restart_core x && restart_core s && health_check all || good=0
  if ((good)); then
    record_result geo ok "已更新"
    ok "Geo 规则已更新"
    return 0
  fi
  err "Geo 更新后检查失败，回滚"
  install -m 644 "$PREV_DIR/geo"/geo*.dat "$BIN_DIR/"
  cp -a "$PREV_DIR/geo/rules/." "$ETC_DIR/rules/"
  render_xray; render_singbox; restart_core x; restart_core s
  record_result geo fail "更新后检查失败，已回滚"
  alert "Geo 规则更新后检查失败（$HEALTH_MSG），已回滚"
  return 1
}

# ---------- 定时任务（systemd timer） ----------
# 默认值：Xray 04:00、sing-box 04:30（北京时间），Geo 每周日 05:00，备份 03:30，脚本自更新 05:30，IP 检测每 5 分钟
upd_defaults() {
  [[ -n $(st .upd.cooldown) ]] && return
  local tmp
  tmp=$(mktemp)
  jq '.upd = (.upd // {}) + {
        cooldown: 3,
        xray: {enabled: true, time: "04:00"},
        singbox: {enabled: true, time: "04:30"},
        geo: {enabled: true},
        self: {enabled: true},
        result: {}, last_date: {}
      }' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
  chmod 600 "$STATE"
}

TZ_PLAN=Asia/Shanghai

# write_timer 名称 OnCalendar 说明
write_timer() {
  local name=$1 cal=$2 desc=$3
  cat >/etc/systemd/system/${SB_NAME}-${name}.service <<EOF
[Unit]
Description=${SB_NAME} ${desc}
After=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/sb cron ${name}
EOF
  cat >/etc/systemd/system/${SB_NAME}-${name}.timer <<EOF
[Unit]
Description=${SB_NAME} ${desc} timer

[Timer]
OnCalendar=${cal}
RandomizedDelaySec=${4:-300}
Persistent=true

[Install]
WantedBy=timers.target
EOF
}

TIMERS=(upd-x upd-s geo self backup ipwatch)

install_timers() {
  upd_defaults
  write_timer upd-x "*-*-* $(st .upd.xray.time):00 $TZ_PLAN" "xray update"
  write_timer upd-s "*-*-* $(st .upd.singbox.time):00 $TZ_PLAN" "sing-box update"
  write_timer geo "Sun *-*-* 05:00:00 $TZ_PLAN" "geo update"
  write_timer self "*-*-* 05:30:00 $TZ_PLAN" "self update"
  write_timer backup "*-*-* 03:30:00 $TZ_PLAN" "backup"
  write_timer ipwatch "*:0/5" "ip watch" 30
  systemctl daemon-reload
  local t key
  for t in "${TIMERS[@]}"; do
    case $t in
      upd-x) key=.upd.xray.enabled ;; upd-s) key=.upd.singbox.enabled ;;
      geo) key=.upd.geo.enabled ;; self) key=.upd.self.enabled ;; *) key="" ;;
    esac
    if [[ -z $key || $(st "$key") != false ]]; then
      systemctl enable --now "${SB_NAME}-$t.timer" >/dev/null 2>&1
    else
      systemctl disable --now "${SB_NAME}-$t.timer" >/dev/null 2>&1
    fi
  done
  ok "定时任务已设置"
}

remove_timers() {
  local t
  for t in "${TIMERS[@]}"; do
    systemctl disable --now "${SB_NAME}-$t.timer" >/dev/null 2>&1
    rm -f /etc/systemd/system/${SB_NAME}-$t.{timer,service}
  done
  systemctl daemon-reload
}

# 定时任务入口：sb cron <任务>
cron_run() {
  # Each task acquires the shared mutation lock through its guarded entry point.
  case $1 in
    upd-x) update_core x ;;
    upd-s) update_core s ;;
    geo) update_geo ;;
    self) declare -F self_update >/dev/null && self_update ;;
    backup) backup_create auto; egress_refresh ;;
    ipwatch) declare -F traffic_tick >/dev/null && traffic_tick; ip_watch ;;
    cert) declare -F cert_cron >/dev/null && cert_cron ;;
    report) declare -F panel_report >/dev/null && panel_report ;;
    *) err "未知任务 $1"; return 1 ;;
  esac
}

# ---------- 公网 IP 变化检测 ----------
ip_watch() {
  local now old
  now=$(get_ipv4)
  valid_public_ipv4 "$now" || { st_set .ip_pending null; return 0; }
  old=$(st .ip)
  if [[ $now == "$old" ]]; then
    st_set .ip_pending null
    if [[ $(st .dns_pending) == true && $(st .l1.enabled) == true ]]; then
      if dns_sync; then st_set .dns_pending false; fi
    fi
    return 0
  fi
  # 连续两次检测到同一新 IP 才确认，避免偶发误判
  if [[ $(st .ip_pending) != "$now" ]]; then
    st_set_str .ip_pending "$now"; return 0
  fi
  st_set_str .ip "$now"; st_set .ip_pending null
  gen_outputs
  log_event IP "$old → $now"
  if declare -F dns_sync >/dev/null && [[ $(st .level) -ge 1 ]]; then
    st_set .dns_pending true
    if dns_sync; then
      st_set .dns_pending false
      alert "公网 IP 变化 $old → $now，DNS 已自动更新"
    else
      alert "公网 IP 变化 $old → $now，DNS 更新失败，将自动重试"
    fi
  else
    alert "公网 IP 变化 $old → $now，请在客户端重新导入节点（或升级到 L1 自动更新 DNS）"
  fi
  declare -F panel_report >/dev/null && panel_report >/dev/null 2>&1
  return 0
}

# ---------- 更新设置菜单 ----------
menu_update() {
  upd_defaults
  while :; do
    clear
    title "更新设置"
    echo "   ${C_BLU}1${C_RST}  Xray 自动更新      $(onoff "$(st .upd.xray.enabled)")  每天 $(st .upd.xray.time)（北京时间）"
    echo "   ${C_BLU}2${C_RST}  sing-box 自动更新  $(onoff "$(st .upd.singbox.enabled)")  每天 $(st .upd.singbox.time)"
    echo "   ${C_BLU}3${C_RST}  Geo 规则自动更新   $(onoff "$(st .upd.geo.enabled)")  每周日 05:00"
    echo "   ${C_BLU}4${C_RST}  脚本自动更新       $(onoff "$(st .upd.self.enabled)")  每天 05:30"
    echo "   ${C_BLU}5${C_RST}  冷静期             $(st .upd.cooldown) 天"
    echo "   ${C_BLU}6${C_RST}  修改更新时间"
    echo "   ${C_BLU}7${C_RST}  立即检查更新（遵守冷静期）"
    echo "   ${C_BLU}8${C_RST}  立即强制更新（忽略冷静期）"
    echo "   ${C_BLU}9${C_RST}  回滚核心到上一版本"
    echo "   ${C_BLU}t${C_RST}  模拟一次失败的更新（验证自动回滚）"
    echo "   ${C_BLU}0${C_RST}  返回"
    case $(ask "选择" 0) in
      1) toggle .upd.xray.enabled; install_timers ;;
      2) toggle .upd.singbox.enabled; install_timers ;;
      3) toggle .upd.geo.enabled; install_timers ;;
      4) toggle .upd.self.enabled; install_timers ;;
      5) local d; d=$(ask "冷静期天数（0-30）" "$(st .upd.cooldown)")
         [[ $d =~ ^[0-9]+$ ]] && ((d <= 30)) && st_set .upd.cooldown "$d" ;;
      6) local tx ts
         tx=$(ask "Xray 更新时间 HH:MM" "$(st .upd.xray.time)")
         ts=$(ask "sing-box 更新时间 HH:MM" "$(st .upd.singbox.time)")
         [[ $tx =~ ^[0-2][0-9]:[0-5][0-9]$ ]] && st_set_str .upd.xray.time "$tx"
         [[ $ts =~ ^[0-2][0-9]:[0-5][0-9]$ ]] && st_set_str .upd.singbox.time "$ts"
         install_timers ;;
      7) update_core x; update_core s ;;
      8) update_core x --force; update_core s --force ;;
      9) local c; c=$(ask "回滚哪个（x=Xray / s=sing-box）" x)
         [[ $c == x || $c == s ]] && rollback_core "$c" "$(cat "$PREV_DIR/$(basename "$(core_bin "$c")").version" 2>/dev/null || echo 旧版)" ;;
      t) local c; c=$(ask "模拟哪个（x / s）" s)
         [[ $c == x || $c == s ]] && update_core "$c" --force --simulate-fail ;;
      0|"") return ;;
    esac
    pause
  done
}
