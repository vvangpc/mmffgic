#!/usr/bin/env bash
# 统一加载所有模块（install.sh / sb.sh 共用）
for _m in common system core config share update users backup domain panel self welcome install; do
  # shellcheck disable=SC1090
  [[ -f $SB_HOME/lib/$_m.sh ]] && . "$SB_HOME/lib/$_m.sh"
done
unset _m
case "$(uname -m)" in aarch64|arm64) ARCH=arm64 ;; *) ARCH=amd64 ;; esac

. "$SB_HOME/lib/reliable.sh"
