#!/usr/bin/env bash
# 配置层：状态初始化、密钥/证书生成、渲染 Xray / sing-box 配置

# Reality 候选伪装站点：小众开源项目站点（不用大厂域名），均支持 TLS1.3 + H2
# 安装时在 VPS 上实测，按握手延迟排序供选择
REALITY_CANDIDATES=(
  www.blender.org www.kernel.org www.debian.org www.gimp.org www.openssl.org
  www.php.net www.postgresql.org www.wireshark.org www.libreoffice.org www.videolan.org
)
DEF_HY2_SNI=www.gimp.org
GEO_CN_IP=https://raw.githubusercontent.com/SagerNet/sing-geoip/rule-set/geoip-cn.srs
GEO_SITE_BASE=https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set
# 回国屏蔽：先放行这些境外也在用的域名（geosite:cn 里含 gstatic/apple 等，会误伤测速和正常访问）
CN_EXCEPT=(google apple)

xray_needed() { [[ $(st .proto.vision.enabled) == true || $(st .proto.xhttp.enabled) == true || $(proto_on cdn) == true ]]; }
sbox_needed() {
  local k
  for k in hy2 tuic hy2tls anytls naive; do [[ $(proto_on "$k") == true ]] && return 0; done
  return 1
}

# 初始空状态（安装时调用一次；重装时保留已有参数）
state_init() {
  mkdir -p "$ETC_DIR" "$CERT_DIR" "$OUT_DIR" "$ETC_DIR/rules"
  chmod 700 "$ETC_DIR"
  [[ -s $STATE ]] && return 0
  cat >"$STATE" <<'EOF'
{
  "schema": 1,
  "level": 0,
  "ip": "",
  "node_name": "",
  "egress": {},
  "core": {"xray": "", "singbox": ""},
  "reality": {"sni": "", "private_key": "", "public_key": "", "short_id": ""},
  "xhttp_path": "",
  "hy2": {"sni": "", "pin": ""},
  "proto": {
    "vision": {"enabled": true, "port": 443},
    "xhttp":  {"enabled": false, "port": 8443},
    "hy2":    {"enabled": true, "port": 443, "hop_enabled": true, "hop": "20000-30000"},
    "tuic":   {"enabled": false, "port": null},
    "anytls": {"enabled": false, "port": null},
    "naive":  {"enabled": false, "port": null}
  },
  "block": {"cn": true, "bt": true},
  "users": []
}
EOF
  chmod 600 "$STATE"
}

# 老版本状态补字段（每次运行 sb 时调用，已有就不动）
state_migrate() {
  [[ -s $STATE ]] || return 0
  [[ $(jq -r '.proto | has("tuic") and has("anytls") and has("naive")' "$STATE" 2>/dev/null) == true ]] && return 0
  local tmp; tmp=$(mktemp)
  jq '.proto.tuic //= {enabled: false, port: null}
      | .proto.anytls //= {enabled: false, port: null}
      | .proto.naive //= {enabled: false, port: null}' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
  chmod 600 "$STATE"
}

# ---------- 协议目录 ----------
# 可开关的线路：key  显示名  传输  是否需要 L1
PROTO_KEYS=(vision xhttp hy2 tuic anytls naive hy2tls cdn)
proto_label() {
  case $1 in
    vision) echo "VLESS-Reality-Vision" ;; xhttp) echo "VLESS-Reality-XHTTP" ;;
    hy2) echo "Hysteria2" ;; tuic) echo "TUIC v5" ;; anytls) echo "AnyTLS" ;; naive) echo "NaiveProxy" ;;
    hy2tls) echo "Hysteria2-TLS" ;; cdn) echo "VLESS-XHTTP-CDN" ;;
    hop) echo "Hy2 端口跳跃" ;; blockcn) echo "屏蔽回国" ;; blockbt) echo "屏蔽 BT" ;;
  esac
}
proto_net() { case $1 in hy2|tuic|hy2tls) echo udp ;; *) echo tcp ;; esac; }
proto_needs_l1() { [[ $1 == tuic || $1 == anytls || $1 == naive || $1 == hy2tls || $1 == cdn ]]; }
proto_path() {  # 状态里的开关字段
  case $1 in
    vision|xhttp|hy2|tuic|anytls|naive) echo ".proto.$1.enabled" ;;
    hop) echo .proto.hy2.hop_enabled ;; hy2tls) echo .l1.hy2tls_enabled ;; cdn) echo .l1.cdn_enabled ;;
    blockcn) echo .block.cn ;; blockbt) echo .block.bt ;;
    *) return 1 ;;
  esac
}
proto_port_path() { case $1 in hy2tls) echo .l1.hy2tls_port ;; cdn) echo .l1.cdn_port ;; *) echo ".proto.$1.port" ;; esac; }
proto_port() { st "$(proto_port_path "$1")"; }
# 实际生效：开关打开，且需要 L1 的线路已经是 L1
proto_on() {
  local p; p=$(proto_path "$1") || { echo false; return; }
  if proto_needs_l1 "$1" && [[ $(st .l1.enabled) != true ]]; then echo false; return; fi
  [[ $(st "$p") == true ]] && echo true || echo false
}
proto_count_on() { local k n=0; for k in "${PROTO_KEYS[@]}"; do [[ $(proto_on "$k") == true ]] && ((n++)); done; echo $n; }

# 本脚本已占用的端口（port_busy 会忽略 xray / sing-box 自己监听的端口，所以要单独查状态）
state_ports() {  # state_ports tcp|udp
  jq -r --arg p "$1" '
    [ if $p == "tcp" then .proto.vision.port, .proto.xhttp.port, .proto.anytls.port, .proto.naive.port,
        .l1.cdn_port, .l1.decoy_port, .l1.cdn_inner, .panel.agent_port
      else .proto.hy2.port, .proto.tuic.port, .l1.hy2tls_port end ]
    | map(select(. != null)) | .[]' "$STATE"
}
in_hop_range() {  # UDP 端口是否落在端口跳跃段里（会被 nft 重定向走）
  local r a b
  for r in "$(st .proto.hy2.hop)" "$(st .l1.hop2)"; do
    [[ $r =~ ^([0-9]+)-([0-9]+)$ ]] || continue
    a=${BASH_REMATCH[1]}; b=${BASH_REMATCH[2]}
    (($1 >= a && $1 <= b)) && return 0
  done
  return 1
}
free_port() {  # free_port tcp|udp 候选端口...
  local proto=$1 p used i; shift
  used=" $(state_ports "$proto" | tr '\n' ' ') "
  for p in "$@" $(for i in {1..60}; do echo $((RANDOM % 15000 + 31000)); done); do
    [[ $used == *" $p "* ]] && continue
    [[ $proto == udp ]] && in_hop_range "$p" && continue
    port_busy "$proto" "$p" && continue
    echo "$p"; return 0
  done
  return 1
}
proto_alloc_port() {  # 第一次开启时分配端口
  local k=$1 p
  [[ $k == tuic || $k == anytls || $k == naive ]] || return 0
  [[ -n $(st ".proto.$k.port") ]] && return 0
  case $k in
    tuic) p=$(free_port udp 2443 4443 6443 10443 11443) ;;
    anytls) p=$(free_port tcp 4443 6443 9443 10443 11443) ;;
    naive) p=$(free_port tcp 7443 6443 9443 12443 13443) ;;
  esac
  [[ -n $p ]] || { err "找不到空闲端口"; return 1; }
  st_set ".proto.$k.port" "$p"
}

# 只改状态，不应用：proto_stage <key> on|off   出错返回非 0 并输出原因
proto_stage() {
  local k=$1 v=$2 path
  path=$(proto_path "$k") || { echo "未知协议：$k"; return 2; }
  [[ $v == on || $v == off ]] || { echo "参数错误：$v"; return 2; }
  if [[ $v == on ]] && proto_needs_l1 "$k" && [[ $(st .l1.enabled) != true ]]; then
    echo "$(proto_label "$k") 需要域名真证书，请先升级 L1（sb → 4）"; return 2
  fi
  [[ $v == on ]] && { proto_alloc_port "$k" || { echo "$(proto_label "$k") 分配端口失败"; return 1; }; }
  st_set "$path" "$([[ $v == on ]] && echo true || echo false)"
}

# CDN 线路开关的附带动作：DNS 记录、证书
proto_cdn_side() {
  declare -F dns_sync >/dev/null || return 0
  if [[ $(st .l1.cdn_enabled) == true ]]; then
    dns_sync; [[ -s $CERT_DIR/cdn.crt ]] || cdn_cert_issue
  else
    cf_delete_record "$(st .l1.cdn_zone_id)" "$(st .l1.cdn_host)"
  fi
}

# 改开关并应用：proto_set <key> on|off
proto_set() {
  local k=$1 v=$2 before msg which
  before=$(proto_on "$k")
  msg=$(proto_stage "$k" "$v") || { err "$msg"; return 2; }
  if [[ $(proto_count_on) == 0 ]]; then
    st_set "$(proto_path "$k")" true; err "至少要保留一条线路"; return 2
  fi
  [[ $k == cdn && $(proto_on cdn) != "$before" ]] && proto_cdn_side
  case $k in vision|xhttp) which=x ;; hy2|hop|tuic|anytls|naive|hy2tls) which=s ;; *) which=all ;; esac
  apply_config "$which"
}

# 一次设定全部线路：proto_apply_set <开启的 key 用 . 连接>   例：vision.hy2.tuic
# 面板「协议」勾选后点「应用」走这里，只重启一次
proto_apply_set() {
  local want=".$1." k v changed=() msg cdn0
  cdn0=$(proto_on cdn)
  for k in "${PROTO_KEYS[@]}" hop; do
    [[ $want == *".$k."* ]] && v=on || v=off
    # 没有 L1 时，需要 L1 的线路保持原样（面板上是灰的）
    proto_needs_l1 "$k" && [[ $(st .l1.enabled) != true ]] && continue
    [[ $v == on && $(st "$(proto_path "$k")") == true ]] && continue
    [[ $v == off && $(st "$(proto_path "$k")") != true ]] && continue
    changed+=("$k:$v")
  done
  ((${#changed[@]})) || { echo "没有变化"; return 0; }
  local bak; bak=$(mktemp); cp -f "$STATE" "$bak"
  for k in "${changed[@]}"; do
    msg=$(proto_stage "${k%%:*}" "${k#*:}") || { cp -f "$bak" "$STATE"; rm -f "$bak"; echo "$msg"; return 2; }
  done
  if [[ $(proto_count_on) == 0 ]]; then cp -f "$bak" "$STATE"; rm -f "$bak"; echo "至少要保留一条线路"; return 2; fi
  rm -f "$bak"
  [[ $(proto_on cdn) != "$cdn0" ]] && proto_cdn_side
  for k in "${changed[@]}"; do echo "$(proto_label "${k%%:*}")：$([[ ${k#*:} == on ]] && echo 开启 || echo 关闭)"; done
  apply_config all
}

# 生成 Reality 密钥（兼容新旧 xray x25519 输出格式）
gen_reality_keys() {
  local out priv pub
  out=$("$XRAY_BIN" x25519)
  priv=$(awk -F': *' 'tolower($1) ~ /^private ?key/ {print $2; exit}' <<<"$out")
  pub=$(awk -F': *' 'tolower($1) ~ /^(public ?key|password)/ {print $2; exit}' <<<"$out")
  if [[ -n $priv && -z $pub ]]; then
    pub=$("$XRAY_BIN" x25519 -i "$priv" | awk -F': *' 'tolower($1) ~ /^(public ?key|password)/ {print $2; exit}')
  fi
  [[ -n $priv && -n $pub ]] || die "Reality 密钥生成失败：$out"
  st_set_str .reality.private_key "$priv"
  st_set_str .reality.public_key "$pub"
  st_set_str .reality.short_id "$(rand_hex 8)"
}

# 检查 Reality 目标站是否支持 TLS1.3 + H2（只走 v4）
check_reality_target() {
  local sni=$1
  curl -4 -sS -o /dev/null --max-time 8 --tlsv1.3 --http2 -w '%{http_version}' "https://$sni" 2>/dev/null | grep -q '^2'
}

# 并发实测候选站点，输出 "毫秒 域名"（只含通过的，按延迟升序）
probe_reality_targets() {
  local d tmp
  tmp=$(mktemp -d)
  for d in "${REALITY_CANDIDATES[@]}"; do
    (
      r=$(curl -4 -sS -o /dev/null --max-time 8 --tlsv1.3 --http2 \
        -w '%{http_version} %{time_appconnect}' "https://$d" 2>/dev/null)
      [[ $r == 2* ]] && awk -v t="${r#* }" -v d="$d" 'BEGIN{printf "%d %s\n", t*1000, d}' >"$tmp/$d"
    ) &
  done
  wait
  cat "$tmp"/* 2>/dev/null | sort -n
  rm -rf "$tmp"
}

# 交互选择伪装站点，结果输出到 stdout（提示走 stderr）
choose_reality_sni() {
  local list=() lines i sel d
  info "实测候选伪装站点（TLS1.3 + H2）..." >&2
  mapfile -t lines < <(probe_reality_targets)
  if ((${#lines[@]} == 0)); then
    warn "候选站点全部检测失败，请手动输入" >&2
  else
    for i in "${!lines[@]}"; do
      list+=("${lines[i]#* }")
      printf "  %2d. %-24s %5sms\n" $((i + 1)) "${lines[i]#* }" "${lines[i]%% *}" >&2
    done
    echo "   c. 自定义域名" >&2
    [[ ${AUTO_YES:-0} == 1 ]] && { echo "${list[0]}"; return; }
    sel=$(ask "选择（默认最快的）" 1)
    if [[ $sel =~ ^[0-9]+$ ]] && ((sel >= 1 && sel <= ${#list[@]})); then
      echo "${list[sel - 1]}"; return
    fi
  fi
  [[ ${AUTO_YES:-0} == 1 ]] && die "没有可用的伪装站点"
  while :; do
    d=$(ask "输入伪装站点域名")
    [[ -n $d ]] || continue
    if check_reality_target "$d"; then echo "$d"; return; fi
    warn "$d 检测不通过（不可达或不支持 TLS1.3/H2）" >&2
    confirm "仍然使用 $d？" n && { echo "$d"; return; }
  done
}

# 生成 Hy2 自签证书（ECDSA，长期有效），记录证书 sha256 指纹用于客户端固定
gen_hy2_cert() {
  local sni=$1
  openssl ecparam -genkey -name prime256v1 -out "$CERT_DIR/hy2.key" 2>/dev/null
  openssl req -new -x509 -days 36500 -key "$CERT_DIR/hy2.key" -out "$CERT_DIR/hy2.crt" -subj "/CN=$sni" \
    -addext "subjectAltName=DNS:$sni" 2>/dev/null || die "自签证书生成失败"
  chmod 600 "$CERT_DIR/hy2.key"
  st_set_str .hy2.pin "$(openssl x509 -noout -fingerprint -sha256 -in "$CERT_DIR/hy2.crt" | cut -d= -f2)"
}

add_user() {  # add_user 名称
  local name=$1 tmp
  tmp=$(mktemp)
  jq --arg n "$name" --arg u "$(gen_uuid)" --arg p "$(rand_hex 16)" \
    '.users += [{"name":$n,"uuid":$u,"hy2":$p,"enabled":true}]' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
  chmod 600 "$STATE"
}

# 下载 sing-box 用的 CN 规则集（本地文件，避免启动时依赖 GitHub）
fetch_rulesets() {
  local name url t commit repo path
  t=$(mktemp -d "$SB_HOME/.rules.XXXXXX") || return 1
  for repo in sing-geoip sing-geosite; do
    commit=$(curl -4 -fsSL --max-time 30 "$GH_API/SagerNet/$repo/commits/rule-set" | jq -r .sha) || { rm -rf "$t"; return 1; }
    [[ $commit =~ ^[a-f0-9]{40}$ ]] || { rm -rf "$t"; return 1; }
    local names=(geoip-cn)
    [[ $repo != sing-geosite ]] || names=(geosite-cn "${CN_EXCEPT[@]/#/geosite-}")
    for name in "${names[@]}"; do
      url="https://raw.githubusercontent.com/SagerNet/$repo/$commit/$name.srs"
      curl -4 -fsSL --retry 2 --max-time 60 -o "$t/$name.srs" "$url" &&
        "$SBOX_BIN" rule-set decompile --output "$t/check.json" "$t/$name.srs" >/dev/null 2>&1 || { rm -rf "$t"; err "规则集校验失败，保留旧规则"; return 1; }
      echo "$repo $commit $name $(sha256sum "$t/$name.srs" | cut -d' ' -f1)" >>"$t/manifest"
    done
  done
  rm -f "$t/check.json"
  switch_tree "$ETC_DIR/rules" "$t" || return 1
  ok "sing-box 规则集已校验并切换"
}

# ---------- Xray 配置 ----------
render_xray() {
  jq -n --slurpfile s "$STATE" '
    $s[0] as $st
    | ($st.users | map(select(.enabled))) as $u
    | ($st.l1 // {}) as $l1
    | ($l1.enabled == true) as $L1
    | {
        sni: $st.reality.sni, pk: $st.reality.private_key, sid: $st.reality.short_id
      } as $r
    # L1 偷自己：目标站改为本机伪装站（自己域名的真证书），原伪装域名仍可连接
    | def reality: {
        target: (if $L1 then "127.0.0.1:\($l1.decoy_port)" else ($r.sni + ":443") end),
        serverNames: ([$r.sni] + (if $L1 then [$l1.direct_host] else [] end)),
        privateKey: $r.pk,
        shortIds: [$r.sid]
      };
      def sniff: {enabled: true, destOverride: ["http","tls","quic"], routeOnly: true};
    {
      log: {loglevel: "warning", access: "none"},
      dns: {servers: ["1.1.1.1","8.8.8.8"], queryStrategy: "UseIPv4"},
      inbounds: (
        (if $st.proto.vision.enabled then [{
          tag: "vision", listen: "0.0.0.0", port: $st.proto.vision.port, protocol: "vless",
          settings: {clients: ($u | map({id: .uuid, email: .name, flow: "xtls-rprx-vision"})), decryption: "none"},
          streamSettings: {network: "raw", security: "reality", realitySettings: reality},
          sniffing: sniff
        }] else [] end)
        +
        (if $st.proto.xhttp.enabled then [{
          tag: "xhttp", listen: "0.0.0.0", port: $st.proto.xhttp.port, protocol: "vless",
          settings: {clients: ($u | map({id: .uuid, email: .name})), decryption: "none"},
          streamSettings: {network: "xhttp", xhttpSettings: {path: $st.xhttp_path, mode: "auto"},
                           security: "reality", realitySettings: reality},
          sniffing: sniff
        }] else [] end)
        +
        # L1 CDN 线路：nginx(TLS，CF 回源) → grpc_pass → 这里（明文 h2c，只监听本机）
        (if $L1 and $l1.cdn_enabled then [{
          tag: "cdn", listen: "127.0.0.1", port: $l1.cdn_inner, protocol: "vless",
          settings: {clients: ($u | map({id: .uuid, email: .name})), decryption: "none"},
          streamSettings: {network: "xhttp", xhttpSettings: {path: $l1.cdn_path, mode: "auto"}},
          sniffing: sniff
        }] else [] end)
      ),
      outbounds: [
        {tag: "direct", protocol: "freedom", streamSettings: {sockopt: {domainStrategy: "UseIPv4"}}},
        {tag: "block", protocol: "blackhole"}
      ],
      routing: {
        domainStrategy: "IPIfNonMatch",
        rules: (
          [{type: "field", ip: ["geoip:private"], outboundTag: "block"}]
          + (if $st.block.bt then [{type: "field", protocol: ["bittorrent"], outboundTag: "block"}] else [] end)
          # 回国屏蔽：先放行 Google/Apple（geosite:cn 含 gstatic 等），再按域名、IP 屏蔽
          + (if $st.block.cn then [
              {type: "field", domain: ["geosite:google", "geosite:apple"], outboundTag: "direct"},
              {type: "field", domain: ["geosite:cn"], outboundTag: "block"},
              {type: "field", ip: ["geoip:cn"], outboundTag: "block"}
            ] else [] end)
        )
      }
    }' >"$XRAY_CONF.new" || return 1
  mv "$XRAY_CONF.new" "$XRAY_CONF"
  chmod 600 "$XRAY_CONF"
}

# ---------- sing-box 配置（1.12+ 新格式：类型化 DNS、规则动作） ----------
render_singbox() {
  local r have_rules=true
  for r in geoip-cn geosite-cn geosite-google geosite-apple; do [[ -s $ETC_DIR/rules/$r.srs ]] || have_rules=false; done
  jq -n --slurpfile s "$STATE" --arg cert "$CERT_DIR/hy2.crt" --arg key "$CERT_DIR/hy2.key" \
    --arg dcert "$CERT_DIR/direct.crt" --arg dkey "$CERT_DIR/direct.key" \
    --arg rules "$ETC_DIR/rules" --argjson have_rules "$have_rules" '
    $s[0] as $st
    | ($st.users | map(select(.enabled))) as $u
    | ($st.l1 // {}) as $l1
    | ($l1.enabled == true) as $L1
    | ($st.block.cn and $have_rules) as $cn
    | {server: "dns", strategy: "ipv4_only"} as $res
    | {
      log: {level: "warn", timestamp: false},
      dns: {servers: [{type: "udp", tag: "dns", server: "1.1.1.1"}], strategy: "ipv4_only"},
      inbounds: (
        (if $st.proto.hy2.enabled then [{
          type: "hysteria2", tag: "hy2", listen: "0.0.0.0", listen_port: $st.proto.hy2.port,
          users: ($u | map({name: .name, password: .hy2})),
          masquerade: ("https://" + $st.hy2.sni),
          tls: {enabled: true, alpn: ["h3"], certificate_path: $cert, key_path: $key}
        }] else [] end)
        +
        (if $L1 and $l1.hy2tls_enabled then [{
          type: "hysteria2", tag: "hy2tls", listen: "0.0.0.0", listen_port: $l1.hy2tls_port,
          users: ($u | map({name: .name, password: .hy2})),
          masquerade: ("https://" + $st.hy2.sni),
          tls: {enabled: true, alpn: ["h3"], certificate_path: $dcert, key_path: $dkey}
        }] else [] end)
        +
        # TUIC v5：L1 用域名真证书，L0 与 Hy2 共用自签证书
        (if $L1 and ($st.proto.tuic.enabled // false) and $st.proto.tuic.port != null then [{
          type: "tuic", tag: "tuic", listen: "0.0.0.0", listen_port: $st.proto.tuic.port,
          users: ($u | map({name: .name, uuid: .uuid, password: .hy2})),
          congestion_control: "bbr", zero_rtt_handshake: false,
          tls: {enabled: true, alpn: ["h3"],
                certificate_path: (if $L1 then $dcert else $cert end), key_path: (if $L1 then $dkey else $key end)}
        }] else [] end)
        +
        # AnyTLS / NaiveProxy：只在 L1（域名真证书）下启用
        (if $L1 and ($st.proto.anytls.enabled // false) and $st.proto.anytls.port != null then [{
          type: "anytls", tag: "anytls", listen: "0.0.0.0", listen_port: $st.proto.anytls.port,
          users: ($u | map({name: .name, password: .hy2})),
          tls: {enabled: true, certificate_path: $dcert, key_path: $dkey}
        }] else [] end)
        +
        (if $L1 and ($st.proto.naive.enabled // false) and $st.proto.naive.port != null then [{
          type: "naive", tag: "naive", listen: "0.0.0.0", listen_port: $st.proto.naive.port, network: "tcp",
          users: ($u | map({username: .name, password: .hy2})),
          tls: {enabled: true, alpn: ["h2", "http/1.1"], certificate_path: $dcert, key_path: $dkey}
        }] else [] end)
      ),
      outbounds: [{type: "direct", tag: "direct", domain_resolver: $res}],
      route: {
        default_domain_resolver: $res,
        rule_set: (if $cn then [
          {type: "local", tag: "geoip-cn", format: "binary", path: ($rules + "/geoip-cn.srs")},
          {type: "local", tag: "geosite-cn", format: "binary", path: ($rules + "/geosite-cn.srs")},
          {type: "local", tag: "geosite-except", format: "binary", path: ($rules + "/geosite-google.srs")},
          {type: "local", tag: "geosite-except-2", format: "binary", path: ($rules + "/geosite-apple.srs")}
        ] else [] end),
        rules: (
          [{action: "sniff"}]
          + (if $st.block.bt then [{protocol: "bittorrent", action: "reject"}] else [] end)
          + (if $cn then [
              {rule_set: ["geosite-except", "geosite-except-2"], action: "route", outbound: "direct"},
              {rule_set: ["geosite-cn"], action: "reject"}
            ] else [] end)
          + [{action: "resolve", strategy: "ipv4_only"}]
          + [{ip_is_private: true, action: "reject"}]
          + (if $cn then [{rule_set: ["geoip-cn"], action: "reject"}] else [] end)
        ),
        final: "direct"
      }
    }' >"$SBOX_CONF.new" || return 1
  mv "$SBOX_CONF.new" "$SBOX_CONF"
  chmod 600 "$SBOX_CONF"
}

# 端口跳跃规则：根据状态组装
hop_sync() {
  local specs=()
  if [[ $(st .proto.hy2.enabled) == true && $(st .proto.hy2.hop_enabled) == true ]]; then
    specs+=("$(st .proto.hy2.hop):$(st .proto.hy2.port):hop")
  fi
  if [[ $(st .l1.enabled) == true && $(st .l1.hy2tls_enabled) == true && -n $(st .l1.hop2) ]]; then
    specs+=("$(st .l1.hop2):$(st .l1.hy2tls_port):hop2")
  fi
  if ((${#specs[@]})); then hop_apply "${specs[@]}"; else hop_remove; fi
}

# 重新生成并重启：apply_config [x|s|all]
apply_config() {
  local which=${1:-all} rc=0
  if [[ $which == all || $which == x ]]; then render_xray || return 1; xray_needed && { check_xray || return 1; }; fi
  if [[ $which == all || $which == s ]]; then render_singbox || return 1; sbox_needed && { check_singbox || return 1; }; fi
  if [[ $which == all || $which == x ]]; then restart_core x || rc=1; fi
  if [[ $which == all || $which == s ]]; then restart_core s || rc=1; hop_sync || rc=1; fi
  if [[ $(st .l1.enabled) == true ]] && declare -F nginx_apply >/dev/null; then nginx_apply || rc=1; fi
  firewall_sync || rc=1
  gen_outputs || rc=1
  return $rc
}
