#!/usr/bin/env bash
# Ed25519 signature binds the payload and version to the maintainer key.
release_verify() {
  local dir=$1 pub=$2 version=$3 sha declared lines
  [[ -s $dir/manifest && -s $dir/manifest.sig && -s $pub ]] || return 1
  openssl pkeyutl -verify -pubin -inkey "$pub" -rawin -in "$dir/manifest" -sigfile "$dir/manifest.sig" >/dev/null 2>&1 || return 1
  # 旧更新器只接受两行清单，因此会在触碰脚本和备份之前拒绝这个包。
  lines=$(wc -l <"$dir/manifest") || return 1
  if [[ $lines != 3 || $(sed -n '3p' "$dir/manifest") != manifest-v2 ]]; then
    [[ ${4:-} == reinstall && $lines == 2 ]] || return 1
  fi
  declared=$(sed -n '1p' "$dir/manifest"); sha=$(sed -n '2p' "$dir/manifest")
  [[ $declared == "$version" && $declared =~ ^[0-9]+\.[0-9]+\.[0-9]+$ && $sha =~ ^[a-f0-9]{64}$ ]] || return 1
  [[ $(sha256sum "$dir/p.tgz" | cut -d' ' -f1) == "$sha" ]]
}
