#!/usr/bin/env bash
# Compact terminal UI. No network requests during rendering.
term_cols() {
  local cols=${COLUMNS:-}
  [[ $cols =~ ^[0-9]+$ ]] || cols=$(tput cols 2>/dev/null || echo 80)
  [[ $cols =~ ^[0-9]+$ ]] || cols=80
  ((cols > 100)) && cols=100
  ((cols < 20)) && cols=20
  echo "$cols"
}
whr() { local n line; n=$(term_cols); printf -v line '%*s' "$((n-4))" ''; printf '  %s%s%s\n' "$C_DIM" "${line// /─}" "$C_RST"; }
menu_pair() {
  if (($(term_cols) < 76)); then mi "$1" "$2"; echo; mi "$3" "$4"; echo
  else mi "$1" "$2" 24; mi "$3" "$4"; echo; fi
}
resource_pct() {
  local value=$1 color=$C_GRN
  ((value<60)) || color=$C_YLW
  ((value<85)) || color=$C_RED
  printf '%s%s%%%s' "$color" "$value" "$C_RST"
}
show_welcome() {
  local k need svc status count=0 total=0 result stamp scope hash color
  echo
  printf '  %s%s魔法控制台 · %s%s\n' "$C_B" "$C_BLU" "$(st .node_name)" "$C_RST"
  printf '  %sL%s · v%s · 运行 %s%s\n' "$C_DIM" "$(st .level)" "$(cat "$SB_HOME/VERSION")" "$(uptime_cn)" "$C_RST"
  whr
  for k in x s; do
    need=0; if [[ $k == x ]]; then xray_needed && need=1; svc=$SVC_X; else sbox_needed && need=1; svc=$SVC_S; fi
    status='未启用'; color=$C_DIM
    if ((need)); then
      status='未运行'; color=$C_RED
      if systemctl is-active -q "$svc"; then status='运行中'; color=$C_GRN; fi
    fi
    printf '  %s：%s%s%s\n' "$(core_name "$k")" "$color" "$status" "$C_RST"
  done
  for k in "${PROTO_KEYS[@]}"; do ((total+=1)); [[ $(proto_on "$k") == true ]] && ((count+=1)); done
  printf '  协议：%s%s / %s%s 已启用\n' "$C_BLU" "$count" "$total" "$C_RST"
  if [[ -s $SB_HOME/.last-health.json ]]; then
    stamp=$(jq -r .time "$SB_HOME/.last-health.json")
    result=$(jq -r .message "$SB_HOME/.last-health.json")
    hash=$(jq -r .state_hash "$SB_HOME/.last-health.json")
    scope=$(jq -r .scope "$SB_HOME/.last-health.json")
    printf '  最近检测：%s%s [%s]%s\n' "$C_DIM" "$stamp" "$scope" "$C_RST"
    [[ $hash == "$(sha256sum "$STATE" | cut -d' ' -f1)" ]] || printf '  %s配置已变化，请重新检测%s\n' "$C_YLW" "$C_RST"
    if [[ $(jq -r .rc "$SB_HOME/.last-health.json") == 0 ]]; then
      printf '  最近结果：%s检查通过%s\n' "$C_GRN" "$C_RST"
      [[ $result != *握手* ]] || echo '  Naive 仅验证握手'
    else printf '  最近结果：%s异常，h 重新检查%s\n' "$C_RED" "$C_RST"; fi
  else printf '  线路：%s尚未检测（h 检查）%s\n' "$C_YLW" "$C_RST"; fi
  whr
  printf '  CPU %s · 内存 %s · 磁盘 %s\n' "$(resource_pct "$(cpu_pct)")" "$(resource_pct "$(mem_pct)")" "$(resource_pct "$(disk_pct)")"
  if [[ -n $(st .panel.url) ]]; then
    color=$C_RED; status='未运行'
    if systemctl is-active -q "${SB_NAME}-agent"; then color=$C_GRN; status='运行中'; fi
    printf '  面板 agent：%s%s%s\n' "$color" "$status" "$C_RST"
  fi
  for k in x s geo self; do
    result=$(jq -r --arg k "$k" '.upd.result[$k] | select(.result=="fail") | .msg // empty' "$STATE")
    [[ -z $result ]] || printf '  %s! %s：%s%s\n' "$C_YLW" "$k" "$result" "$C_RST"
  done
  local days disk mem bk
  disk=$(disk_pct); mem=$(mem_pct)
  ((disk<80)) || echo '  ! 磁盘空间偏紧：sb log clean'
  ((mem<90)) || echo '  ! 内存使用偏高：sb status'
  if [[ $(st .l1.enabled) == true ]]; then
    days=$(cert_days "$CERT_DIR/direct.crt")
    [[ $days =~ ^-?[0-9]+$ ]] && ((days<15)) && printf '  ! 直连证书剩余 %s 天：sb domain check\n' "$days"
  fi
  bk=$(find "$BK_DIR" -maxdepth 1 -name '*.sbk' -mtime -3 -print -quit 2>/dev/null)
  [[ -n $bk ]] || echo '  ! 近三天无备份：sb backup now'
  echo '  s 查看端口、证书、流量与更新详情'
  return 0
}
menu_proto() {
  local keys=(vision xhttp hy2 tuic anytls naive hy2tls cdn hop)
  local -A selected=() original=()
  local k i sel want dirty baseline label
  while :; do
    baseline=$(sha256sum "$STATE" | cut -d' ' -f1)
    for k in "${keys[@]}"; do original[$k]=$(proto_on "$k"); selected[$k]=${original[$k]}; done
    while :; do
      clear; title '协议管理' '选择后统一应用'
      dirty=0
      for i in "${!keys[@]}"; do
        k=${keys[i]}; label='关闭'; [[ ${selected[$k]} == true ]] && label='启用'
        [[ ${selected[$k]} == "${original[$k]}" ]] || { label+=' *'; dirty=1; }
        if proto_needs_l1 "$k" && [[ $(st .l1.enabled) != true ]]; then label='需要域名'; fi
        printf '  %s. %s [%s]\n' "$((i+1))" "$(proto_label "$k")" "$label"
      done
      echo '  a. 应用更改    d. 放弃更改'
      echo '  m. 端口与高级设置'
      echo '  0. 返回'
      sel=$(ask '选择' 0)
      case $sel in
        [1-9]) k=${keys[sel-1]}
          if proto_needs_l1 "$k" && [[ $(st .l1.enabled) != true ]]; then warn '请先配置域名'; pause; continue; fi
          if [[ ${selected[$k]} == true ]]; then selected[$k]=false; else selected[$k]=true; fi ;;
        a) ((dirty)) || continue
          if [[ $baseline != "$(sha256sum "$STATE" | cut -d' ' -f1)" ]]; then warn '配置已被其他任务修改，重新载入后再选择'; pause; break; fi
          want=''
          for k in "${keys[@]}"; do
            [[ ${selected[$k]} != true ]] || want+="$k."
            [[ ${selected[$k]} == "${original[$k]}" ]] || printf '  %s → %s\n' "$(proto_label "$k")" "$([[ ${selected[$k]} == true ]] && echo 开启 || echo 关闭)"
          done
          [[ ${original[cdn]} != true || ${selected[cdn]} == true || -z $(st .panel.url) ]] || warn '关闭 CDN 后面板将无法远程操作'
          confirm '应用以上更改？会重启核心并短暂断流' n || continue
          if with_lock terminal_apply "$baseline" "${want%.}"; then ok '已应用，请在客户端更新订阅'; else err '应用失败，请查看上方恢复结果'; fi
          pause; break ;;
        d) break ;;
        m) if ((dirty)); then warn '请先应用或放弃待修改项'; pause; else menu_proto_advanced; break; fi ;;
        0|q|'') if ((dirty)); then confirm '放弃未应用的更改并返回？' n || continue; fi; return ;;
        *) warn '无效选择'; pause ;;
      esac
    done
  done
}
terminal_apply() {
  [[ $1 == "$(sha256sum "$STATE" | cut -d' ' -f1)" ]] || { err '配置已变化，请重新选择'; return 1; }
  proto_apply_set "$2"
}
terminal_change() { with_lock transaction terminal_change_raw "$@"; }
terminal_change_raw() {
  st_set "$1" "$2" || return 1
  apply_config "$3"
}
