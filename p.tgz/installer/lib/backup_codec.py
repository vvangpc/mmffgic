#!/usr/bin/env python3
"""SBK2: encrypt-then-MAC envelope; legacy CBC is read-only compatible."""
import hashlib
import hmac
import io
import os
from pathlib import Path
import subprocess
import sys
import tarfile

mode, source, destination, keyfile = sys.argv[1:5]
key = Path(keyfile).read_bytes().strip()
if len(key) < 16:
    raise SystemExit("backup key too short")
data = Path(source).read_bytes()
if len(data)>64*1024*1024:
    raise SystemExit("backup too large")
def crypt(data, decrypt=False):
    return subprocess.run(["openssl","enc",*( ["-d"] if decrypt else []),"-aes-256-cbc","-pbkdf2","-iter","200000","-md","sha256","-pass",f"file:{keyfile}"], input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
if mode == "encrypt":
    salt=os.urandom(16)
    ciphertext=crypt(data)
    auth=hashlib.pbkdf2_hmac("sha256",key,b"SBK2-MAC"+salt,200000)
    header=b"SBK2\n"+salt
    Path(destination).write_bytes(header+hmac.digest(auth,header+ciphertext,"sha256")+ciphertext)
elif mode == "extract":
    if data.startswith(b"SBK2\n"):
        if len(data)<69: raise SystemExit("truncated backup")
        header,tag,ciphertext=data[:21],data[21:53],data[53:]
        auth=hashlib.pbkdf2_hmac("sha256",key,b"SBK2-MAC"+header[5:],200000)
        if not hmac.compare_digest(tag,hmac.digest(auth,header+ciphertext,"sha256")):raise SystemExit("backup authentication failed")
        data=crypt(ciphertext,True)
    else:
        print("读取旧版无认证备份；仅恢复可信来源的旧备份",file=sys.stderr)
        data=crypt(data,True)
    with tarfile.open(fileobj=io.BytesIO(data),mode="r:gz") as tar:
        members=tar.getmembers()
        if len(members)>10000 or sum(m.size for m in members)>128*1024*1024:raise SystemExit("archive too large")
        for m in members:
            p=Path(m.name)
            if p.is_absolute() or ".." in p.parts or not p.parts or p.parts[0] not in ("etc","acme") or not (m.isfile() or m.isdir()):raise SystemExit("unsafe archive entry")
        # All links/devices are rejected above; works with supported Python versions.
        for m in members:
            target=Path(destination)/m.name
            if m.isdir():target.mkdir(parents=True,exist_ok=True)
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(tar.extractfile(m).read())
                target.chmod(0o600)
else:
    raise SystemExit("invalid mode")
