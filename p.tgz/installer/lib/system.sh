#!/usr/bin/env bash
# 系统层：系统检测、依赖、IPv6 关闭、时间同步、BBR、防火墙、端口跳跃

check_os() {
  [[ -r /etc/os-release ]] || die "无法识别系统"
  # shellcheck disable=SC1091
  . /etc/os-release
  case "$ID:$VERSION_ID" in
    ubuntu:22.04|ubuntu:24.04|debian:12|debian:13) ok "系统：$PRETTY_NAME" ;;
    ubuntu:*|debian:*) warn "未测试的版本：$PRETTY_NAME，继续尝试" ;;
    *) die "只支持 Ubuntu 22.04/24.04、Debian 12/13（当前：${PRETTY_NAME:-未知}）" ;;
  esac
  case "$(uname -m)" in
    x86_64|amd64) ARCH=amd64 ;;
    aarch64|arm64) ARCH=arm64 ;;
    *) die "不支持的架构：$(uname -m)" ;;
  esac
  ok "架构：$ARCH"
  command -v systemctl >/dev/null || die "需要 systemd"
}

install_deps() {
  local pkgs=(python3 curl jq openssl unzip tar nftables ca-certificates iproute2)
  local miss=()
  for p in "${pkgs[@]}"; do dpkg -s "$p" >/dev/null 2>&1 || miss+=("$p"); done
  if ((${#miss[@]})); then
    info "安装依赖：${miss[*]}"
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq || warn "apt-get update 出错，继续尝试安装"
    apt-get install -y -qq "${miss[@]}" >/dev/null || die "依赖安装失败：${miss[*]}"
  fi
  ok "依赖已就绪"
}

# 获取公网 IPv4（只走 v4）
get_ipv4() {
  local ip u
  for u in https://api.ipify.org https://ipv4.icanhazip.com https://ifconfig.me/ip https://ip.sb; do
    ip=$(curl -4 -fsS --max-time 6 "$u" 2>/dev/null | tr -d '[:space:]')
    valid_public_ipv4 "$ip" && { echo "$ip"; return 0; }
  done
  return 1  # Never publish a private interface address as the public endpoint.
}

# ---------- IPv6 ----------
SYSCTL_V6=/etc/sysctl.d/90-sb-disable-ipv6.conf

ipv6_disable() {
  # 若当前 SSH 是通过 IPv6 连进来的，关掉会断线
  local client=${SSH_CONNECTION%% *}
  if [[ $client == *:* && $client != ::ffff:* ]]; then
    warn "当前 SSH 连接来自 IPv6 地址（$client），关闭 IPv6 会立即断线！"
    warn "请改用 IPv4 地址登录后再安装。"
    confirm "仍然继续关闭 IPv6？" n || die "已取消"
  fi
  cat >"$SYSCTL_V6" <<'EOF'
# 由 sb 脚本生成：持久关闭 IPv6
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1
EOF
  sysctl -q -p "$SYSCTL_V6" >/dev/null 2>&1 || sysctl -q --system >/dev/null 2>&1
  # 系统解析优先 v4（gai.conf），防止个别程序仍尝试 AAAA
  if [[ -f /etc/gai.conf ]] && ! grep -q '^precedence ::ffff:0:0/96  100' /etc/gai.conf; then
    echo 'precedence ::ffff:0:0/96  100' >>/etc/gai.conf
  fi
  if [[ $(cat /proc/sys/net/ipv6/conf/all/disable_ipv6 2>/dev/null) == 1 ]] || [[ ! -e /proc/sys/net/ipv6 ]]; then
    ok "IPv6 已关闭（持久）"
  else
    warn "IPv6 关闭未生效，请检查内核参数"
  fi
}

ipv6_enable() {
  rm -f "$SYSCTL_V6"
  sysctl -q -w net.ipv6.conf.all.disable_ipv6=0 net.ipv6.conf.default.disable_ipv6=0 net.ipv6.conf.lo.disable_ipv6=0 >/dev/null 2>&1
  ok "IPv6 已恢复（核心配置仍只用 v4）"
}

ipv6_status() {
  if [[ ! -e /proc/sys/net/ipv6 ]] || [[ $(cat /proc/sys/net/ipv6/conf/all/disable_ipv6) == 1 ]]; then
    echo "已关闭"
  else
    echo "${C_YLW}开启中${C_RST}"
  fi
}

# ---------- 时间同步（Reality 对时间敏感） ----------
time_sync() {
  if systemctl list-unit-files 2>/dev/null | grep -q '^chrony'; then
    systemctl enable --now chrony >/dev/null 2>&1 || true
  else
    dpkg -s systemd-timesyncd >/dev/null 2>&1 || apt-get install -y -qq systemd-timesyncd >/dev/null 2>&1 || true
    timedatectl set-ntp true >/dev/null 2>&1 || true
  fi
  ok "时间同步已开启（$(timedatectl show -p NTPSynchronized --value 2>/dev/null | sed 's/yes/已同步/;s/no/同步中/')）"
}

# ---------- BBR ----------
bbr_enable() {
  cat >/etc/sysctl.d/90-sb-bbr.conf <<'EOF'
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF
  sysctl -q -p /etc/sysctl.d/90-sb-bbr.conf >/dev/null 2>&1
  [[ $(sysctl -n net.ipv4.tcp_congestion_control) == bbr ]] && ok "BBR 已开启" || warn "BBR 开启失败（内核可能不支持）"
}
bbr_status() { sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null; }

# ---------- 端口占用检查 ----------
# port_busy tcp 443  -> 0 表示被占用（排除本脚本自己的核心）
port_busy() {
  local proto=$1 port=$2 flag
  [[ $proto == tcp ]] && flag=-lntp || flag=-lnup
  ss $flag 2>/dev/null | awk -v p=":$port" '$4 ~ p"$"' | grep -v -e "\"xray\"" -e "\"sing-box\"" | grep -q .
}

# ---------- 防火墙放行（ufw / firewalld，若启用） ----------
fw_open() {
  local spec owned="$ETC_DIR/firewall.owned" backend
  touch "$owned"
  for spec in "$@"; do
    [[ $spec =~ ^[0-9]+(:[0-9]+)?/(tcp|udp)$ ]] || return 1
    if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q 'Status: active'; then
      backend=ufw
      if ! ufw status | grep -F "$spec" | grep -q ALLOW; then
        ufw allow "$spec" comment "$SB_NAME" >/dev/null 2>&1 || return 1
        echo "$backend $spec" >>"$owned"
      fi
    elif command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; then
      backend=firewalld
      if ! firewall-cmd -q --permanent --query-port="${spec/:/-}"; then
        firewall-cmd -q --permanent --add-port="${spec/:/-}" && firewall-cmd -q --add-port="${spec/:/-}" || return 1
        echo "$backend $spec" >>"$owned"
      fi
    fi
  done
  sort -u "$owned" -o "$owned"
}
fw_close_owned() {
  local spec=$1 backend owned="$ETC_DIR/firewall.owned"
  [[ -f $owned ]] || return 0
  while read -r backend item; do
    [[ $item == "$spec" ]] || continue
    case $backend in
      ufw) ufw --force delete allow "$spec" >/dev/null 2>&1 || return 1 ;;
      firewalld) firewall-cmd -q --permanent --remove-port="${spec/:/-}" && firewall-cmd -q --remove-port="${spec/:/-}" || return 1 ;;
    esac
  done <"$owned"
  awk -v s="$spec" '$2!=s' "$owned" >"$owned.new" && mv "$owned.new" "$owned"
}
firewall_sync() {
  local desired=() k range backend spec
  for k in vision xhttp hy2 tuic anytls naive; do [[ $(proto_on "$k") == true ]] && desired+=("$(proto_port "$k")/$(proto_net "$k")"); done
  if [[ $(st .proto.hy2.enabled) == true && $(st .proto.hy2.hop_enabled) == true ]]; then range=$(st .proto.hy2.hop); desired+=("${range/-/:}/udp"); fi
  if [[ $(st .l1.enabled) == true ]]; then
    [[ $(st .l1.cdn_enabled) == true ]] && desired+=("$(st .l1.cdn_port)/tcp")
    if [[ $(st .l1.hy2tls_enabled) == true ]]; then
      desired+=("$(st .l1.hy2tls_port)/udp")
      range=$(st .l1.hop2); [[ -z $range ]] || desired+=("${range/-/:}/udp")
    fi
  fi
  fw_open "${desired[@]}" || return 1
  local stale=()
  while read -r backend spec; do
    printf '%s\n' "${desired[@]}" | grep -qxF "$spec" || stale+=("$spec")
  done <"$ETC_DIR/firewall.owned"
  for spec in "${stale[@]}"; do fw_close_owned "$spec" || return 1; done
  return 0
}

# ---------- Hy2 端口跳跃：nft 把 UDP 端口段重定向到 Hy2 端口 ----------
# hop_apply "端口段:目标端口:标签" ...   例：hop_apply 20000-30000:443:hop 50001-60000:8443:hop2
# 每个目标端口另有一条 "<标签>-direct" 计数，用于区分直连与跳跃
hop_apply() {
  local f="$ETC_DIR/hop.nft" spec range target tag rules=""
  local intervals=() start end previous a b
  for spec in "$@"; do
    IFS=: read -r range target tag <<<"$spec"
    valid_hop "$range" || { err "跳跃范围无效或占用已用端口"; return 1; }
    start=${range%-*}; end=${range#*-}
    for previous in "${intervals[@]}"; do
      a=${previous%-*}; b=${previous#*-}
      if ((10#$start<=10#$b && 10#$end>=10#$a)); then err "跳跃范围重叠"; return 1; fi
    done
    intervals+=("$range")
    rules+="    udp dport ${target} counter comment \"${tag}-direct\"
    udp dport ${range} counter redirect to :${target} comment \"${tag}\"
"
  done
  cat >"$f" <<EOF
table ip ${SB_NAME}_hop
delete table ip ${SB_NAME}_hop
table ip ${SB_NAME}_hop {
  chain prerouting {
    type nat hook prerouting priority dstnat; policy accept;
${rules}  }
}
EOF
  cat >/etc/systemd/system/${SVC_HOP}.service <<EOF
[Unit]
Description=${SB_NAME} udp hop
After=network-pre.target nftables.service
Wants=network-pre.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/sbin/nft -f ${f}
ExecStop=-/usr/sbin/nft delete table ip ${SB_NAME}_hop

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable "$SVC_HOP" >/dev/null 2>&1
  if systemctl restart "$SVC_HOP"; then
    for spec in "$@"; do IFS=: read -r range target tag <<<"$spec"; ok "端口跳跃：UDP ${range} → ${target}"; done
  else
    warn "端口跳跃规则加载失败"; return 1
  fi
}

# 新建 UDP 流数量（nat 链只统计每条流的首包）：hop_packets 标签   如 hop / hop-direct
hop_packets() {
  nft list table ip "${SB_NAME}_hop" 2>/dev/null |
    awk -v c="comment \"$1\"" 'index($0, c) {for(i=1;i<=NF;i++) if($i=="packets"){print $(i+1); exit}}'
}

hop_remove() {
  systemctl disable --now "$SVC_HOP" >/dev/null 2>&1
  nft delete table ip "${SB_NAME}_hop" >/dev/null 2>&1
  rm -f /etc/systemd/system/${SVC_HOP}.service "$ETC_DIR/hop.nft"
  systemctl daemon-reload
}

valid_public_ipv4() {
  local a b c d extra
  IFS=. read -r a b c d extra <<<"$1"
  [[ -z $extra && $a =~ ^[0-9]{1,3}$ && $b =~ ^[0-9]{1,3}$ && $c =~ ^[0-9]{1,3}$ && $d =~ ^[0-9]{1,3}$ ]] || return 1
  a=$((10#$a)); b=$((10#$b)); c=$((10#$c)); d=$((10#$d))
  ((a>0 && a<224 && b<256 && c<256 && d<256)) || return 1
  ((a!=10 && a!=127 && !(a==169 && b==254) && !(a==172 && b>=16 && b<=31) && !(a==192 && b==168) && !(a==100 && b>=64 && b<=127) && !(a==198 && (b==18 || b==19))))
}
valid_hop() {
  [[ $1 =~ ^([0-9]{1,5})-([0-9]{1,5})$ ]] || return 1
  local a=$((10#${BASH_REMATCH[1]})) b=$((10#${BASH_REMATCH[2]})) p
  ((a>=1024 && b<=65535 && a<=b)) || return 1
  while read -r p; do [[ $p =~ ^[0-9]+$ ]] && ((p>=a && p<=b)) && return 1; done < <(state_ports udp)
  while read -r p; do [[ $p =~ ^[0-9]+$ ]] && ((p>=a && p<=b)) && return 1; done < <(ss -H -lnup 2>/dev/null | grep -v -e '"xray"' -e '"sing-box"' | awk '{sub(/.*:/,"",$4);print $4}')
  return 0
}
