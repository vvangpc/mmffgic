#!/usr/bin/env bash
# 用户管理：每个使用者独立 UUID / Hy2 密码，可单独停用

user_exists() { jq -e --arg n "$1" '.users[]|select(.name==$n)' "$STATE" >/dev/null; }
user_enabled_count() { jq '[.users[]|select(.enabled)]|length' "$STATE"; }

user_list() {
  echo "${C_BLU}  名称            状态    UUID${C_RST}"
  jq -r '.users[] | [.name, (if .enabled then "启用" else "停用" end), .uuid] | @tsv' "$STATE" |
    while IFS=$'\t' read -r n s u; do printf "  %-15s %-6s  %s\n" "$n" "$s" "$u"; done
}

user_add_cmd() {
  local name=$1
  [[ $name =~ ^[A-Za-z0-9_-]{1,20}$ ]] || { err "名称只能用字母、数字、_、-（最多 20 位）"; return 1; }
  user_exists "$name" && { err "用户 $name 已存在"; return 1; }
  add_user "$name"
  apply_config all >/dev/null || return 1
  ok "已添加用户 $name"
  show_nodes "$name" --qr
}

user_set_enabled() {  # user_set_enabled 名称 true|false
  local name=$1 val=$2 tmp
  user_exists "$name" || { err "用户 $name 不存在"; return 1; }
  tmp=$(mktemp)
  jq --arg n "$name" --argjson v "$val" '(.users[]|select(.name==$n)|.enabled) = $v' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
  chmod 600 "$STATE"
  apply_config all >/dev/null || return 1
  ok "用户 $name 已$([[ $val == true ]] && echo 启用 || echo 停用)"
}

user_del() {
  local name=$1 tmp
  user_exists "$name" || { err "用户 $name 不存在"; return 1; }

  tmp=$(mktemp)
  jq --arg n "$name" '.users |= map(select(.name != $n))' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
  chmod 600 "$STATE"
  apply_config all >/dev/null || return 1
  ok "已删除用户 $name"
}

# 重置某用户的 UUID 和 Hy2 密码（泄露时用）
user_reset() {
  local name=$1 tmp
  user_exists "$name" || { err "用户 $name 不存在"; return 1; }
  tmp=$(mktemp)
  jq --arg n "$name" --arg u "$(gen_uuid)" --arg p "$(rand_hex 16)" \
    '(.users[]|select(.name==$n)) |= (.uuid=$u | .hy2=$p)' "$STATE" >"$tmp" && mv "$tmp" "$STATE"
  chmod 600 "$STATE"
  apply_config all >/dev/null || return 1
  ok "用户 $name 的 UUID 和密码已重置，旧链接失效"
  show_nodes "$name"
}

pick_user() {  # 交互选一个用户名
  user_list >&2
  ask "用户名" "${1:-}"
}

menu_user() {
  while :; do
    clear
    title "用户管理"
    user_list
    echo
    echo "   ${C_BLU}1${C_RST}  添加用户   2. 停用用户   3. 启用用户   4. 删除用户"
    echo "   ${C_BLU}5${C_RST}  重置 UUID  6. 查看某用户的节点   0. 返回"
    case $(ask "选择" 0) in
      1) user_add_cmd "$(ask "新用户名称（字母数字）")" ;;
      2) user_set_enabled "$(ask "要停用的用户")" false ;;
      3) user_set_enabled "$(ask "要启用的用户")" true ;;
      4) local n; n=$(ask "要删除的用户")
         [[ -n $n ]] && confirm "确定删除 $n？" n && user_del "$n" ;;
      5) local n; n=$(ask "要重置的用户")
         [[ -n $n ]] && confirm "重置后 $n 的旧链接全部失效，继续？" n && user_reset "$n" ;;
      6) show_nodes "$(ask "用户名" default)" --qr ;;
      0|"") return ;;
    esac
    pause
  done
}

# sb user 子命令
cmd_user() {
  case "${1:-}" in
    "") menu_user ;;
    list) user_list ;;
    add) user_add_cmd "$2" ;;
    disable) user_set_enabled "$2" false ;;
    enable) user_set_enabled "$2" true ;;
    del) user_del "$2" ;;
    reset) user_reset "$2" ;;
    *) echo "用法：sb user [list|add 名称|disable 名称|enable 名称|del 名称|reset 名称]" ;;
  esac
}
