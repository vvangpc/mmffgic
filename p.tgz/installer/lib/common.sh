#!/usr/bin/env bash
# 公共函数：输出、路径、状态文件读写
# 由 install.sh / sb.sh 通过 source 引入，依赖 SB_HOME 已设置

umask 077
# Root-private per-invocation diagnostics; never follow predictable /tmp paths.
SB_RUN_DIR=$(mktemp -d "${TMPDIR:-/tmp}/sb-run.XXXXXXXX") || exit 1
chmod 700 "$SB_RUN_DIR"
trap 'rm -rf -- "$SB_RUN_DIR"' EXIT

# ---------- 输出 ----------
if [[ -t 1 ]]; then
  C_RED=$'\e[31m'; C_GRN=$'\e[32m'; C_YLW=$'\e[33m'; C_BLU=$'\e[36m'; C_DIM=$'\e[2m'; C_B=$'\e[1m'; C_RST=$'\e[0m'
else
  C_RED=""; C_GRN=""; C_YLW=""; C_BLU=""; C_DIM=""; C_B=""; C_RST=""
fi
info() { echo "${C_BLU}[*]${C_RST} $*"; }
ok()   { echo "${C_GRN}[✓]${C_RST} $*"; }
warn() { echo "${C_YLW}[!]${C_RST} $*" >&2; }
err()  { echo "${C_RED}[✗]${C_RST} $*" >&2; }
die()  { err "$*"; exit 1; }

# ---------- 排版 ----------
# 显示宽度：中文等多字节字符按 2 列算（终端里一个汉字占两格），先去掉颜色码
dw() {
  local s; s=$(sed 's/\x1b\[[0-9;]*m//g' <<<"$1")
  local a; a=$(LC_ALL=C tr -d '\200-\377' <<<"$s")
  local nb=$(( $(LC_ALL=C printf %s "$s" | LC_ALL=C wc -c) - ${#a} ))
  echo $(( ${#a} + nb / 3 * 2 ))
}
padr() { local w; w=$(dw "$1"); printf '%s%*s' "$1" $(( $2 > w ? $2 - w : 0 )) ""; }   # 右侧补空格到指定宽度
hr()    { printf '  %s%s%s\n' "$C_DIM" "──────────────────────────────────────────────────" "$C_RST"; }
title() { echo; printf '  %s▍%s%s%s%s\n' "$C_BLU" "$C_RST" "$C_B" "$1" "$C_RST${2:+  $C_DIM$2$C_RST}"; }
kv()    { printf '    %s%s%s%s\n' "$C_DIM" "$(padr "$1" 12)" "$C_RST" "$2"; }
dot()   { case $1 in on|true|active) printf '%s●%s' "$C_GRN" "$C_RST" ;; bad|fail) printf '%s●%s' "$C_RED" "$C_RST" ;; *) printf '%s○%s' "$C_DIM" "$C_RST" ;; esac; }
mi()    { printf '   %s%s%s  %s' "$C_BLU" "$1" "$C_RST" "$(padr "$2" "${3:-20}")"; }   # 菜单项：键 文字 [宽度]

# 询问，带默认值：ask "提示" "默认值" -> 结果在 stdout
ask() {
  local prompt=$1 def=${2:-} ans
  if [[ -n $def ]]; then
    read -r -p "$prompt [${def}]: " ans </dev/tty || true
  else
    read -r -p "$prompt: " ans </dev/tty || true
  fi
  echo "${ans:-$def}"
}
# 是/否，默认值 y 或 n
confirm() {
  local prompt=$1 def=${2:-n} ans
  read -r -p "$prompt [$([[ $def == y ]] && echo Y/n || echo y/N)]: " ans </dev/tty || true
  ans=${ans:-$def}
  [[ $ans =~ ^[Yy] ]]
}
pause() { read -r -p "按回车继续..." _ </dev/tty || true; }

# ---------- 路径 ----------
SB_NAME=$(basename "$SB_HOME")
BIN_DIR="$SB_HOME/bin"
ETC_DIR="$SB_HOME/etc"
CERT_DIR="$ETC_DIR/cert"
OUT_DIR="$SB_HOME/out"
STATE="$ETC_DIR/state.json"
XRAY_BIN="$BIN_DIR/xray"
SBOX_BIN="$BIN_DIR/sing-box"
XRAY_CONF="$ETC_DIR/xray.json"
SBOX_CONF="$ETC_DIR/sing-box.json"
SVC_X="${SB_NAME}-x"   # Xray 服务名
SVC_S="${SB_NAME}-s"   # sing-box 服务名
SVC_HOP="${SB_NAME}-hop"  # 端口跳跃 nft 规则

# ---------- 状态文件（JSON，jq 读写） ----------
# st '.path'          读取
# st_set '.path' val  写入（val 为 JSON 字面量，如 '"abc"' / 'true' / '443'）
st() { jq -r "$1 | select(. != null)" "$STATE"; }
st_set() {
  local tmp
  tmp=$(mktemp)
  jq "$1 = $2" "$STATE" >"$tmp" && mv "$tmp" "$STATE" && chmod 600 "$STATE"
}
# 写入字符串（自动转义）
st_set_str() {
  local tmp
  tmp=$(mktemp)
  jq --arg v "$2" "$1 = \$v" "$STATE" >"$tmp" && mv "$tmp" "$STATE" && chmod 600 "$STATE"
}

# ---------- 杂项 ----------
rand_hex() { openssl rand -hex "${1:-8}"; }
rand_str() { tr -dc 'a-z0-9' </dev/urandom | head -c "${1:-8}"; }
gen_uuid() {
  if [[ -r /proc/sys/kernel/random/uuid ]]; then cat /proc/sys/kernel/random/uuid
  else "$XRAY_BIN" uuid; fi
}
# URL 编码（用于分享链接里的备注、路径）
urlencode() { jq -rn --arg v "$1" '$v|@uri'; }

need_root() { [[ $EUID -eq 0 ]] || die "请用 root 运行"; }

switch_tree() {
  local dst=$1 stage=$2 old link="${1}.next.$$"
  [[ $stage == "$SB_HOME"/.outputs.* || $stage == "$SB_HOME"/.subs.* || $stage == "$SB_HOME"/.rules.* ]] || return 1
  old=$(readlink "$dst" 2>/dev/null || true)
  if [[ -d $dst && ! -L $dst ]]; then mv "$dst" "${dst}.legacy.$$" || return 1; old="${dst}.legacy.$$"; fi
  ln -s "$stage" "$link" && mv -Tf "$link" "$dst" || return 1
  [[ $old == "$SB_HOME"/* && $old != "$stage" ]] && rm -rf -- "$old"
  return 0
}
