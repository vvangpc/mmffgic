#!/usr/bin/env bash
# 安装入口：把脚本复制到 /opt/<随机名>/ 并执行安装
# 用法：bash install.sh [-y] [--restore 备份文件]
#   -y          全部使用默认值，不提问
#   --restore   安装后用备份恢复节点参数（换 VPS 时用）
#   --repo      发布仓库 raw 地址（引导脚本传入，用于脚本自更新）
set -o pipefail

SRC=$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)
[[ $EUID -eq 0 ]] || { echo "请用 root 运行" >&2; exit 1; }

AUTO_YES=0 RESTORE_FILE="" REPO_RAW=""
while (($#)); do
  case $1 in
    -y) AUTO_YES=1 ;;
    --restore) RESTORE_FILE=$(readlink -f "$2"); shift ;;
    --repo) REPO_RAW=${2%/}; shift ;;
    *) echo "未知参数：$1" >&2; exit 2 ;;
  esac
  shift
done

# 已安装则沿用原目录（保留节点参数），否则随机生成中性目录名
if [[ -L /usr/local/bin/sb ]] && [[ -f $(readlink -f /usr/local/bin/sb) ]]; then
  SB_HOME=$(dirname "$(readlink -f /usr/local/bin/sb)")
else
  SB_HOME="/opt/$(tr -dc 'a-z' </dev/urandom | head -c 6)"
fi
exec 9>"/run/$(basename "$SB_HOME").lock"
flock -w 600 9 || { echo "另一项安装或维护仍在执行" >&2; exit 1; }
export SB_LOCKED="$SB_HOME"
mkdir -p "$SB_HOME/lib"
if [[ $SRC != "$SB_HOME" ]]; then
  rm -f "$SB_HOME"/lib/*.sh
  cp -f "$SRC"/lib/* "$SB_HOME/lib/"
  cp -f "$SRC/sb.sh" "$SB_HOME/sb.sh"
  [[ -f $SRC/VERSION ]] && cp -f "$SRC/VERSION" "$SB_HOME/VERSION"
  [[ -d $SRC/agent ]] && { mkdir -p "$SB_HOME/agent"; cp -f "$SRC"/agent/* "$SB_HOME/agent/"; }
fi
chmod 755 "$SB_HOME/sb.sh"

export SB_HOME AUTO_YES
# shellcheck disable=SC1091
. "$SB_HOME/lib/load.sh"
install_rc=0
do_install || install_rc=$?
[[ -n $REPO_RAW ]] && st_set_str .self.repo "$REPO_RAW"
((install_rc == 0)) || exit "$install_rc"
if [[ -n $RESTORE_FILE ]]; then
  backup_restore "$RESTORE_FILE" || exit $?
  [[ -n $REPO_RAW ]] && st_set_str .self.repo "$REPO_RAW"   # 备份里可能是旧地址
fi
