#!/usr/bin/env bash
# sb：管理菜单与子命令
set -o pipefail

SB_HOME=$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")
export SB_HOME
# shellcheck disable=SC1091
. "$SB_HOME/lib/load.sh"
need_root
state_migrate

onoff() { [[ $1 == true ]] && echo "${C_GRN}● 开${C_RST}" || echo "${C_DIM}○ 关${C_RST}"; }
toggle() { if [[ $(st "$1") == true ]]; then st_set "$1" false; else st_set "$1" true; fi; }
todo() { warn "$1 功能尚未启用：$2"; }

# ---------- sb status ----------
cmd_status() {
  local now_ip cert_end r k n eg
  title "状态" "$(st .node_name) · L$(st .level) · v$(cat "$SB_HOME/VERSION" 2>/dev/null)"
  kv "Xray" "$(dot "$(systemctl is-active "$SVC_X")") $(st .core.xray)"
  kv "sing-box" "$(dot "$(systemctl is-active "$SVC_S")") $(st .core.singbox)"
  kv "节点 IP" "$(st .ip)"
  now_ip=$(get_ipv4)
  if [[ -n $now_ip && $now_ip != "$(st .ip)" ]]; then
    kv "当前公网 IP" "${C_YLW}$now_ip（已变化，sb ip 立即更新；每 5 分钟也会自动检测）${C_RST}"
  fi
  eg=$(jq -r --arg ip "$(st .ip)" '[(.egress // {}) | to_entries[] | select(.value != $ip) | .key] | join(", ")' "$STATE")
  kv "出口 IP" "$([[ -z $eg ]] && echo "各线路都与节点 IP 一致" || echo "${C_YLW}$eg 线路不同（节点名带 -IPchange）${C_RST}")"
  kv "IPv6" "$(ipv6_status)"
  kv "拥塞控制" "$(bbr_status)"
  cert_end=$(openssl x509 -noout -enddate -in "$CERT_DIR/hy2.crt" 2>/dev/null | cut -d= -f2)
  kv "Hy2 证书" "自签，到期 $(date -d "$cert_end" +%F 2>/dev/null || echo 未知)"
  declare -F domain_status >/dev/null && domain_status

  title "协议"
  kv "Vision" "$(onoff "$(st .proto.vision.enabled)")   TCP $(st .proto.vision.port)"
  kv "XHTTP" "$(onoff "$(st .proto.xhttp.enabled)")   TCP $(st .proto.xhttp.port)"
  kv "Hysteria2" "$(onoff "$(st .proto.hy2.enabled)")   UDP $(st .proto.hy2.port)$([[ $(st .proto.hy2.hop_enabled) == true ]] && echo "  ${C_DIM}跳跃 $(st .proto.hy2.hop)${C_RST}")"
  kv "TUIC" "$(onoff "$(proto_on tuic)")   UDP $(st .proto.tuic.port)"
  if [[ $(st .l1.enabled) == true ]]; then
    kv "Hy2-TLS" "$(onoff "$(st .l1.hy2tls_enabled)")   UDP $(st .l1.hy2tls_port)$([[ -n $(st .l1.hop2) ]] && echo "  ${C_DIM}跳跃 $(st .l1.hop2)${C_RST}")"
    kv "CDN" "$(onoff "$(st .l1.cdn_enabled)")   TCP $(st .l1.cdn_port)"
    kv "AnyTLS" "$(onoff "$(proto_on anytls)")   TCP $(st .proto.anytls.port)"
    kv "Naive" "$(onoff "$(proto_on naive)")   TCP $(st .proto.naive.port)"
  fi
  [[ $(st .proto.hy2.hop_enabled) == true ]] &&
    kv "Hy2 连接数" "直连 $(hop_packets hop-direct) · 跳跃 $(hop_packets hop)  ${C_DIM}（规则加载以来）${C_RST}"
  kv "屏蔽" "回国 $(onoff "$(st .block.cn)")   BT $(onoff "$(st .block.bt)")"
  kv "用户" "$(jq '[.users[]|select(.enabled)]|length' "$STATE") 个启用 / 共 $(jq '.users|length' "$STATE") 个"

  title "上次更新"
  for k in x s geo self; do
    r=$(jq -r --arg k "$k" '.upd.result[$k] // empty | "\(.result)\t\(.time)\t\(.msg)"' "$STATE")
    case $k in x) n=Xray ;; s) n=sing-box ;; geo) n=Geo ;; self) n=脚本 ;; esac
    if [[ -z $r ]]; then kv "$n" "${C_DIM}暂无${C_RST}"; continue; fi
    IFS=$'\t' read -r k r eg <<<"$r"
    kv "$n" "$(dot "$([[ $k == ok ]] && echo on || echo fail)") ${C_DIM}$r${C_RST}  $eg"
  done

  if [[ -s $SB_HOME/.last-health.json ]]; then
    title "最近线路检测"
    jq -r '.time, .message' "$SB_HOME/.last-health.json"
  fi
  title "流量"
  if [[ -s $TRAFFIC ]]; then
    local month; month=$(TZ=Asia/Shanghai date +%Y-%m)
    kv "本月总流量" "$(human_bytes "$(jq -r --arg m "$month" '(.mon[$m].rx // 0) + (.mon[$m].tx // 0)' "$TRAFFIC")")"
  else kv "流量" "暂无统计"; fi
  title "监听端口"
  ss -lntup 2>/dev/null | awk 'NR>1 && /"(xray|sing-box|nginx|sbagent)"/ {split($7,a,"\""); print a[2], $1, $5}' | sort -u |
    while read -r c a b; do printf '    %s%s%s%s %s
' "$C_DIM" "$(padr "$c" 10)" "$C_RST" "$(padr "${a^^}" 4)" "$b"; done
  echo
}

cmd_ip() {
  local ip
  ip=$(get_ipv4)
  [[ -n $ip ]] || die "获取公网 IPv4 失败"
  local old; old=$(st .ip)
  st_set_str .ip "$ip"
  gen_outputs
  if [[ $(st .level) -ge 1 ]] && declare -F dns_sync >/dev/null; then dns_sync; fi
  ok "节点 IP：$old → $ip"
  [[ $(st .level) -ge 1 ]] || warn "L0 链接里是 IP，请在客户端重新导入"
}

cmd_log() {
  echo "   ${C_BLU}1${C_RST}  Xray 日志   2. sing-box 日志   3. 实时跟踪 Xray   4. 实时跟踪 sing-box"
  echo "   ${C_BLU}5${C_RST}  事件日志（更新 / 备份 / 告警 / IP 变化）   6. 面板 agent 日志   7. 清理日志（腾硬盘）"
  case $(ask "选择" 1) in
    1) journalctl -u "$SVC_X" -n 80 --no-pager ;;
    2) journalctl -u "$SVC_S" -n 80 --no-pager ;;
    3) journalctl -u "$SVC_X" -f ;;
    4) journalctl -u "$SVC_S" -f ;;
    5) tail -n 60 "$SB_HOME/log/events.log" 2>/dev/null || echo "（暂无）" ;;
    6) journalctl -u "${SB_NAME}-agent" -n 80 --no-pager ;;
    7) log_clean ;;
  esac
}

cmd_sub() {
  local u=${1:-default}
  show_nodes "$u" --qr
  echo
  if declare -F sub_urls >/dev/null && [[ $(st .level) -ge 1 ]]; then
    sub_urls "$u"
  elif [[ -t 0 ]] && confirm "开启 5 分钟临时订阅（明文 HTTP，方便导入）？" n; then
    temp_sub "$u" 5
  fi
}

cmd_update() {
  local what=${1:-all}; shift || true
  case $what in
    x|xray) update_core x "$@" ;;
    s|sing-box|singbox) update_core s "$@" ;;
    geo) update_geo ;;
    self) self_update "$@" ;;
    all|--force) [[ $what == --force ]] && set -- --force "$@"
      update_core x "$@"; update_core s "$@" ;;
    *) echo "用法：sb update [x|s|geo|self] [--force] [--simulate-fail]" ;;
  esac
}

# ---------- 协议管理 ----------
# 一行协议：proto_line 编号 key
proto_line() {
  local n=$1 k=$2 st port note=""
  port=$(proto_port "$k")
  if proto_needs_l1 "$k" && [[ $(st .l1.enabled) != true ]]; then
    st="${C_DIM}○ 需 L1${C_RST}"; note="${C_DIM}要先升级域名（sb → 4）${C_RST}"
  else
    st=$(onoff "$(proto_on "$k")")
  fi
  case $k in
    tuic) note=${note:-"${C_DIM}与 Hy2 同为 UDP，可作备用${C_RST}"} ;;
    anytls) note=${note:-"${C_DIM}域名真证书，Reality 被针对时的替补${C_RST}"} ;;
    naive) note=${note:-"${C_DIM}仿 Chrome 流量；FlClash 不支持${C_RST}"} ;;
    cdn) note=${note:-"${C_DIM}IP 被墙时用，面板远程操作也靠它${C_RST}"} ;;
  esac
  echo "   ${C_BLU}$n${C_RST}  $(padr "$(proto_label "$k")" 22) $(padr "$st" 12) $(padr "$(proto_net "$k" | tr a-z A-Z) ${port:--}" 11) $note"
}

menu_proto_advanced() {
  local keys=(vision xhttp hy2 tuic anytls naive hy2tls cdn) i
  while :; do
    clear
    title "端口与高级设置"
    echo
    echo "   ${C_BLU}p${C_RST}  修改端口"
    echo "   ${C_BLU}h${C_RST}  修改 Hy2 跳跃范围"
    echo "   ${C_BLU}r${C_RST}  更换 Reality 伪装站点（当前 $(st .reality.sni)）"
    echo "   ${C_BLU}c${C_RST}  屏蔽回国流量       $(onoff "$(st .block.cn)")"
    echo "   ${C_BLU}b${C_RST}  屏蔽 BT            $(onoff "$(st .block.bt)")"
    echo "   ${C_BLU}v${C_RST}  IPv6 应急开关      当前 $(ipv6_status)"
    echo "   ${C_BLU}n${C_RST}  节点名称（当前 $(st .node_name)）   i. 线路实测（延迟 / 出口 IP / 测速）"
    echo "   ${C_BLU}0${C_RST}  返回"
    local sel; sel=$(ask "选择" 0)
    case $sel in p|r|c|b|h) confirm "此操作会应用配置并可能短暂断流，继续？" n || continue ;; esac
    case $sel in
      h) local range; range=$(ask '跳跃端口范围' "$(st .proto.hy2.hop)")
         if valid_hop "$range"; then terminal_change .proto.hy2.hop "$(jq -Rn --arg s "$range" '$s')" s
         else err '跳跃范围无效或存在端口冲突'; fi ;;
      p) echo "   ${C_BLU}1${C_RST}  Vision  2. XHTTP  3. Hy2  4. TUIC  5. AnyTLS  6. Naive"
         local k proto key cur p
         k=$(ask "改哪个" 1)
         case $k in 1) key=vision ;; 2) key=xhttp ;; 3) key=hy2 ;; 4) key=tuic ;; 5) key=anytls ;; 6) key=naive ;; *) continue ;; esac
         proto=$(proto_net "$key")
         cur=$(st ".proto.$key.port")
         p=$(ask "新的 ${proto^^} 端口" "$cur")
         if [[ $p =~ ^[0-9]+$ ]] && ((p >= 1 && p <= 65535)) && [[ $p != "$cur" ]]; then
           if port_busy "$proto" "$p" || state_ports "$proto" | grep -qx "$p"; then warn "端口 $p 已被占用"
           elif [[ $proto == udp ]] && in_hop_range "$p"; then warn "端口 $p 在 Hy2 跳跃端口段里，换一个"
           else
             case $key in vision|xhttp) terminal_change ".proto.$key.port" "$p" x ;; *) terminal_change ".proto.$key.port" "$p" s ;; esac
             [[ $? == 0 ]] && warn "端口已改，请在客户端重新导入链接"
           fi
         fi ;;
      r) local s; s=$(choose_reality_sni)
         if [[ -n $s && $s != "$(st .reality.sni)" ]]; then
           terminal_change .reality.sni "$(jq -Rn --arg s "$s" '$s')" x && warn "已改为 $s，请在客户端重新导入链接"
         fi ;;
      c) terminal_change .block.cn "$([[ $(st .block.cn) == true ]] && echo false || echo true)" all ;;
      b) terminal_change .block.bt "$([[ $(st .block.bt) == true ]] && echo false || echo true)" all ;;
      v) if [[ $(ipv6_status) == 已关闭 ]]; then
           warn "应急开关：恢复系统 IPv6（核心仍只用 v4），仅用于排障"
           confirm "确定开启？" n && ipv6_enable
         else
           ipv6_disable
         fi ;;
      n) local nn; nn=$(ask "新的节点名称" "$(st .node_name)")
         nn=$(tr -cd 'A-Za-z0-9-' <<<"$nn")
         [[ -n $nn ]] && st_set_str .node_name "$nn" && gen_outputs && warn "节点名已改，请在客户端重新导入链接" ;;
      i) probe_show speed; egress_refresh "$PROBE_LAST"; pause ;;
      0|"") return ;;
    esac
    pause
  done
}

menu_sys() {
  echo "   ${C_BLU}1${C_RST}  开启 BBR（当前 $(bbr_status)）  2. 时间同步  3. 健康检查（实际出站测试）"
  echo "   ${C_BLU}4${C_RST}  SSH 登录自动进菜单 $(welcome_enabled && onoff true || onoff false)   5. 清理日志（腾硬盘）   u. 卸载   0. 返回"
  case $(ask "选择" 0) in
    1) bbr_enable ;;
    2) time_sync ;;
    3) health_check all; echo "$HEALTH_MSG" ;;
    4) if welcome_enabled; then welcome_remove; st_set .welcome false; ok "已关闭，SSH 登录后停在命令行（输入 sb 进菜单）"
       else welcome_install; st_set .welcome true; ok "已开启，下次 SSH 登录直接进入菜单"; fi ;;
    5) log_clean ;;
    u) do_uninstall ;;
  esac
}

menu_main() {
  while :; do
    clear
    # 顶部就是欢迎页（资源、服务、协议、流量、告警、常用命令）
    show_welcome
    whr
    printf '   %s管理菜单%s\n' "$C_BLU" "$C_RST"
    menu_pair 1 "安装 / 重装" 2 "协议管理"
    menu_pair 3 "节点 / 订阅" 4 "域名设置"
    menu_pair 5 "面板接入" 6 "更新设置"
    menu_pair 7 "用户管理" 8 "备份 / 恢复"
    menu_pair 9 "系统维护" 0 "退出（q）"
    whr
    printf '   %s快捷操作%s\n' "$C_BLU" "$C_RST"
    menu_pair h "线路健康检查" s "详细状态"
    menu_pair l "查看日志" u "检查更新"
    echo
    case $(ask "选择" q) in
      1) do_install ;;
      2) menu_proto; continue ;;
      3) cmd_sub ;;
      4) if declare -F menu_domain >/dev/null; then menu_domain; continue; else todo 添加域名 "缺少模块"; fi ;;
      5) if declare -F menu_panel >/dev/null; then menu_panel; continue; else todo 接入面板 "缺少模块"; fi ;;
      6) menu_update; continue ;;
      7) menu_user; continue ;;
      8) menu_backup; continue ;;
      9) menu_sys ;;
      h) health_check all; echo "$HEALTH_MSG" ;;
      s) cmd_status ;;
      l) cmd_log ;;
      u) cmd_update ;;
      0|q|Q) exit 0 ;;
    esac
    pause
  done
}

usage() {
  cat <<'EOF'
用法：sb [命令]
  （无）        主菜单
  status        状态：两个核心、出口 IP、证书有效期、上次更新结果
  update        立即检查更新   sb update [x|s|geo|self] [--force] [--simulate-fail]
  log           查看日志
  sub [用户]    显示节点链接、订阅和二维码
  user          用户管理       sb user [list|add|disable|enable|del|reset] 名称
  backup        备份 / 恢复    sb backup [now|list|restore 文件|key]
  domain        域名（L1）
  panel         面板（L2）
  ip            重新检测公网 IP
  health        健康检查（经每个协议实际访问外网）
  welcome       欢迎页（SSH 登录时自动显示）
EOF
}

reliability_init

case "${1:-}" in
  "") menu_main ;;
  status|s) cmd_status ;;
  welcome) if [[ ${2:-} == --login ]]; then welcome_login; else show_welcome; echo; fi ;;
  update) shift; cmd_update "$@" ;;
  log) if [[ ${2:-} == clean ]]; then log_clean; else cmd_log; fi ;;
  sub) cmd_sub "${2:-default}" ;;
  ip) cmd_ip ;;
  user) shift; cmd_user "$@" ;;
  backup) shift; cmd_backup "$@" ;;
  health) health_check "${2:-all}"; rc=$?; echo "$HEALTH_MSG"; exit $rc ;;
  probe) if [[ ${2:-} == --json ]]; then node_probe "${3:-}"; else probe_show "${2:-}"; egress_refresh "$PROBE_LAST"; fi ;;
  cron) cron_run "$2" ;;
  domain) shift; if declare -F cmd_domain >/dev/null; then cmd_domain "$@"; else todo 域名 "缺少模块"; fi ;;
  panel) shift; if declare -F cmd_panel >/dev/null; then cmd_panel "$@"; else todo 面板 "缺少模块"; fi ;;
  agent-exec) shift; agent_exec "$@" ;;
  self-post) self_post ;;
  cert-reload) declare -F cert_reload >/dev/null && cert_reload ;;
  version) cat "$SB_HOME/VERSION" ;;
  -h|--help|help) usage ;;
  *) usage; exit 1 ;;
esac
